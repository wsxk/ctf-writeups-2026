public static class GameConfig
{
    public const int MaxWeight = 132;
    public const int TrueEndingValue = 322;
    public const string StoryResourcePath = "Story/story";
    public const string TitleSceneName = "TitleScene";
    public const string GameSceneName = "GameScene";
    public const string EndingSceneName = "EndingScene";
}
