using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GameManager : MonoBehaviour
{
    [SerializeField] private DialogueUI dialogueUI;
    [SerializeField] private Text errorLabel;

    private readonly HashSet<string> flags = new HashSet<string>();
    private readonly List<string> markers = new List<string>();
    private StoryDatabase storyData;
    private int currentNodeIndex;
    private int currentWeight;
    private int currentValue;
    private int maxWeight;
    private int trueEndingValue;

    public void Configure(DialogueUI targetDialogueUI, Text targetErrorLabel)
    {
        dialogueUI = targetDialogueUI;
        errorLabel = targetErrorLabel;
    }

    private void Start()
    {
        GameStateStore.ResetRun();
        LoadStory();

        if (storyData == null || storyData.nodes.Count == 0)
        {
            ShowError("Story data is missing or invalid.");
            return;
        }

        maxWeight = storyData.meta != null && storyData.meta.maxWeight > 0
            ? storyData.meta.maxWeight
            : GameConfig.MaxWeight;
        trueEndingValue = storyData.meta != null && storyData.meta.trueEndingValue > 0
            ? storyData.meta.trueEndingValue
            : GameConfig.TrueEndingValue;

        ShowCurrentNode();
    }

    private void LoadStory()
    {
        TextAsset textAsset = Resources.Load<TextAsset>(GameConfig.StoryResourcePath);
        if (textAsset == null)
        {
            Debug.LogError($"Missing story resource at Resources/{GameConfig.StoryResourcePath}.json");
            return;
        }

        storyData = JsonUtility.FromJson<StoryDatabase>(textAsset.text);
        if (storyData == null)
        {
            Debug.LogError("Failed to parse story.json");
        }
    }

    private void ShowCurrentNode()
    {
        if (dialogueUI == null)
        {
            ShowError("DialogueUI reference is missing.");
            return;
        }

        StoryNodeData node = storyData.nodes[currentNodeIndex];
        dialogueUI.RenderNode(
            node,
            currentNodeIndex,
            storyData.nodes.Count,
            currentWeight,
            currentValue,
            ResolveSprite,
            OnChoiceSelected);
    }

    private void OnChoiceSelected(StoryChoiceData choice)
    {
        currentWeight += choice.weight;
        currentValue += choice.value;

        if (!string.IsNullOrWhiteSpace(choice.flag))
        {
            flags.Add(choice.flag);
        }

        if (!string.IsNullOrWhiteSpace(choice.marker))
        {
            markers.Add(choice.marker);
        }

        GameStateStore.SetProgress(currentWeight, currentValue, flags, markers);

        currentNodeIndex++;
        if (currentNodeIndex >= storyData.nodes.Count)
        {
            EvaluateEnding();
            return;
        }

        ShowCurrentNode();
    }

    private void EvaluateEnding()
    {
        if (currentWeight > maxWeight)
        {
            FinishGame(EndingType.Failure);
            return;
        }

        bool isTrueEnding = currentValue == trueEndingValue;

        FinishGame(isTrueEnding ? EndingType.True : EndingType.Normal);
    }

    private void FinishGame(EndingType endingType)
    {
        GameStateStore.SetEnding(endingType, currentWeight, currentValue, flags, markers);
        SceneFlowController.OpenEnding();
    }

    private Sprite ResolveSprite(string resourceName)
    {
        Sprite sprite = Resources.Load<Sprite>($"Art/{resourceName}");
        return sprite != null ? sprite : GeneratedArtLibrary.Get(resourceName);
    }

    private void ShowError(string message)
    {
        Debug.LogError(message);
        if (errorLabel != null)
        {
            errorLabel.gameObject.SetActive(true);
            errorLabel.text = message;
        }
    }
}
