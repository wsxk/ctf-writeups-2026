using System.Collections.Generic;
using System.Security.Cryptography;
using System.Text;

public static class FlagUtility
{
    public static string BuildTrueEndingFlag(IEnumerable<string> markers)
    {
        if (markers == null)
        {
            return string.Empty;
        }

        StringBuilder builder = new StringBuilder();
        foreach (string marker in markers)
        {
            if (!string.IsNullOrWhiteSpace(marker))
            {
                builder.Append(marker);
            }
        }

        byte[] payload = Encoding.UTF8.GetBytes(builder.ToString());
        byte[] digest;
        using (MD5 md5 = MD5.Create())
        {
            digest = md5.ComputeHash(payload);
        }
        StringBuilder hex = new StringBuilder(digest.Length * 2);
        foreach (byte value in digest)
        {
            hex.Append(value.ToString("x2"));
        }

        return $"SUCTF{{{hex}}}";
    }
}
