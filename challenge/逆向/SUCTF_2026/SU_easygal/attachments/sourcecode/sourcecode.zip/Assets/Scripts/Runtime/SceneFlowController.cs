using UnityEngine;
using UnityEngine.SceneManagement;

public static class SceneFlowController
{
    public static void OpenTitle()
    {
        OpenScreen(GameScreenKind.Title);
    }

    public static void OpenGame()
    {
        OpenScreen(GameScreenKind.Game);
    }

    public static void OpenEnding()
    {
        OpenScreen(GameScreenKind.Ending);
    }

    private static void OpenScreen(GameScreenKind screen)
    {
        string sceneName = GetSceneName(screen);
        RuntimeSceneBootstrap.PendingScreen = screen;

        if (!string.IsNullOrEmpty(sceneName) && Application.CanStreamedLevelBeLoaded(sceneName))
        {
            SceneManager.LoadScene(sceneName);
            return;
        }

        RuntimeSceneBootstrap.Show(screen);
    }

    private static string GetSceneName(GameScreenKind screen)
    {
        switch (screen)
        {
            case GameScreenKind.Title:
                return GameConfig.TitleSceneName;
            case GameScreenKind.Game:
                return GameConfig.GameSceneName;
            case GameScreenKind.Ending:
                return GameConfig.EndingSceneName;
            default:
                return string.Empty;
        }
    }
}
