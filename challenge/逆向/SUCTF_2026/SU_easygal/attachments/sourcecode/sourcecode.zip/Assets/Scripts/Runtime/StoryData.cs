using System;
using System.Collections.Generic;
using System.Linq;

[Serializable]
public class StoryChoiceData
{
    public string text;
    public int weight;
    public int value;
    public string flag;
    public string marker;
}

[Serializable]
public class StoryMetaData
{
    public int maxWeight;
    public int trueEndingValue;
    public int nodeCount;
    public string verificationMethod;
}

[Serializable]
public class StoryNodeData
{
    public string id;
    public string dayLabel;
    public string speaker;
    public string text;
    public List<string> paragraphs = new List<string>();
    public string background;
    public string portrait;
    public List<StoryChoiceData> choices = new List<StoryChoiceData>();

    public string GetDisplayText()
    {
        return StoryTextComposer.ComposeText(text, paragraphs);
    }
}

[Serializable]
public class StoryEndingData
{
    public string key;
    public string title;
    public string text;
    public List<string> paragraphs = new List<string>();
    public string background;
    public string portrait;

    public string GetDisplayText()
    {
        return StoryTextComposer.ComposeText(text, paragraphs);
    }
}

[Serializable]
public class StoryDatabase
{
    public StoryMetaData meta = new StoryMetaData();
    public List<StoryNodeData> nodes = new List<StoryNodeData>();
    public List<StoryEndingData> endings = new List<StoryEndingData>();
}

public static class StoryTextComposer
{
    public static string ComposeText(string lead, List<string> paragraphs)
    {
        IEnumerable<string> blocks = new[] { lead }
            .Concat(paragraphs ?? new List<string>());

        return string.Join("\n\n", blocks.Where(entry => !string.IsNullOrWhiteSpace(entry)));
    }
}
