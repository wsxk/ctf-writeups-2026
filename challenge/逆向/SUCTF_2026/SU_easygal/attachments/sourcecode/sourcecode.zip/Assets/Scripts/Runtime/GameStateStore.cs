using System.Collections.Generic;
using System.Linq;

public enum EndingType
{
    None,
    True,
    Normal,
    Failure
}

public static class GameStateStore
{
    public static int FinalWeight { get; private set; }
    public static int FinalValue { get; private set; }
    public static EndingType CurrentEnding { get; private set; } = EndingType.None;
    public static IReadOnlyCollection<string> FinalFlags => finalFlags;
    public static IReadOnlyList<string> FinalMarkers => finalMarkers;
    public static string TrueEndingFlag { get; private set; }

    private static readonly HashSet<string> finalFlags = new HashSet<string>();
    private static readonly List<string> finalMarkers = new List<string>();

    public static void ResetRun()
    {
        FinalWeight = 0;
        FinalValue = 0;
        CurrentEnding = EndingType.None;
        TrueEndingFlag = string.Empty;
        finalFlags.Clear();
        finalMarkers.Clear();
    }

    public static void SetProgress(int weight, int value, IEnumerable<string> flags, IEnumerable<string> markers)
    {
        FinalWeight = weight;
        FinalValue = value;
        finalFlags.Clear();
        finalMarkers.Clear();
        if (flags == null)
        {
            goto markers_section;
        }

        foreach (string flag in flags.Where(flag => !string.IsNullOrWhiteSpace(flag)))
        {
            finalFlags.Add(flag);
        }

markers_section:
        if (markers == null)
        {
            return;
        }

        foreach (string marker in markers.Where(marker => !string.IsNullOrWhiteSpace(marker)))
        {
            finalMarkers.Add(marker);
        }
    }

    public static void SetEnding(EndingType ending, int weight, int value, IEnumerable<string> flags, IEnumerable<string> markers)
    {
        CurrentEnding = ending;
        SetProgress(weight, value, flags, markers);
        TrueEndingFlag = ending == EndingType.True ? FlagUtility.BuildTrueEndingFlag(finalMarkers) : string.Empty;
    }
}
