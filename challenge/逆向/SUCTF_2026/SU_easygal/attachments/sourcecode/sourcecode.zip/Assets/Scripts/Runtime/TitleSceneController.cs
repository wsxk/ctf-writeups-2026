using UnityEngine;
using UnityEngine.SceneManagement;

public class TitleSceneController : MonoBehaviour
{
    public void StartGame()
    {
        GameStateStore.ResetRun();
        SceneFlowController.OpenGame();
    }

    public void QuitGame()
    {
        Application.Quit();
    }
}
