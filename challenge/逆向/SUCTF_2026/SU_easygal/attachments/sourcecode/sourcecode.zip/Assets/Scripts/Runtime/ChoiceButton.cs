using System;
using UnityEngine;
using UnityEngine.UI;

[RequireComponent(typeof(Button))]
public class ChoiceButton : MonoBehaviour
{
    [SerializeField] private Button button;
    [SerializeField] private Text label;

    public void Configure(Button targetButton, Text targetLabel)
    {
        button = targetButton;
        label = targetLabel;
    }

    private void Reset()
    {
        button = GetComponent<Button>();
        label = GetComponentInChildren<Text>();
    }

    public void Bind(StoryChoiceData choice, Action<StoryChoiceData> onSelected)
    {
        if (button == null)
        {
            button = GetComponent<Button>();
        }

        if (label == null)
        {
            label = GetComponentInChildren<Text>();
        }

        if (label != null)
        {
            label.text = choice.text;
        }

        button.onClick.RemoveAllListeners();
        button.onClick.AddListener(() => onSelected?.Invoke(choice));
        button.interactable = true;
        gameObject.SetActive(true);
    }

    public void Hide()
    {
        if (button != null)
        {
            button.onClick.RemoveAllListeners();
        }

        gameObject.SetActive(false);
    }
}
