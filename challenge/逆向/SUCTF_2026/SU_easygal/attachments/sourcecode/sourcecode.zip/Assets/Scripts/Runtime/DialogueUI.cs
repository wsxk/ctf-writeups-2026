using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine;
using UnityEngine.UI;

public class DialogueUI : MonoBehaviour
{
    [Header("Artwork")]
    [SerializeField] private Image backgroundImage;
    [SerializeField] private Image portraitImage;

    [Header("Text")]
    [SerializeField] private Text dayLabel;
    [SerializeField] private Text progressLabel;
    [SerializeField] private Text speakerLabel;
    [SerializeField] private Text bodyLabel;
    [SerializeField] private Text weightLabel;
    [SerializeField] private Text valueLabel;

    [Header("Choices")]
    [SerializeField] private ChoiceButton[] choiceButtons;
    [SerializeField] private Button nextButton;
    [SerializeField] private Text nextButtonLabel;

    private readonly List<string> pages = new List<string>();
    private StoryNodeData currentNode;
    private Action<StoryChoiceData> currentChoiceHandler;
    private int currentPageIndex;

    public void Configure(
        Image targetBackgroundImage,
        Image targetPortraitImage,
        Text targetDayLabel,
        Text targetProgressLabel,
        Text targetSpeakerLabel,
        Text targetBodyLabel,
        Text targetWeightLabel,
        Text targetValueLabel,
        ChoiceButton[] targetChoiceButtons)
    {
        backgroundImage = targetBackgroundImage;
        portraitImage = targetPortraitImage;
        dayLabel = targetDayLabel;
        progressLabel = targetProgressLabel;
        speakerLabel = targetSpeakerLabel;
        bodyLabel = targetBodyLabel;
        weightLabel = targetWeightLabel;
        valueLabel = targetValueLabel;
        choiceButtons = targetChoiceButtons;
    }

    public void ConfigureNextButton(Button targetNextButton, Text targetNextButtonLabel)
    {
        nextButton = targetNextButton;
        nextButtonLabel = targetNextButtonLabel;

        if (nextButton != null)
        {
            nextButton.onClick.RemoveAllListeners();
            nextButton.onClick.AddListener(ShowNextPage);
        }
    }

    public void RenderNode(
        StoryNodeData node,
        int nodeIndex,
        int totalNodes,
        int currentWeight,
        int currentValue,
        Func<string, Sprite> spriteResolver,
        Action<StoryChoiceData> onChoiceSelected)
    {
        if (node == null)
        {
            return;
        }

        SetSprite(backgroundImage, node.background, spriteResolver);
        SetSprite(portraitImage, node.portrait, spriteResolver);

        if (dayLabel != null)
        {
            dayLabel.text = node.dayLabel;
        }

        if (progressLabel != null)
        {
            progressLabel.text = $"进度 {nodeIndex + 1}/{totalNodes}";
        }

        if (speakerLabel != null)
        {
            speakerLabel.text = node.speaker;
        }

        currentNode = node;
        currentChoiceHandler = onChoiceSelected;
        currentPageIndex = 0;
        BuildPages(node.GetDisplayText());
        RenderCurrentPage();

        if (weightLabel != null)
        {
            weightLabel.gameObject.SetActive(false);
        }

        if (valueLabel != null)
        {
            valueLabel.gameObject.SetActive(false);
        }

        UpdateChoiceVisibility();
    }

    private static void SetSprite(Image target, string resourceName, Func<string, Sprite> spriteResolver)
    {
        if (target == null)
        {
            return;
        }

        if (string.IsNullOrWhiteSpace(resourceName))
        {
            target.gameObject.SetActive(false);
            return;
        }

        Sprite sprite = spriteResolver?.Invoke(resourceName);
        target.sprite = sprite;
        target.gameObject.SetActive(sprite != null);
    }

    private static void ResetScrollPosition(Text targetLabel)
    {
        ScrollRect scrollRect = targetLabel == null ? null : targetLabel.GetComponentInParent<ScrollRect>();
        if (scrollRect == null)
        {
            return;
        }

        Canvas.ForceUpdateCanvases();
        scrollRect.verticalNormalizedPosition = 1f;
    }

    private void ShowNextPage()
    {
        if (currentPageIndex >= pages.Count - 1)
        {
            return;
        }

        currentPageIndex++;
        RenderCurrentPage();
        UpdateChoiceVisibility();
    }

    private void RenderCurrentPage()
    {
        if (bodyLabel != null)
        {
            bodyLabel.text = pages.Count == 0 ? string.Empty : pages[currentPageIndex];
            ResetScrollPosition(bodyLabel);
        }

        if (nextButton != null)
        {
            bool hasMorePages = currentPageIndex < pages.Count - 1;
            nextButton.gameObject.SetActive(hasMorePages);
        }

        if (nextButtonLabel != null)
        {
            nextButtonLabel.text = "下一句";
            nextButtonLabel.font = UIFontProvider.GetChineseFont();
            nextButtonLabel.fontSize = 24;
            nextButtonLabel.alignment = TextAnchor.MiddleCenter;
        }
    }

    private void UpdateChoiceVisibility()
    {
        if (choiceButtons == null)
        {
            return;
        }

        bool showChoices = currentPageIndex >= pages.Count - 1 && currentNode != null;
        for (int i = 0; i < choiceButtons.Length; i++)
        {
            if (!showChoices || i >= currentNode.choices.Count)
            {
                choiceButtons[i].Hide();
                continue;
            }

            choiceButtons[i].Bind(currentNode.choices[i], currentChoiceHandler);
        }
    }

    private void BuildPages(string displayText)
    {
        pages.Clear();
        List<string> fragments = SplitIntoFragments(displayText);
        const int maxCharsPerPage = 130;

        StringBuilder builder = new StringBuilder();
        foreach (string fragment in fragments)
        {
            string candidate = builder.Length == 0 ? fragment : $"{builder}\n\n{fragment}";
            if (builder.Length > 0 && candidate.Length > maxCharsPerPage)
            {
                pages.Add(builder.ToString());
                builder.Length = 0;
            }

            if (fragment.Length <= maxCharsPerPage)
            {
                if (builder.Length > 0)
                {
                    builder.Append("\n\n");
                }

                builder.Append(fragment);
                continue;
            }

            foreach (string chunk in SplitLongFragment(fragment, maxCharsPerPage))
            {
                if (builder.Length > 0)
                {
                    pages.Add(builder.ToString());
                    builder.Length = 0;
                }

                pages.Add(chunk);
            }
        }

        if (builder.Length > 0)
        {
            pages.Add(builder.ToString());
        }

        if (pages.Count == 0)
        {
            pages.Add(string.Empty);
        }
    }

    private static List<string> SplitIntoFragments(string displayText)
    {
        List<string> fragments = new List<string>();
        string[] paragraphs = displayText.Split(new[] { "\n\n" }, StringSplitOptions.RemoveEmptyEntries);
        foreach (string paragraph in paragraphs)
        {
            string trimmed = paragraph.Trim();
            if (string.IsNullOrWhiteSpace(trimmed))
            {
                continue;
            }

            fragments.Add(trimmed);
        }

        return fragments;
    }

    private static IEnumerable<string> SplitLongFragment(string fragment, int maxCharsPerPage)
    {
        List<string> chunks = new List<string>();
        StringBuilder sentenceBuilder = new StringBuilder();
        StringBuilder pageBuilder = new StringBuilder();

        for (int i = 0; i < fragment.Length; i++)
        {
            char c = fragment[i];
            sentenceBuilder.Append(c);
            if (!IsSentenceBoundary(c, i, fragment))
            {
                continue;
            }

            AppendSentence(sentenceBuilder.ToString(), maxCharsPerPage, pageBuilder, chunks);
            sentenceBuilder.Length = 0;
        }

        if (sentenceBuilder.Length > 0)
        {
            AppendSentence(sentenceBuilder.ToString(), maxCharsPerPage, pageBuilder, chunks);
        }

        if (pageBuilder.Length > 0)
        {
            chunks.Add(pageBuilder.ToString());
        }

        return chunks;
    }

    private static void AppendSentence(string sentence, int maxCharsPerPage, StringBuilder pageBuilder, List<string> chunks)
    {
        string trimmed = sentence.Trim();
        if (string.IsNullOrWhiteSpace(trimmed))
        {
            return;
        }

        string candidate = pageBuilder.Length == 0 ? trimmed : pageBuilder + trimmed;
        if (pageBuilder.Length > 0 && candidate.Length > maxCharsPerPage)
        {
            chunks.Add(pageBuilder.ToString().Trim());
            pageBuilder.Length = 0;
        }

        if (trimmed.Length <= maxCharsPerPage)
        {
            pageBuilder.Append(trimmed);
            return;
        }

        int start = 0;
        while (start < trimmed.Length)
        {
            int length = Mathf.Min(maxCharsPerPage, trimmed.Length - start);
            chunks.Add(trimmed.Substring(start, length));
            start += length;
        }
    }

    private static bool IsSentenceBoundary(char c, int index, string source)
    {
        if (c == '。' || c == '！' || c == '？' || c == '!' || c == '?' || c == '.' || c == ';' || c == '；')
        {
            return true;
        }

        return c == '\n' && index + 1 < source.Length && source[index + 1] == '\n';
    }
}
