using UnityEngine;

public static class UIFontProvider
{
    private static Font cachedFont;

    public static Font GetChineseFont()
    {
        if (cachedFont != null)
        {
            return cachedFont;
        }

        string[] fontCandidates =
        {
            "Microsoft YaHei UI",
            "Microsoft YaHei",
            "DengXian",
            "SimHei",
            "SimSun",
            "Arial Unicode MS",
            "Arial"
        };

        cachedFont = Font.CreateDynamicFontFromOSFont(fontCandidates, 32);
        return cachedFont;
    }
}
