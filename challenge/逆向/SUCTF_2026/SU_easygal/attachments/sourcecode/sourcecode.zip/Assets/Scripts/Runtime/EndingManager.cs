using System.Linq;
using UnityEngine;
using UnityEngine.UI;

public class EndingManager : MonoBehaviour
{
    [SerializeField] private Image backgroundImage;
    [SerializeField] private Image portraitImage;
    [SerializeField] private Text titleLabel;
    [SerializeField] private Text bodyLabel;
    [SerializeField] private Text summaryLabel;

    public void Configure(
        Image targetBackgroundImage,
        Image targetPortraitImage,
        Text targetTitleLabel,
        Text targetBodyLabel,
        Text targetSummaryLabel)
    {
        backgroundImage = targetBackgroundImage;
        portraitImage = targetPortraitImage;
        titleLabel = targetTitleLabel;
        bodyLabel = targetBodyLabel;
        summaryLabel = targetSummaryLabel;
    }

    private void Start()
    {
        StoryDatabase database = LoadStory();
        StoryEndingData endingData = FindEnding(database, GameStateStore.CurrentEnding);

        if (endingData == null)
        {
            if (titleLabel != null)
            {
                titleLabel.text = "Ending Data Missing";
            }

            if (bodyLabel != null)
            {
                bodyLabel.text = "Open the game from TitleScene so the ending state can be created.";
            }

            return;
        }

        ApplyArt(backgroundImage, endingData.background);
        ApplyArt(portraitImage, endingData.portrait);

        if (titleLabel != null)
        {
            titleLabel.text = endingData.title;
        }

        if (bodyLabel != null)
        {
            bodyLabel.text = endingData.GetDisplayText();
            ResetScrollPosition(bodyLabel);
        }

        if (summaryLabel != null)
        {
            if (GameStateStore.CurrentEnding == EndingType.True)
            {
                summaryLabel.text = GameStateStore.TrueEndingFlag;
            }
            else
            {
                summaryLabel.text = string.Empty;
            }
        }
    }

    public void RestartGame()
    {
        GameStateStore.ResetRun();
        SceneFlowController.OpenGame();
    }

    public void ReturnToTitle()
    {
        GameStateStore.ResetRun();
        SceneFlowController.OpenTitle();
    }

    private static StoryDatabase LoadStory()
    {
        TextAsset textAsset = Resources.Load<TextAsset>(GameConfig.StoryResourcePath);
        return textAsset == null ? null : JsonUtility.FromJson<StoryDatabase>(textAsset.text);
    }

    private static StoryEndingData FindEnding(StoryDatabase database, EndingType endingType)
    {
        if (database == null || database.endings == null)
        {
            return null;
        }

        string key = endingType.ToString();
        return database.endings.FirstOrDefault(entry => entry.key == key);
    }

    private static void ApplyArt(Image target, string resourceName)
    {
        if (target == null)
        {
            return;
        }

        if (string.IsNullOrWhiteSpace(resourceName))
        {
            target.gameObject.SetActive(false);
            return;
        }

        Sprite sprite = Resources.Load<Sprite>($"Art/{resourceName}");
        if (sprite == null)
        {
            sprite = GeneratedArtLibrary.Get(resourceName);
        }
        target.sprite = sprite;
        target.gameObject.SetActive(sprite != null);
    }

    private static void ResetScrollPosition(Text targetLabel)
    {
        ScrollRect scrollRect = targetLabel == null ? null : targetLabel.GetComponentInParent<ScrollRect>();
        if (scrollRect == null)
        {
            return;
        }

        Canvas.ForceUpdateCanvases();
        scrollRect.verticalNormalizedPosition = 1f;
    }
}
