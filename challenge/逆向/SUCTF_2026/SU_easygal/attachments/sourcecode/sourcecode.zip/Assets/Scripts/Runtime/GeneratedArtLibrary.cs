using System.Collections.Generic;
using UnityEngine;

public static class GeneratedArtLibrary
{
    private static readonly Dictionary<string, Sprite> cache = new Dictionary<string, Sprite>();

    public static Sprite Get(string key)
    {
        if (string.IsNullOrWhiteSpace(key))
        {
            return null;
        }

        if (cache.TryGetValue(key, out Sprite sprite))
        {
            return sprite;
        }

        Texture2D texture = CreateTexture(key);
        if (texture == null)
        {
            return null;
        }

        texture.wrapMode = TextureWrapMode.Clamp;
        texture.filterMode = FilterMode.Bilinear;
        sprite = Sprite.Create(texture, new Rect(0, 0, texture.width, texture.height), new Vector2(0.5f, 0.5f), 100f);
        sprite.name = key;
        cache[key] = sprite;
        return sprite;
    }

    private static Texture2D CreateTexture(string key)
    {
        switch (key)
        {
            case "bg_title":
                return BuildBackground(1920, 1080, new Color(0.16f, 0.2f, 0.31f), new Color(0.93f, 0.76f, 0.72f), BackgroundDecoration.Title);
            case "bg_campus":
                return BuildBackground(1920, 1080, new Color(0.93f, 0.87f, 0.93f), new Color(0.99f, 0.95f, 0.87f), BackgroundDecoration.Campus);
            case "bg_library":
                return BuildBackground(1920, 1080, new Color(0.87f, 0.83f, 0.74f), new Color(0.75f, 0.68f, 0.62f), BackgroundDecoration.Library);
            case "bg_rain":
                return BuildBackground(1920, 1080, new Color(0.17f, 0.24f, 0.37f), new Color(0.45f, 0.5f, 0.58f), BackgroundDecoration.Rain);
            case "bg_studio":
                return BuildBackground(1920, 1080, new Color(0.92f, 0.88f, 0.82f), new Color(0.79f, 0.72f, 0.69f), BackgroundDecoration.Studio);
            case "bg_rooftop":
                return BuildBackground(1920, 1080, new Color(0.64f, 0.8f, 0.94f), new Color(0.9f, 0.95f, 0.99f), BackgroundDecoration.Rooftop);
            case "bg_gallery":
                return BuildBackground(1920, 1080, new Color(0.95f, 0.95f, 0.96f), new Color(0.84f, 0.85f, 0.89f), BackgroundDecoration.Gallery);
            case "bg_sakura":
                return BuildBackground(1920, 1080, new Color(0.85f, 0.81f, 0.95f), new Color(1f, 0.93f, 0.88f), BackgroundDecoration.Sakura);
            case "portrait_kanna_calm":
                return BuildPortrait(900, 1400, new Color(0.19f, 0.22f, 0.34f), new Color(0.82f, 0.9f, 0.95f), FaceMood.Calm);
            case "portrait_kanna_worried":
                return BuildPortrait(900, 1400, new Color(0.22f, 0.25f, 0.4f), new Color(0.76f, 0.85f, 0.95f), FaceMood.Worried);
            case "portrait_kanna_soft":
                return BuildPortrait(900, 1400, new Color(0.2f, 0.19f, 0.33f), new Color(0.94f, 0.83f, 0.87f), FaceMood.Soft);
            default:
                return null;
        }
    }

    private static Texture2D BuildBackground(int width, int height, Color top, Color bottom, BackgroundDecoration decoration)
    {
        Texture2D texture = new Texture2D(width, height, TextureFormat.RGBA32, false);
        for (int y = 0; y < height; y++)
        {
            Color row = Color.Lerp(top, bottom, y / (float)(height - 1));
            for (int x = 0; x < width; x++)
            {
                texture.SetPixel(x, y, row);
            }
        }

        switch (decoration)
        {
            case BackgroundDecoration.Title:
                DrawCircle(texture, 1480, 240, 160, new Color(1f, 0.96f, 0.85f, 0.75f));
                for (int i = 0; i < 18; i++)
                {
                    DrawPetal(texture, 120 + i * 95, 180 + (i % 5) * 45, 26 + (i % 3) * 8, new Color(1f, 0.87f, 0.92f, 0.58f));
                }
                break;
            case BackgroundDecoration.Campus:
                DrawRect(texture, 0, 760, width, 320, new Color(0.74f, 0.81f, 0.73f));
                DrawRect(texture, 220, 250, 360, 530, new Color(0.9f, 0.91f, 0.93f));
                DrawRect(texture, 620, 320, 280, 460, new Color(0.84f, 0.86f, 0.9f));
                DrawTree(texture, 1460, 630, new Color(0.65f, 0.4f, 0.25f), new Color(0.97f, 0.83f, 0.89f));
                DrawTree(texture, 1680, 590, new Color(0.62f, 0.38f, 0.22f), new Color(0.96f, 0.79f, 0.86f));
                break;
            case BackgroundDecoration.Library:
                DrawRect(texture, 0, 720, width, 360, new Color(0.73f, 0.66f, 0.59f));
                for (int x = 130; x < width - 140; x += 250)
                {
                    DrawRect(texture, x, 220, 180, 680, new Color(0.53f, 0.34f, 0.23f));
                    for (int y = 260; y < 860; y += 130)
                    {
                        DrawRect(texture, x + 20, y, 140, 12, new Color(0.3f, 0.2f, 0.12f));
                    }
                }
                break;
            case BackgroundDecoration.Rain:
                DrawRect(texture, 0, 760, width, 320, new Color(0.22f, 0.27f, 0.33f));
                DrawRect(texture, 260, 360, 420, 420, new Color(0.57f, 0.63f, 0.69f));
                DrawRect(texture, 760, 320, 280, 460, new Color(0.5f, 0.56f, 0.64f));
                for (int x = -200; x < width + 200; x += 30)
                {
                    DrawDiagonal(texture, x, 0, 85, 240, new Color(0.84f, 0.92f, 1f, 0.22f));
                }
                break;
            case BackgroundDecoration.Studio:
                DrawRect(texture, 0, 780, width, 300, new Color(0.69f, 0.63f, 0.58f));
                DrawRect(texture, 240, 240, 420, 560, new Color(0.96f, 0.95f, 0.94f));
                DrawRect(texture, 280, 280, 340, 460, new Color(1f, 1f, 1f));
                break;
            case BackgroundDecoration.Rooftop:
                DrawRect(texture, 0, 700, width, 380, new Color(0.76f, 0.79f, 0.84f));
                DrawRect(texture, 0, 560, width, 44, new Color(0.46f, 0.5f, 0.58f));
                DrawCloud(texture, 420, 220, 110, new Color(1f, 1f, 1f, 0.72f));
                DrawCloud(texture, 1320, 260, 130, new Color(1f, 1f, 1f, 0.68f));
                break;
            case BackgroundDecoration.Gallery:
                DrawRect(texture, 0, 760, width, 320, new Color(0.76f, 0.78f, 0.82f));
                for (int x = 180; x < width - 240; x += 340)
                {
                    DrawRect(texture, x, 280, 220, 320, Color.white);
                    DrawRect(texture, x + 22, 302, 176, 276, new Color(0.86f, 0.89f, 0.95f));
                }
                break;
            case BackgroundDecoration.Sakura:
                DrawRect(texture, 0, 760, width, 320, new Color(0.77f, 0.86f, 0.78f));
                DrawTree(texture, 320, 440, new Color(0.57f, 0.34f, 0.22f), new Color(0.98f, 0.82f, 0.88f));
                DrawTree(texture, 1560, 420, new Color(0.56f, 0.31f, 0.22f), new Color(0.99f, 0.85f, 0.9f));
                for (int i = 0; i < 18; i++)
                {
                    DrawPetal(texture, 180 + i * 92, 200 + (i % 5) * 42, 20 + (i % 4) * 6, new Color(1f, 0.88f, 0.92f, 0.58f));
                }
                break;
        }

        texture.Apply();
        return texture;
    }

    private static Texture2D BuildPortrait(int width, int height, Color hairColor, Color clothColor, FaceMood mood)
    {
        Texture2D texture = new Texture2D(width, height, TextureFormat.RGBA32, false);
        for (int y = 0; y < height; y++)
        {
            for (int x = 0; x < width; x++)
            {
                texture.SetPixel(x, y, Color.clear);
            }
        }

        DrawRect(texture, 0, 880, width, 520, new Color(1f, 0.93f, 0.95f, 0.18f));
        DrawCircle(texture, width / 2, 480, 200, new Color(0.97f, 0.88f, 0.82f));
        DrawRect(texture, 210, 700, 480, 520, clothColor);
        DrawCircle(texture, 210, 980, 230, clothColor);
        DrawCircle(texture, 690, 980, 230, clothColor);

        DrawCircle(texture, width / 2, 430, 255, hairColor);
        DrawCircle(texture, 300, 580, 150, hairColor);
        DrawCircle(texture, 600, 580, 150, hairColor);
        DrawRect(texture, 250, 400, 400, 280, hairColor);

        int leftEyeY = mood == FaceMood.Worried ? 500 : 515;
        int rightEyeY = mood == FaceMood.Soft ? 520 : leftEyeY;
        DrawRect(texture, 360, leftEyeY, 64, 8, new Color(0.18f, 0.2f, 0.26f));
        DrawRect(texture, 476, rightEyeY, 64, 8, new Color(0.18f, 0.2f, 0.26f));
        if (mood == FaceMood.Worried)
        {
            DrawRect(texture, 356, 478, 60, 6, new Color(0.18f, 0.2f, 0.26f));
            DrawRect(texture, 484, 470, 60, 6, new Color(0.18f, 0.2f, 0.26f));
        }

        if (mood == FaceMood.Soft)
        {
            DrawRect(texture, 410, 625, 80, 6, new Color(0.62f, 0.34f, 0.39f));
            DrawRect(texture, 402, 619, 16, 6, new Color(0.62f, 0.34f, 0.39f));
            DrawRect(texture, 482, 619, 16, 6, new Color(0.62f, 0.34f, 0.39f));
        }
        else
        {
            DrawRect(texture, 414, 626, 72, 4, new Color(0.62f, 0.34f, 0.39f));
        }

        texture.Apply();
        return texture;
    }

    private static void DrawRect(Texture2D texture, int x, int y, int width, int height, Color color)
    {
        for (int py = Mathf.Max(0, y); py < Mathf.Min(texture.height, y + height); py++)
        {
            for (int px = Mathf.Max(0, x); px < Mathf.Min(texture.width, x + width); px++)
            {
                Blend(texture, px, py, color);
            }
        }
    }

    private static void DrawCircle(Texture2D texture, int cx, int cy, int radius, Color color)
    {
        int r2 = radius * radius;
        for (int y = Mathf.Max(0, cy - radius); y <= Mathf.Min(texture.height - 1, cy + radius); y++)
        {
            int dy = y - cy;
            for (int x = Mathf.Max(0, cx - radius); x <= Mathf.Min(texture.width - 1, cx + radius); x++)
            {
                int dx = x - cx;
                if (dx * dx + dy * dy <= r2)
                {
                    Blend(texture, x, y, color);
                }
            }
        }
    }

    private static void DrawPetal(Texture2D texture, int centerX, int centerY, int size, Color color)
    {
        DrawCircle(texture, centerX - size / 3, centerY, size / 2, color);
        DrawCircle(texture, centerX + size / 3, centerY, size / 2, color);
        DrawCircle(texture, centerX, centerY - size / 3, size / 2, color);
    }

    private static void DrawTree(Texture2D texture, int trunkX, int trunkTop, Color trunkColor, Color blossomColor)
    {
        DrawRect(texture, trunkX, trunkTop, 54, 320, trunkColor);
        DrawCircle(texture, trunkX + 20, trunkTop + 30, 130, blossomColor);
        DrawCircle(texture, trunkX + 90, trunkTop, 120, blossomColor);
        DrawCircle(texture, trunkX + 40, trunkTop - 70, 110, blossomColor);
    }

    private static void DrawCloud(Texture2D texture, int centerX, int centerY, int radius, Color color)
    {
        DrawCircle(texture, centerX - radius / 2, centerY, radius / 2, color);
        DrawCircle(texture, centerX, centerY - radius / 4, radius / 2, color);
        DrawCircle(texture, centerX + radius / 2, centerY, radius / 2, color);
    }

    private static void DrawDiagonal(Texture2D texture, int startX, int startY, int deltaX, int deltaY, Color color)
    {
        for (int i = 0; i < 220; i++)
        {
            int x = startX + i * deltaX / 220;
            int y = startY + i * deltaY / 220;
            Blend(texture, x, y, color);
            Blend(texture, x + 1, y, color);
        }
    }

    private static void Blend(Texture2D texture, int x, int y, Color color)
    {
        if (x < 0 || y < 0 || x >= texture.width || y >= texture.height)
        {
            return;
        }

        Color bg = texture.GetPixel(x, y);
        float alpha = color.a + bg.a * (1f - color.a);
        if (alpha <= 0f)
        {
            texture.SetPixel(x, y, Color.clear);
            return;
        }

        Color blended = new Color(
            (color.r * color.a + bg.r * bg.a * (1f - color.a)) / alpha,
            (color.g * color.a + bg.g * bg.a * (1f - color.a)) / alpha,
            (color.b * color.a + bg.b * bg.a * (1f - color.a)) / alpha,
            alpha);
        texture.SetPixel(x, y, blended);
    }

    private enum BackgroundDecoration
    {
        Title,
        Campus,
        Library,
        Rain,
        Studio,
        Rooftop,
        Gallery,
        Sakura
    }

    private enum FaceMood
    {
        Calm,
        Worried,
        Soft
    }
}
