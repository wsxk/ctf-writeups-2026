using System.IO;
using System.Reflection;
using TMPro;
using UnityEditor;
using UnityEditor.Events;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public static class EsaygalProjectBuilder
{
    private const string ArtDirectory = "Assets/Resources/Art";
    private const string ScenesDirectory = "Assets/Scenes";

    [MenuItem("Tools/Esaygal/Build All")]
    public static void BuildAll()
    {
        EnsureDirectory(ArtDirectory);
        EnsureDirectory(ScenesDirectory);

        GenerateArt();
        AssetDatabase.Refresh();

        CreateTitleScene();
        CreateGameScene();
        CreateEndingScene();
        ConfigureBuildSettings();

        AssetDatabase.SaveAssets();
        AssetDatabase.Refresh();
        EditorUtility.DisplayDialog("Esaygal", "Generated art, scenes, and build settings.", "OK");
    }

    [MenuItem("Tools/Esaygal/Generate Art Only")]
    public static void GenerateArtOnly()
    {
        EnsureDirectory(ArtDirectory);
        GenerateArt();
        AssetDatabase.SaveAssets();
        AssetDatabase.Refresh();
    }

    private static void GenerateArt()
    {
        WriteSpriteTexture("bg_title.png", 1920, 1080, texture => FillTitleBackground(texture));
        WriteSpriteTexture("bg_campus.png", 1920, 1080, texture => FillCampusBackground(texture, new Color(0.92f, 0.86f, 0.92f), new Color(0.99f, 0.95f, 0.85f)));
        WriteSpriteTexture("bg_library.png", 1920, 1080, texture => FillInteriorBackground(texture, new Color(0.87f, 0.83f, 0.74f), new Color(0.54f, 0.35f, 0.23f), new Color(0.72f, 0.56f, 0.36f)));
        WriteSpriteTexture("bg_rain.png", 1920, 1080, texture => FillRainBackground(texture));
        WriteSpriteTexture("bg_studio.png", 1920, 1080, texture => FillStudioBackground(texture));
        WriteSpriteTexture("bg_rooftop.png", 1920, 1080, texture => FillRooftopBackground(texture));
        WriteSpriteTexture("bg_gallery.png", 1920, 1080, texture => FillGalleryBackground(texture));
        WriteSpriteTexture("bg_sakura.png", 1920, 1080, texture => FillSakuraBackground(texture));

        WriteSpriteTexture("portrait_kanna_calm.png", 1024, 1536, texture => FillPortrait(texture, new Color(0.18f, 0.22f, 0.34f), new Color(0.83f, 0.9f, 0.95f), false, false));
        WriteSpriteTexture("portrait_kanna_worried.png", 1024, 1536, texture => FillPortrait(texture, new Color(0.21f, 0.24f, 0.4f), new Color(0.75f, 0.85f, 0.95f), true, false));
        WriteSpriteTexture("portrait_kanna_soft.png", 1024, 1536, texture => FillPortrait(texture, new Color(0.2f, 0.19f, 0.33f), new Color(0.93f, 0.82f, 0.86f), false, true));
    }

    private static void CreateTitleScene()
    {
        Scene scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
        CreateCamera();
        CreateEventSystem();

        Canvas canvas = CreateCanvas("TitleCanvas");
        Image background = CreateImage("Background", canvas.transform, anchorMin: Vector2.zero, anchorMax: Vector2.one, offsetMin: Vector2.zero, offsetMax: Vector2.zero);
        background.sprite = LoadSprite("bg_title");
        background.preserveAspect = true;

        Image overlay = CreateImage("Overlay", canvas.transform, anchorMin: Vector2.zero, anchorMax: Vector2.one, offsetMin: Vector2.zero, offsetMax: Vector2.zero);
        overlay.color = new Color(0.07f, 0.08f, 0.12f, 0.34f);

        Image portrait = CreateImage("Portrait", canvas.transform, new Vector2(0f, 0f), new Vector2(0.46f, 1f), new Vector2(0f, 0f), new Vector2(0f, 0f));
        portrait.sprite = LoadSprite("portrait_kanna_soft");
        portrait.preserveAspect = true;

        RectTransform panel = CreatePanel("TitlePanel", canvas.transform, new Vector2(0.48f, 0.14f), new Vector2(0.94f, 0.86f), new Color(0.1f, 0.11f, 0.16f, 0.76f));
        panel.offsetMin = new Vector2(0f, 0f);
        panel.offsetMax = new Vector2(0f, 0f);

        CreateText("Eyebrow", panel, "A Minimal Visual Novel Puzzle", 30, new Vector2(0f, 0.82f), new Vector2(1f, 0.95f), new Color(0.96f, 0.8f, 0.82f), FontStyles.SmallCaps);
        CreateText("Title", panel, "Esaygal", 86, new Vector2(0f, 0.56f), new Vector2(1f, 0.82f), Color.white, FontStyles.Bold);
        CreateText("Subtitle", panel, "Use your limited weight on the only choices that truly matter.", 34, new Vector2(0.06f, 0.4f), new Vector2(0.94f, 0.58f), new Color(0.89f, 0.91f, 0.94f), FontStyles.Normal);
        CreateText("Detail", panel, "60 linear story nodes\nWeight is evaluated only at the end\nThe true ending is guaranteed by weight/value only\nUse DP to verify the unique optimum", 28, new Vector2(0.06f, 0.12f), new Vector2(0.94f, 0.42f), new Color(0.76f, 0.8f, 0.86f), FontStyles.Normal);

        TitleSceneController controller = panel.gameObject.AddComponent<TitleSceneController>();
        Button startButton = CreateButton("StartButton", panel, "Start", new Vector2(0.08f, 0.02f), new Vector2(0.46f, 0.14f), new Color(0.91f, 0.49f, 0.57f));
        Button quitButton = CreateButton("QuitButton", panel, "Quit", new Vector2(0.54f, 0.02f), new Vector2(0.92f, 0.14f), new Color(0.23f, 0.29f, 0.39f));

        UnityEventTools.AddPersistentListener(startButton.onClick, controller.StartGame);
        UnityEventTools.AddPersistentListener(quitButton.onClick, controller.QuitGame);

        EditorSceneManager.SaveScene(scene, Path.Combine(ScenesDirectory, "TitleScene.unity"));
    }

    private static void CreateGameScene()
    {
        Scene scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
        CreateCamera();
        CreateEventSystem();

        Canvas canvas = CreateCanvas("GameCanvas");
        Image background = CreateImage("Background", canvas.transform, Vector2.zero, Vector2.one, Vector2.zero, Vector2.zero);
        background.sprite = LoadSprite("bg_campus");
        background.preserveAspect = true;

        Image tint = CreateImage("Tint", canvas.transform, Vector2.zero, Vector2.one, Vector2.zero, Vector2.zero);
        tint.color = new Color(0.04f, 0.05f, 0.09f, 0.12f);

        Image portrait = CreateImage("Portrait", canvas.transform, new Vector2(0.56f, 0.08f), new Vector2(0.97f, 0.92f), Vector2.zero, Vector2.zero);
        portrait.sprite = LoadSprite("portrait_kanna_calm");
        portrait.preserveAspect = true;

        RectTransform topBar = CreatePanel("TopBar", canvas.transform, new Vector2(0.03f, 0.9f), new Vector2(0.97f, 0.98f), new Color(0.08f, 0.1f, 0.16f, 0.84f));
        TMP_Text dayLabel = CreateText("DayLabel", topBar, "Gate", 28, new Vector2(0.02f, 0.14f), new Vector2(0.22f, 0.86f), Color.white, FontStyles.Bold);
        TMP_Text progressLabel = CreateText("ProgressLabel", topBar, "Progress 1/60", 26, new Vector2(0.24f, 0.14f), new Vector2(0.48f, 0.86f), new Color(0.83f, 0.86f, 0.93f), FontStyles.Normal);
        TMP_Text weightLabel = CreateText("WeightLabel", topBar, "Weight 0/132", 26, new Vector2(0.62f, 0.14f), new Vector2(0.78f, 0.86f), new Color(1f, 0.89f, 0.9f), FontStyles.Bold);
        TMP_Text valueLabel = CreateText("ValueLabel", topBar, "Value 0/322", 26, new Vector2(0.8f, 0.14f), new Vector2(0.98f, 0.86f), new Color(0.9f, 0.94f, 1f), FontStyles.Bold);

        RectTransform dialoguePanel = CreatePanel("DialoguePanel", canvas.transform, new Vector2(0.03f, 0.04f), new Vector2(0.97f, 0.4f), new Color(0.08f, 0.1f, 0.15f, 0.9f));
        TMP_Text speakerLabel = CreateText("SpeakerLabel", dialoguePanel, "旁白", 32, new Vector2(0.03f, 0.76f), new Vector2(0.34f, 0.94f), new Color(0.97f, 0.79f, 0.82f), FontStyles.Bold);
        TMP_Text bodyLabel = CreateText("BodyLabel", dialoguePanel, string.Empty, 28, new Vector2(0.03f, 0.26f), new Vector2(0.62f, 0.74f), Color.white, FontStyles.Normal);
        bodyLabel.enableWordWrapping = true;

        RectTransform choiceRoot = CreatePanel("ChoiceRoot", dialoguePanel, new Vector2(0.66f, 0.1f), new Vector2(0.97f, 0.9f), new Color(0.15f, 0.16f, 0.23f, 0.56f));
        ChoiceButton[] choiceButtons = new ChoiceButton[2];
        choiceButtons[0] = CreateChoiceButton("ChoiceA", choiceRoot, new Vector2(0.06f, 0.54f), new Vector2(0.94f, 0.94f), new Color(0.88f, 0.54f, 0.58f));
        choiceButtons[1] = CreateChoiceButton("ChoiceB", choiceRoot, new Vector2(0.06f, 0.06f), new Vector2(0.94f, 0.46f), new Color(0.28f, 0.39f, 0.53f));

        TMP_Text errorLabel = CreateText("ErrorLabel", canvas.transform as RectTransform, string.Empty, 26, new Vector2(0.1f, 0.46f), new Vector2(0.9f, 0.54f), new Color(1f, 0.78f, 0.78f), FontStyles.Bold);
        errorLabel.gameObject.SetActive(false);

        DialogueUI dialogueUI = canvas.gameObject.AddComponent<DialogueUI>();
        AssignField(dialogueUI, "backgroundImage", background);
        AssignField(dialogueUI, "portraitImage", portrait);
        AssignField(dialogueUI, "dayLabel", dayLabel);
        AssignField(dialogueUI, "progressLabel", progressLabel);
        AssignField(dialogueUI, "speakerLabel", speakerLabel);
        AssignField(dialogueUI, "bodyLabel", bodyLabel);
        AssignField(dialogueUI, "weightLabel", weightLabel);
        AssignField(dialogueUI, "valueLabel", valueLabel);
        AssignField(dialogueUI, "choiceButtons", choiceButtons);

        GameManager manager = canvas.gameObject.AddComponent<GameManager>();
        AssignField(manager, "dialogueUI", dialogueUI);
        AssignField(manager, "errorLabel", errorLabel);

        EditorSceneManager.SaveScene(scene, Path.Combine(ScenesDirectory, "GameScene.unity"));
    }

    private static void CreateEndingScene()
    {
        Scene scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
        CreateCamera();
        CreateEventSystem();

        Canvas canvas = CreateCanvas("EndingCanvas");
        Image background = CreateImage("Background", canvas.transform, Vector2.zero, Vector2.one, Vector2.zero, Vector2.zero);
        background.sprite = LoadSprite("bg_sakura");
        background.preserveAspect = true;

        Image overlay = CreateImage("Overlay", canvas.transform, Vector2.zero, Vector2.one, Vector2.zero, Vector2.zero);
        overlay.color = new Color(0.08f, 0.08f, 0.13f, 0.38f);

        Image portrait = CreateImage("Portrait", canvas.transform, new Vector2(0.05f, 0.12f), new Vector2(0.45f, 0.92f), Vector2.zero, Vector2.zero);
        portrait.sprite = LoadSprite("portrait_kanna_soft");
        portrait.preserveAspect = true;

        RectTransform panel = CreatePanel("EndingPanel", canvas.transform, new Vector2(0.46f, 0.1f), new Vector2(0.95f, 0.9f), new Color(0.1f, 0.1f, 0.15f, 0.82f));
        TMP_Text titleLabel = CreateText("TitleLabel", panel, "Ending", 54, new Vector2(0.06f, 0.78f), new Vector2(0.94f, 0.94f), Color.white, FontStyles.Bold);
        TMP_Text bodyLabel = CreateText("BodyLabel", panel, string.Empty, 28, new Vector2(0.06f, 0.32f), new Vector2(0.94f, 0.76f), new Color(0.94f, 0.95f, 0.98f), FontStyles.Normal);
        bodyLabel.enableWordWrapping = true;
        TMP_Text summaryLabel = CreateText("SummaryLabel", panel, string.Empty, 22, new Vector2(0.06f, 0.16f), new Vector2(0.94f, 0.3f), new Color(0.81f, 0.85f, 0.91f), FontStyles.Normal);

        EndingManager manager = panel.gameObject.AddComponent<EndingManager>();
        AssignField(manager, "backgroundImage", background);
        AssignField(manager, "portraitImage", portrait);
        AssignField(manager, "titleLabel", titleLabel);
        AssignField(manager, "bodyLabel", bodyLabel);
        AssignField(manager, "summaryLabel", summaryLabel);

        Button restartButton = CreateButton("RestartButton", panel, "Play Again", new Vector2(0.06f, 0.03f), new Vector2(0.45f, 0.12f), new Color(0.9f, 0.51f, 0.58f));
        Button titleButton = CreateButton("TitleButton", panel, "Back To Title", new Vector2(0.55f, 0.03f), new Vector2(0.94f, 0.12f), new Color(0.29f, 0.37f, 0.51f));

        UnityEventTools.AddPersistentListener(restartButton.onClick, manager.RestartGame);
        UnityEventTools.AddPersistentListener(titleButton.onClick, manager.ReturnToTitle);

        EditorSceneManager.SaveScene(scene, Path.Combine(ScenesDirectory, "EndingScene.unity"));
    }

    private static void ConfigureBuildSettings()
    {
        EditorBuildSettings.scenes = new[]
        {
            new EditorBuildSettingsScene(Path.Combine(ScenesDirectory, "TitleScene.unity"), true),
            new EditorBuildSettingsScene(Path.Combine(ScenesDirectory, "GameScene.unity"), true),
            new EditorBuildSettingsScene(Path.Combine(ScenesDirectory, "EndingScene.unity"), true)
        };
    }

    private static void CreateCamera()
    {
        GameObject cameraObject = new GameObject("Main Camera");
        Camera camera = cameraObject.AddComponent<Camera>();
        camera.clearFlags = CameraClearFlags.SolidColor;
        camera.backgroundColor = new Color(0.08f, 0.09f, 0.14f);
        camera.orthographic = true;
        cameraObject.tag = "MainCamera";
        cameraObject.AddComponent<AudioListener>();
    }

    private static void CreateEventSystem()
    {
        GameObject eventSystem = new GameObject("EventSystem");
        eventSystem.AddComponent<EventSystem>();
        eventSystem.AddComponent<StandaloneInputModule>();
    }

    private static Canvas CreateCanvas(string name)
    {
        GameObject canvasObject = new GameObject(name, typeof(Canvas), typeof(CanvasScaler), typeof(GraphicRaycaster));
        Canvas canvas = canvasObject.GetComponent<Canvas>();
        canvas.renderMode = RenderMode.ScreenSpaceOverlay;

        CanvasScaler scaler = canvasObject.GetComponent<CanvasScaler>();
        scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        scaler.referenceResolution = new Vector2(1920f, 1080f);
        scaler.matchWidthOrHeight = 0.5f;

        return canvas;
    }

    private static RectTransform CreatePanel(string name, Transform parent, Vector2 anchorMin, Vector2 anchorMax, Color color)
    {
        Image image = CreateImage(name, parent, anchorMin, anchorMax, Vector2.zero, Vector2.zero);
        image.color = color;
        return image.rectTransform;
    }

    private static Image CreateImage(string name, Transform parent, Vector2 anchorMin, Vector2 anchorMax, Vector2 offsetMin, Vector2 offsetMax)
    {
        GameObject gameObject = new GameObject(name, typeof(RectTransform), typeof(Image));
        gameObject.transform.SetParent(parent, false);
        RectTransform rect = gameObject.GetComponent<RectTransform>();
        rect.anchorMin = anchorMin;
        rect.anchorMax = anchorMax;
        rect.offsetMin = offsetMin;
        rect.offsetMax = offsetMax;
        return gameObject.GetComponent<Image>();
    }

    private static TMP_Text CreateText(string name, RectTransform parent, string text, float fontSize, Vector2 anchorMin, Vector2 anchorMax, Color color, FontStyles style)
    {
        GameObject gameObject = new GameObject(name, typeof(RectTransform), typeof(TextMeshProUGUI));
        gameObject.transform.SetParent(parent, false);

        RectTransform rect = gameObject.GetComponent<RectTransform>();
        rect.anchorMin = anchorMin;
        rect.anchorMax = anchorMax;
        rect.offsetMin = Vector2.zero;
        rect.offsetMax = Vector2.zero;

        TextMeshProUGUI label = gameObject.GetComponent<TextMeshProUGUI>();
        label.text = text;
        label.fontSize = fontSize;
        label.color = color;
        label.fontStyle = style;
        label.alignment = TextAlignmentOptions.Left;
        label.enableAutoSizing = false;
        label.font = TMP_Settings.defaultFontAsset;
        return label;
    }

    private static Button CreateButton(string name, RectTransform parent, string text, Vector2 anchorMin, Vector2 anchorMax, Color color)
    {
        GameObject gameObject = new GameObject(name, typeof(RectTransform), typeof(Image), typeof(Button));
        gameObject.transform.SetParent(parent, false);

        RectTransform rect = gameObject.GetComponent<RectTransform>();
        rect.anchorMin = anchorMin;
        rect.anchorMax = anchorMax;
        rect.offsetMin = Vector2.zero;
        rect.offsetMax = Vector2.zero;

        Image image = gameObject.GetComponent<Image>();
        image.color = color;

        Button button = gameObject.GetComponent<Button>();
        ColorBlock colors = button.colors;
        colors.normalColor = color;
        colors.highlightedColor = color * 1.08f;
        colors.pressedColor = color * 0.92f;
        colors.selectedColor = color;
        button.colors = colors;

        TMP_Text label = CreateText("Label", rect, text, 28, new Vector2(0.06f, 0.12f), new Vector2(0.94f, 0.88f), Color.white, FontStyles.Bold);
        label.alignment = TextAlignmentOptions.Center;
        return button;
    }

    private static ChoiceButton CreateChoiceButton(string name, RectTransform parent, Vector2 anchorMin, Vector2 anchorMax, Color color)
    {
        Button button = CreateButton(name, parent, "Choice", anchorMin, anchorMax, color);
        ChoiceButton choiceButton = button.gameObject.AddComponent<ChoiceButton>();
        AssignField(choiceButton, "button", button);
        return choiceButton;
    }

    private static void AssignField(object target, string fieldName, object value)
    {
        FieldInfo field = target.GetType().GetField(fieldName, BindingFlags.Instance | BindingFlags.NonPublic);
        if (field != null)
        {
            field.SetValue(target, value);
            if (target is Object unityObject)
            {
                EditorUtility.SetDirty(unityObject);
            }
        }
    }

    private static Sprite LoadSprite(string resourceName)
    {
        return AssetDatabase.LoadAssetAtPath<Sprite>($"{ArtDirectory}/{resourceName}.png");
    }

    private static void WriteSpriteTexture(string fileName, int width, int height, System.Action<Texture2D> painter)
    {
        Texture2D texture = new Texture2D(width, height, TextureFormat.RGBA32, false);
        painter(texture);
        texture.Apply();

        string assetPath = $"{ArtDirectory}/{fileName}";
        File.WriteAllBytes(assetPath, texture.EncodeToPNG());
        Object.DestroyImmediate(texture);

        AssetDatabase.ImportAsset(assetPath, ImportAssetOptions.ForceUpdate);
        if (AssetImporter.GetAtPath(assetPath) is TextureImporter importer)
        {
            importer.textureType = TextureImporterType.Sprite;
            importer.alphaIsTransparency = true;
            importer.mipmapEnabled = false;
            importer.spritePixelsPerUnit = 100;
            importer.maxTextureSize = 2048;
            importer.textureCompression = TextureImporterCompression.Uncompressed;
            importer.SaveAndReimport();
        }
    }

    private static void FillTitleBackground(Texture2D texture)
    {
        FillVerticalGradient(texture, new Color(0.15f, 0.19f, 0.29f), new Color(0.92f, 0.72f, 0.72f));
        DrawCircle(texture, 1480, 240, 160, new Color(1f, 0.95f, 0.84f, 0.7f));
        DrawHaze(texture, new Color(0.98f, 0.82f, 0.86f, 0.28f), 0.52f);
        for (int i = 0; i < 14; i++)
        {
            int x = 120 + i * 120;
            DrawPetal(texture, x, 200 + (i % 4) * 40, 32 + (i % 3) * 8, new Color(0.98f, 0.87f, 0.91f, 0.55f));
        }
    }

    private static void FillCampusBackground(Texture2D texture, Color skyTop, Color skyBottom)
    {
        FillVerticalGradient(texture, skyTop, skyBottom);
        DrawRect(texture, 0, 760, texture.width, 320, new Color(0.74f, 0.8f, 0.73f));
        DrawRect(texture, 220, 260, 360, 520, new Color(0.89f, 0.9f, 0.92f));
        DrawRect(texture, 620, 300, 280, 480, new Color(0.84f, 0.86f, 0.9f));
        for (int y = 320; y < 760; y += 80)
        {
            DrawRect(texture, 260, y, 280, 12, new Color(0.65f, 0.7f, 0.78f));
            DrawRect(texture, 660, y, 200, 12, new Color(0.62f, 0.67f, 0.76f));
        }

        DrawTree(texture, 1440, 640, new Color(0.66f, 0.41f, 0.26f), new Color(0.97f, 0.84f, 0.9f));
        DrawTree(texture, 1680, 600, new Color(0.61f, 0.38f, 0.22f), new Color(0.96f, 0.8f, 0.86f));
    }

    private static void FillInteriorBackground(Texture2D texture, Color wall, Color shelf, Color book)
    {
        FillVerticalGradient(texture, wall, wall * 0.88f);
        DrawRect(texture, 0, 720, texture.width, 360, wall * 0.85f);
        for (int x = 140; x < texture.width - 140; x += 260)
        {
            DrawRect(texture, x, 220, 180, 680, shelf);
            for (int y = 260; y < 860; y += 130)
            {
                DrawRect(texture, x + 18, y, 144, 14, new Color(0.28f, 0.2f, 0.14f));
                for (int i = 0; i < 7; i++)
                {
                    DrawRect(texture, x + 24 + i * 20, y + 16, 14, 84, Color.Lerp(book, new Color(0.86f, 0.44f, 0.34f), i * 0.1f));
                }
            }
        }
    }

    private static void FillRainBackground(Texture2D texture)
    {
        FillVerticalGradient(texture, new Color(0.18f, 0.24f, 0.38f), new Color(0.44f, 0.49f, 0.57f));
        DrawRect(texture, 0, 760, texture.width, 320, new Color(0.22f, 0.27f, 0.32f));
        DrawRect(texture, 260, 360, 420, 420, new Color(0.58f, 0.63f, 0.7f));
        DrawRect(texture, 760, 320, 280, 460, new Color(0.5f, 0.56f, 0.64f));
        for (int x = -200; x < texture.width + 200; x += 28)
        {
            DrawDiagonal(texture, x, 0, 80, 240, new Color(0.82f, 0.9f, 1f, 0.22f));
        }
    }

    private static void FillStudioBackground(Texture2D texture)
    {
        FillVerticalGradient(texture, new Color(0.92f, 0.88f, 0.82f), new Color(0.78f, 0.72f, 0.68f));
        DrawRect(texture, 0, 780, texture.width, 300, new Color(0.68f, 0.62f, 0.58f));
        DrawRect(texture, 240, 240, 420, 560, new Color(0.95f, 0.95f, 0.94f));
        DrawRect(texture, 280, 280, 340, 460, new Color(1f, 1f, 1f));
        DrawCircle(texture, 1540, 340, 100, new Color(0.96f, 0.68f, 0.5f, 0.24f));
        for (int i = 0; i < 5; i++)
        {
            DrawCircle(texture, 1460 + i * 50, 280 + i * 42, 38 + i * 3, new Color(0.94f, 0.54f, 0.52f, 0.3f));
        }
    }

    private static void FillRooftopBackground(Texture2D texture)
    {
        FillVerticalGradient(texture, new Color(0.64f, 0.8f, 0.94f), new Color(0.89f, 0.95f, 0.99f));
        DrawRect(texture, 0, 700, texture.width, 380, new Color(0.76f, 0.79f, 0.84f));
        DrawRect(texture, 0, 560, texture.width, 44, new Color(0.45f, 0.5f, 0.59f));
        DrawRect(texture, 0, 604, texture.width, 8, new Color(0.29f, 0.33f, 0.41f));
        DrawCloud(texture, 460, 210, 110, new Color(1f, 1f, 1f, 0.7f));
        DrawCloud(texture, 1340, 260, 130, new Color(1f, 1f, 1f, 0.65f));
    }

    private static void FillGalleryBackground(Texture2D texture)
    {
        FillVerticalGradient(texture, new Color(0.95f, 0.95f, 0.96f), new Color(0.83f, 0.84f, 0.88f));
        DrawRect(texture, 0, 760, texture.width, 320, new Color(0.76f, 0.78f, 0.82f));
        for (int x = 180; x < texture.width - 240; x += 340)
        {
            DrawRect(texture, x, 280, 220, 320, new Color(1f, 1f, 1f));
            DrawRect(texture, x + 22, 302, 176, 276, new Color(0.86f, 0.89f, 0.95f));
        }
        DrawCircle(texture, 1620, 180, 120, new Color(1f, 0.95f, 0.83f, 0.24f));
    }

    private static void FillSakuraBackground(Texture2D texture)
    {
        FillVerticalGradient(texture, new Color(0.85f, 0.81f, 0.95f), new Color(1f, 0.93f, 0.88f));
        DrawRect(texture, 0, 760, texture.width, 320, new Color(0.77f, 0.86f, 0.78f));
        DrawTree(texture, 320, 440, new Color(0.57f, 0.34f, 0.22f), new Color(0.98f, 0.82f, 0.88f));
        DrawTree(texture, 1560, 420, new Color(0.56f, 0.31f, 0.22f), new Color(0.99f, 0.85f, 0.9f));
        for (int i = 0; i < 18; i++)
        {
            DrawPetal(texture, 180 + i * 92, 200 + (i % 5) * 42, 20 + (i % 4) * 6, new Color(1f, 0.88f, 0.92f, 0.58f));
        }
    }

    private static void FillPortrait(Texture2D texture, Color hairColor, Color accentColor, bool worried, bool smile)
    {
        FillTransparent(texture);
        DrawRect(texture, 0, 980, texture.width, 556, new Color(1f, 0.93f, 0.95f, 0.18f));
        DrawCircle(texture, 512, 540, 210, new Color(0.97f, 0.88f, 0.82f));
        DrawRoundedShoulders(texture, accentColor);
        DrawHair(texture, hairColor);
        DrawEyes(texture, worried, smile);
        DrawMouth(texture, smile);
        DrawCircle(texture, 430, 610, 22, new Color(1f, 0.73f, 0.76f, 0.14f));
        DrawCircle(texture, 594, 610, 22, new Color(1f, 0.73f, 0.76f, 0.14f));
    }

    private static void FillVerticalGradient(Texture2D texture, Color top, Color bottom)
    {
        for (int y = 0; y < texture.height; y++)
        {
            Color color = Color.Lerp(top, bottom, y / (float)(texture.height - 1));
            for (int x = 0; x < texture.width; x++)
            {
                texture.SetPixel(x, y, color);
            }
        }
    }

    private static void FillTransparent(Texture2D texture)
    {
        Color clear = new Color(0f, 0f, 0f, 0f);
        for (int y = 0; y < texture.height; y++)
        {
            for (int x = 0; x < texture.width; x++)
            {
                texture.SetPixel(x, y, clear);
            }
        }
    }

    private static void DrawHaze(Texture2D texture, Color color, float center)
    {
        int pivot = Mathf.RoundToInt(texture.width * center);
        for (int y = 0; y < texture.height; y++)
        {
            for (int x = 0; x < texture.width; x++)
            {
                float distance = Mathf.Abs(x - pivot) / (texture.width * 0.52f);
                float alpha = Mathf.Clamp01(1f - distance) * color.a;
                BlendPixel(texture, x, y, new Color(color.r, color.g, color.b, alpha));
            }
        }
    }

    private static void DrawRect(Texture2D texture, int x, int y, int width, int height, Color color)
    {
        for (int py = Mathf.Max(0, y); py < Mathf.Min(texture.height, y + height); py++)
        {
            for (int px = Mathf.Max(0, x); px < Mathf.Min(texture.width, x + width); px++)
            {
                BlendPixel(texture, px, py, color);
            }
        }
    }

    private static void DrawCircle(Texture2D texture, int centerX, int centerY, int radius, Color color)
    {
        int minX = Mathf.Max(0, centerX - radius);
        int maxX = Mathf.Min(texture.width - 1, centerX + radius);
        int minY = Mathf.Max(0, centerY - radius);
        int maxY = Mathf.Min(texture.height - 1, centerY + radius);
        int radiusSquared = radius * radius;

        for (int y = minY; y <= maxY; y++)
        {
            int dy = y - centerY;
            for (int x = minX; x <= maxX; x++)
            {
                int dx = x - centerX;
                if (dx * dx + dy * dy <= radiusSquared)
                {
                    BlendPixel(texture, x, y, color);
                }
            }
        }
    }

    private static void DrawDiagonal(Texture2D texture, int startX, int startY, int deltaX, int deltaY, Color color)
    {
        for (int i = 0; i < 220; i++)
        {
            int x = startX + i * deltaX / 220;
            int y = startY + i * deltaY / 220;
            for (int w = 0; w < 2; w++)
            {
                BlendPixel(texture, x + w, y, color);
            }
        }
    }

    private static void DrawPetal(Texture2D texture, int centerX, int centerY, int size, Color color)
    {
        DrawCircle(texture, centerX - size / 3, centerY, size / 2, color);
        DrawCircle(texture, centerX + size / 3, centerY, size / 2, color);
        DrawCircle(texture, centerX, centerY - size / 3, size / 2, color);
    }

    private static void DrawTree(Texture2D texture, int trunkX, int trunkTop, Color trunkColor, Color blossomColor)
    {
        DrawRect(texture, trunkX, trunkTop, 54, 320, trunkColor);
        DrawCircle(texture, trunkX + 12, trunkTop + 40, 140, blossomColor);
        DrawCircle(texture, trunkX + 86, trunkTop + 18, 122, blossomColor);
        DrawCircle(texture, trunkX + 50, trunkTop - 70, 114, blossomColor);
    }

    private static void DrawCloud(Texture2D texture, int centerX, int centerY, int radius, Color color)
    {
        DrawCircle(texture, centerX - radius / 2, centerY, radius / 2, color);
        DrawCircle(texture, centerX, centerY - radius / 4, radius / 2, color);
        DrawCircle(texture, centerX + radius / 2, centerY, radius / 2, color);
        DrawCircle(texture, centerX, centerY + radius / 6, radius / 2, color);
    }

    private static void DrawRoundedShoulders(Texture2D texture, Color color)
    {
        DrawRect(texture, 224, 720, 576, 480, color);
        DrawCircle(texture, 224, 960, 240, color);
        DrawCircle(texture, 800, 960, 240, color);
        DrawRect(texture, 434, 720, 156, 400, new Color(0.95f, 0.95f, 0.98f, 0.85f));
    }

    private static void DrawHair(Texture2D texture, Color hairColor)
    {
        DrawCircle(texture, 512, 500, 270, hairColor);
        DrawCircle(texture, 338, 620, 154, hairColor);
        DrawCircle(texture, 688, 620, 154, hairColor);
        DrawRect(texture, 260, 430, 504, 300, hairColor);
        DrawCircle(texture, 512, 444, 222, new Color(hairColor.r * 0.84f, hairColor.g * 0.84f, hairColor.b * 0.84f));
    }

    private static void DrawEyes(Texture2D texture, bool worried, bool smile)
    {
        Color eye = new Color(0.18f, 0.2f, 0.26f);
        int leftY = worried ? 528 : 540;
        int rightY = smile ? 544 : leftY;
        DrawRect(texture, 408, leftY, 72, 8, eye);
        DrawRect(texture, 544, rightY, 72, 8, eye);
        if (worried)
        {
            DrawRect(texture, 404, 506, 68, 6, eye);
            DrawRect(texture, 552, 498, 68, 6, eye);
        }
    }

    private static void DrawMouth(Texture2D texture, bool smile)
    {
        Color mouth = new Color(0.63f, 0.33f, 0.39f);
        if (smile)
        {
            DrawRect(texture, 462, 676, 102, 6, mouth);
            DrawRect(texture, 454, 670, 18, 6, mouth);
            DrawRect(texture, 554, 670, 18, 6, mouth);
        }
        else
        {
            DrawRect(texture, 466, 676, 92, 4, mouth);
        }
    }

    private static void BlendPixel(Texture2D texture, int x, int y, Color color)
    {
        if (x < 0 || x >= texture.width || y < 0 || y >= texture.height)
        {
            return;
        }

        Color background = texture.GetPixel(x, y);
        float alpha = color.a + background.a * (1f - color.a);
        if (alpha <= 0f)
        {
            texture.SetPixel(x, y, Color.clear);
            return;
        }

        Color blended = new Color(
            (color.r * color.a + background.r * background.a * (1f - color.a)) / alpha,
            (color.g * color.a + background.g * background.a * (1f - color.a)) / alpha,
            (color.b * color.a + background.b * background.a * (1f - color.a)) / alpha,
            alpha);
        texture.SetPixel(x, y, blended);
    }

    private static void EnsureDirectory(string path)
    {
        if (!AssetDatabase.IsValidFolder(path))
        {
            string[] parts = path.Split('/');
            string current = parts[0];
            for (int i = 1; i < parts.Length; i++)
            {
                string next = $"{current}/{parts[i]}";
                if (!AssetDatabase.IsValidFolder(next))
                {
                    AssetDatabase.CreateFolder(current, parts[i]);
                }

                current = next;
            }
        }
    }
}
