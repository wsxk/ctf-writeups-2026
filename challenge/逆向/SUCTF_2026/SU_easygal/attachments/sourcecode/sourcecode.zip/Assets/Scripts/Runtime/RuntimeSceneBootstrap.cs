using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public enum GameScreenKind
{
    Title,
    Game,
    Ending
}

public static class RuntimeSceneBootstrap
{
    public static GameScreenKind PendingScreen { get; set; } = GameScreenKind.Title;

    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
    private static void BootstrapOnLoad()
    {
        string activeScene = SceneManager.GetActiveScene().name;
        if (activeScene == GameConfig.TitleSceneName ||
            activeScene == GameConfig.GameSceneName ||
            activeScene == GameConfig.EndingSceneName)
        {
            return;
        }

        Show(PendingScreen);
    }

    public static void Show(GameScreenKind screen)
    {
        CleanupExistingBootstrapRoots();
        EnsureCamera();
        EnsureEventSystem();

        switch (screen)
        {
            case GameScreenKind.Game:
                BuildGameScreen();
                break;
            case GameScreenKind.Ending:
                BuildEndingScreen();
                break;
            default:
                BuildTitleScreen();
                break;
        }
    }

    private static void CleanupExistingBootstrapRoots()
    {
        string[] rootNames =
        {
            "RuntimeTitleCanvas",
            "RuntimeGameCanvas",
            "RuntimeEndingCanvas"
        };

        foreach (string rootName in rootNames)
        {
            GameObject existing = GameObject.Find(rootName);
            if (existing != null)
            {
                Object.Destroy(existing);
            }
        }
    }

    private static void EnsureCamera()
    {
        Camera camera = Camera.main;
        if (camera == null)
        {
            GameObject cameraObject = new GameObject("Main Camera");
            camera = cameraObject.AddComponent<Camera>();
            cameraObject.tag = "MainCamera";
            cameraObject.AddComponent<AudioListener>();
        }

        camera.clearFlags = CameraClearFlags.SolidColor;
        camera.backgroundColor = new Color(0.07f, 0.08f, 0.13f);
        camera.orthographic = true;
    }

    private static void EnsureEventSystem()
    {
        if (Object.FindObjectOfType<EventSystem>() != null)
        {
            return;
        }

        GameObject eventSystem = new GameObject("EventSystem");
        eventSystem.AddComponent<EventSystem>();
        eventSystem.AddComponent<StandaloneInputModule>();
    }

    private static void BuildTitleScreen()
    {
        Canvas canvas = CreateCanvas("RuntimeTitleCanvas");
        Image background = CreateImage("Background", canvas.transform, Vector2.zero, Vector2.one);
        background.sprite = GeneratedArtLibrary.Get("bg_title");
        background.preserveAspect = true;

        Image portrait = CreateImage("Portrait", canvas.transform, new Vector2(0f, 0f), new Vector2(0.46f, 1f));
        portrait.sprite = GeneratedArtLibrary.Get("portrait_kanna_soft");
        portrait.preserveAspect = true;

        RectTransform panel = CreatePanel("TitlePanel", canvas.transform, new Vector2(0.48f, 0.14f), new Vector2(0.94f, 0.86f), new Color(0.1f, 0.11f, 0.16f, 0.78f));
        CreateText("Eyebrow", panel, "狂子哥的恋爱日记", 28, new Vector2(0.06f, 0.82f), new Vector2(0.94f, 0.94f), new Color(0.96f, 0.8f, 0.82f), TextAnchor.MiddleLeft);
        CreateText("Title", panel, "Esaygal", 80, new Vector2(0.06f, 0.58f), new Vector2(0.94f, 0.82f), Color.white, TextAnchor.MiddleLeft).fontStyle = FontStyle.Bold;
        CreateText("Subtitle", panel, "把有限的余裕，留给真正重要的人。", 32, new Vector2(0.06f, 0.42f), new Vector2(0.94f, 0.58f), new Color(0.9f, 0.92f, 0.96f), TextAnchor.MiddleLeft);
        CreateText("Detail", panel, "SUCTF2026", 26, new Vector2(0.06f, 0.14f), new Vector2(0.94f, 0.42f), new Color(0.79f, 0.83f, 0.89f), TextAnchor.UpperLeft);

        TitleSceneController controller = panel.gameObject.AddComponent<TitleSceneController>();
        Button startButton = CreateButton("StartButton", panel, "开始", new Vector2(0.08f, 0.03f), new Vector2(0.45f, 0.14f), new Color(0.91f, 0.49f, 0.57f));
        Button quitButton = CreateButton("QuitButton", panel, "退出", new Vector2(0.55f, 0.03f), new Vector2(0.92f, 0.14f), new Color(0.25f, 0.31f, 0.41f));
        startButton.onClick.AddListener(controller.StartGame);
        quitButton.onClick.AddListener(controller.QuitGame);
    }

    private static void BuildGameScreen()
    {
        Canvas canvas = CreateCanvas("RuntimeGameCanvas");
        Image background = CreateImage("Background", canvas.transform, Vector2.zero, Vector2.one);
        background.sprite = GeneratedArtLibrary.Get("bg_campus");
        background.preserveAspect = true;

        CreateImage("Tint", canvas.transform, Vector2.zero, Vector2.one).color = new Color(0.04f, 0.05f, 0.09f, 0.16f);

        Image portrait = CreateImage("Portrait", canvas.transform, new Vector2(0.56f, 0.08f), new Vector2(0.97f, 0.92f));
        portrait.preserveAspect = true;

        RectTransform topBar = CreatePanel("TopBar", canvas.transform, new Vector2(0.03f, 0.9f), new Vector2(0.97f, 0.98f), new Color(0.08f, 0.1f, 0.16f, 0.86f));
        Text dayLabel = CreateText("DayLabel", topBar, "校门口", 28, new Vector2(0.02f, 0.14f), new Vector2(0.22f, 0.86f), Color.white, TextAnchor.MiddleLeft);
        Text progressLabel = CreateText("ProgressLabel", topBar, "进度 1/60", 26, new Vector2(0.24f, 0.14f), new Vector2(0.52f, 0.86f), new Color(0.83f, 0.86f, 0.93f), TextAnchor.MiddleLeft);
        Text weightLabel = CreateText("WeightLabel", topBar, string.Empty, 24, new Vector2(0.62f, 0.14f), new Vector2(0.78f, 0.86f), new Color(1f, 0.89f, 0.9f), TextAnchor.MiddleLeft);
        Text valueLabel = CreateText("ValueLabel", topBar, string.Empty, 24, new Vector2(0.8f, 0.14f), new Vector2(0.98f, 0.86f), new Color(0.9f, 0.94f, 1f), TextAnchor.MiddleLeft);
        weightLabel.gameObject.SetActive(false);
        valueLabel.gameObject.SetActive(false);

        RectTransform dialoguePanel = CreatePanel("DialoguePanel", canvas.transform, new Vector2(0.03f, 0.04f), new Vector2(0.97f, 0.4f), new Color(0.08f, 0.1f, 0.15f, 0.9f));
        Text speakerLabel = CreateText("SpeakerLabel", dialoguePanel, "旁白", 32, new Vector2(0.03f, 0.76f), new Vector2(0.34f, 0.94f), new Color(0.97f, 0.79f, 0.82f), TextAnchor.MiddleLeft);
        Text bodyLabel = CreateScrollTextArea("BodyScroll", dialoguePanel, new Vector2(0.03f, 0.22f), new Vector2(0.62f, 0.74f), string.Empty, 26, Color.white);
        Button nextButton = CreateButton("NextButton", dialoguePanel, "下一句", new Vector2(0.4f, 0.06f), new Vector2(0.62f, 0.16f), new Color(0.39f, 0.47f, 0.63f));
        Text nextButtonLabel = GetButtonLabel(nextButton);
        if (nextButtonLabel != null)
        {
            nextButtonLabel.text = "下一句";
            nextButtonLabel.font = UIFontProvider.GetChineseFont();
            nextButtonLabel.fontSize = 24;
            nextButtonLabel.alignment = TextAnchor.MiddleCenter;
        }
        nextButton.transform.SetAsLastSibling();

        RectTransform choiceRoot = CreatePanel("ChoiceRoot", dialoguePanel, new Vector2(0.66f, 0.1f), new Vector2(0.97f, 0.9f), new Color(0.15f, 0.16f, 0.23f, 0.56f));
        ChoiceButton[] choiceButtons = new ChoiceButton[2];
        choiceButtons[0] = CreateChoiceButton("ChoiceA", choiceRoot, new Vector2(0.06f, 0.54f), new Vector2(0.94f, 0.94f), new Color(0.88f, 0.54f, 0.58f));
        choiceButtons[1] = CreateChoiceButton("ChoiceB", choiceRoot, new Vector2(0.06f, 0.06f), new Vector2(0.94f, 0.46f), new Color(0.28f, 0.39f, 0.53f));

        Text errorLabel = CreateText("ErrorLabel", canvas.transform as RectTransform, string.Empty, 24, new Vector2(0.08f, 0.44f), new Vector2(0.92f, 0.54f), new Color(1f, 0.76f, 0.76f), TextAnchor.MiddleCenter);
        errorLabel.gameObject.SetActive(false);

        DialogueUI dialogueUI = canvas.gameObject.AddComponent<DialogueUI>();
        dialogueUI.Configure(background, portrait, dayLabel, progressLabel, speakerLabel, bodyLabel, weightLabel, valueLabel, choiceButtons);
        dialogueUI.ConfigureNextButton(nextButton, nextButtonLabel);

        GameManager manager = canvas.gameObject.AddComponent<GameManager>();
        manager.Configure(dialogueUI, errorLabel);
    }

    private static void BuildEndingScreen()
    {
        Canvas canvas = CreateCanvas("RuntimeEndingCanvas");
        Image background = CreateImage("Background", canvas.transform, Vector2.zero, Vector2.one);
        background.sprite = GeneratedArtLibrary.Get("bg_sakura");
        background.preserveAspect = true;

        CreateImage("Overlay", canvas.transform, Vector2.zero, Vector2.one).color = new Color(0.08f, 0.08f, 0.13f, 0.38f);

        Image portrait = CreateImage("Portrait", canvas.transform, new Vector2(0.05f, 0.12f), new Vector2(0.45f, 0.92f));
        portrait.preserveAspect = true;

        RectTransform panel = CreatePanel("EndingPanel", canvas.transform, new Vector2(0.46f, 0.1f), new Vector2(0.95f, 0.9f), new Color(0.1f, 0.1f, 0.15f, 0.82f));
        Text titleLabel = CreateText("TitleLabel", panel, "Ending", 52, new Vector2(0.06f, 0.78f), new Vector2(0.94f, 0.94f), Color.white, TextAnchor.MiddleLeft);
        titleLabel.fontStyle = FontStyle.Bold;
        Text bodyLabel = CreateScrollTextArea("EndingBodyScroll", panel, new Vector2(0.06f, 0.32f), new Vector2(0.94f, 0.76f), string.Empty, 25, new Color(0.94f, 0.95f, 0.98f));
        Text summaryLabel = CreateText("SummaryLabel", panel, string.Empty, 22, new Vector2(0.06f, 0.16f), new Vector2(0.94f, 0.3f), new Color(0.81f, 0.85f, 0.91f), TextAnchor.UpperLeft);

        EndingManager manager = panel.gameObject.AddComponent<EndingManager>();
        manager.Configure(background, portrait, titleLabel, bodyLabel, summaryLabel);

        Button restartButton = CreateButton("RestartButton", panel, "再来一次", new Vector2(0.06f, 0.03f), new Vector2(0.45f, 0.12f), new Color(0.9f, 0.51f, 0.58f));
        Button titleButton = CreateButton("TitleButton", panel, "回到标题", new Vector2(0.55f, 0.03f), new Vector2(0.94f, 0.12f), new Color(0.29f, 0.37f, 0.51f));
        restartButton.onClick.AddListener(manager.RestartGame);
        titleButton.onClick.AddListener(manager.ReturnToTitle);
    }

    private static Canvas CreateCanvas(string name)
    {
        GameObject canvasObject = new GameObject(name, typeof(Canvas), typeof(CanvasScaler), typeof(GraphicRaycaster));
        Canvas canvas = canvasObject.GetComponent<Canvas>();
        canvas.renderMode = RenderMode.ScreenSpaceOverlay;

        CanvasScaler scaler = canvasObject.GetComponent<CanvasScaler>();
        scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        scaler.referenceResolution = new Vector2(1920f, 1080f);
        scaler.matchWidthOrHeight = 0.5f;

        return canvas;
    }

    private static Image CreateImage(string name, Transform parent, Vector2 anchorMin, Vector2 anchorMax)
    {
        GameObject gameObject = new GameObject(name, typeof(RectTransform), typeof(Image));
        gameObject.transform.SetParent(parent, false);
        RectTransform rect = gameObject.GetComponent<RectTransform>();
        rect.anchorMin = anchorMin;
        rect.anchorMax = anchorMax;
        rect.offsetMin = Vector2.zero;
        rect.offsetMax = Vector2.zero;
        return gameObject.GetComponent<Image>();
    }

    private static RectTransform CreatePanel(string name, Transform parent, Vector2 anchorMin, Vector2 anchorMax, Color color)
    {
        Image image = CreateImage(name, parent, anchorMin, anchorMax);
        image.color = color;
        return image.rectTransform;
    }

    private static Text CreateText(string name, RectTransform parent, string text, int fontSize, Vector2 anchorMin, Vector2 anchorMax, Color color, TextAnchor alignment)
    {
        GameObject gameObject = new GameObject(name, typeof(RectTransform), typeof(Text));
        gameObject.transform.SetParent(parent, false);

        RectTransform rect = gameObject.GetComponent<RectTransform>();
        rect.anchorMin = anchorMin;
        rect.anchorMax = anchorMax;
        rect.offsetMin = Vector2.zero;
        rect.offsetMax = Vector2.zero;

        Text label = gameObject.GetComponent<Text>();
        label.text = text;
        label.font = UIFontProvider.GetChineseFont();
        label.fontSize = fontSize;
        label.color = color;
        label.alignment = alignment;
        label.horizontalOverflow = HorizontalWrapMode.Wrap;
        label.verticalOverflow = VerticalWrapMode.Truncate;
        label.supportRichText = true;
        return label;
    }

    private static Text CreateScrollTextArea(string name, RectTransform parent, Vector2 anchorMin, Vector2 anchorMax, string text, int fontSize, Color color)
    {
        GameObject rootObject = new GameObject(name, typeof(RectTransform), typeof(Image), typeof(ScrollRect));
        rootObject.transform.SetParent(parent, false);

        RectTransform rootRect = rootObject.GetComponent<RectTransform>();
        rootRect.anchorMin = anchorMin;
        rootRect.anchorMax = anchorMax;
        rootRect.offsetMin = Vector2.zero;
        rootRect.offsetMax = Vector2.zero;

        Image rootImage = rootObject.GetComponent<Image>();
        rootImage.color = new Color(1f, 1f, 1f, 0.04f);

        ScrollRect scrollRect = rootObject.GetComponent<ScrollRect>();
        scrollRect.horizontal = false;
        scrollRect.vertical = true;
        scrollRect.scrollSensitivity = 24f;

        GameObject viewportObject = new GameObject("Viewport", typeof(RectTransform), typeof(Image), typeof(Mask));
        viewportObject.transform.SetParent(rootRect, false);
        RectTransform viewportRect = viewportObject.GetComponent<RectTransform>();
        viewportRect.anchorMin = Vector2.zero;
        viewportRect.anchorMax = Vector2.one;
        viewportRect.offsetMin = new Vector2(8f, 8f);
        viewportRect.offsetMax = new Vector2(-8f, -8f);

        Image viewportImage = viewportObject.GetComponent<Image>();
        viewportImage.color = new Color(1f, 1f, 1f, 0.01f);
        viewportObject.GetComponent<Mask>().showMaskGraphic = false;

        GameObject contentObject = new GameObject("Content", typeof(RectTransform), typeof(ContentSizeFitter));
        contentObject.transform.SetParent(viewportRect, false);
        RectTransform contentRect = contentObject.GetComponent<RectTransform>();
        contentRect.anchorMin = new Vector2(0f, 1f);
        contentRect.anchorMax = new Vector2(1f, 1f);
        contentRect.pivot = new Vector2(0.5f, 1f);
        contentRect.offsetMin = new Vector2(0f, 0f);
        contentRect.offsetMax = new Vector2(0f, 0f);

        ContentSizeFitter fitter = contentObject.GetComponent<ContentSizeFitter>();
        fitter.horizontalFit = ContentSizeFitter.FitMode.Unconstrained;
        fitter.verticalFit = ContentSizeFitter.FitMode.PreferredSize;

        GameObject textObject = new GameObject("Text", typeof(RectTransform), typeof(Text));
        textObject.transform.SetParent(contentRect, false);
        RectTransform textRect = textObject.GetComponent<RectTransform>();
        textRect.anchorMin = new Vector2(0f, 1f);
        textRect.anchorMax = new Vector2(1f, 1f);
        textRect.pivot = new Vector2(0.5f, 1f);
        textRect.offsetMin = Vector2.zero;
        textRect.offsetMax = Vector2.zero;

        Text label = textObject.GetComponent<Text>();
        label.text = text;
        label.font = UIFontProvider.GetChineseFont();
        label.fontSize = fontSize;
        label.color = color;
        label.alignment = TextAnchor.UpperLeft;
        label.horizontalOverflow = HorizontalWrapMode.Wrap;
        label.verticalOverflow = VerticalWrapMode.Overflow;
        label.supportRichText = true;

        ContentSizeFitter textFitter = textObject.AddComponent<ContentSizeFitter>();
        textFitter.horizontalFit = ContentSizeFitter.FitMode.Unconstrained;
        textFitter.verticalFit = ContentSizeFitter.FitMode.PreferredSize;

        scrollRect.viewport = viewportRect;
        scrollRect.content = contentRect;
        scrollRect.movementType = ScrollRect.MovementType.Clamped;

        return label;
    }

    private static Button CreateButton(string name, RectTransform parent, string text, Vector2 anchorMin, Vector2 anchorMax, Color color)
    {
        GameObject gameObject = new GameObject(name, typeof(RectTransform), typeof(Image), typeof(Button));
        gameObject.transform.SetParent(parent, false);

        RectTransform rect = gameObject.GetComponent<RectTransform>();
        rect.anchorMin = anchorMin;
        rect.anchorMax = anchorMax;
        rect.offsetMin = Vector2.zero;
        rect.offsetMax = Vector2.zero;

        Image image = gameObject.GetComponent<Image>();
        image.color = color;

        Button button = gameObject.GetComponent<Button>();
        ColorBlock colors = button.colors;
        colors.normalColor = color;
        colors.highlightedColor = color * 1.08f;
        colors.pressedColor = color * 0.92f;
        colors.selectedColor = color;
        button.colors = colors;

        Text label = CreateText("Label", rect, text, 28, new Vector2(0.08f, 0.14f), new Vector2(0.92f, 0.86f), Color.white, TextAnchor.MiddleCenter);
        label.fontStyle = FontStyle.Bold;
        return button;
    }

    private static ChoiceButton CreateChoiceButton(string name, RectTransform parent, Vector2 anchorMin, Vector2 anchorMax, Color color)
    {
        Button button = CreateButton(name, parent, "Choice", anchorMin, anchorMax, color);
        ChoiceButton choiceButton = button.gameObject.AddComponent<ChoiceButton>();
        choiceButton.Configure(button, GetButtonLabel(button));
        return choiceButton;
    }

    private static Text GetButtonLabel(Button button)
    {
        if (button == null)
        {
            return null;
        }

        Transform labelTransform = button.transform.Find("Label");
        return labelTransform == null ? null : labelTransform.GetComponent<Text>();
    }
}
