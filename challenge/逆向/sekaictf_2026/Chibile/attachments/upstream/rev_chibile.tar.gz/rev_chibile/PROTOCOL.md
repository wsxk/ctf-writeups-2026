# Chibile - secret delivery

Phase 1 returns the inner object `{ sid, c_um, lh_um, c_km, lh_km }`.

For each secret: `BK` = baked half-key, `LH` = the `lh_*` value, `C` = the `c_*` value.

```
DK     = HMAC-SHA256(BK, LH)
KS(b)  = HMAC-SHA256(DK, tag || u32le(b))      ; tag = "UM-KS" (user) | "KM-KS" (kernel)
b = i // 32 ,  j = i % 32 ,  rotl8/rotr8 = 8-bit rotate

user   : S[i] = rotl8(C[i] ^ KS(b)[j], 3) ^ BK[j]
kernel : S[i] = rotr8(C[i] ^ DK[(i*7) % 32], 3) ^ KS(b)[j]
```

Each secret is 12 chars over `ABCDEFGHJKLMNPQRSTUVWXYZ23456789`.
