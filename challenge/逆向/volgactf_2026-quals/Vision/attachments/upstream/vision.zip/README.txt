WARNING: I can't stress this enough, but don't even think about launching that on main PC, if that bsods your main system (or triggers some AC or other stuff) you deserve it.

Now to the setup:
0. Install a VM and start it;
1. Disable vulnerable driver list (HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\CI\Config, set VulnerableDriverBlocklistEnable to 0) and AV on the VM;
2. Launch cmd from admin, cd to the unpacked files, run "kdmapper.exe vision.sys";
3. Start vision.exe.


The only tested version of Windows was Windows 11 Build 22621 (aka 22h2), should also work for 23h2 and any version below it (but that was not tested). w11 24h2 and 25h2 would not work.

Have fun.

P.S.: yeah, checking the flag might take ages (around 15-20s), I consider it a bruteforce protection, not a bug tbh.