#!/usr/bin/env sage-run
import re

from sage.all import Matrix, PolynomialRing, ZZ, Zmod, inverse_mod, prod


data = open("chal.txt", encoding="utf-8").read()
es = list(map(int, re.findall(r"^e = (\d+)$", data, re.MULTILINE)))
ns = list(map(ZZ, re.findall(r"^n = (\d+)$", data, re.MULTILINE)))
cs = list(map(ZZ, re.findall(r"^c = (\d+)$", data, re.MULTILINE)))

N = prod(ns)
degree = max(es)
R_N = PolynomialRing(Zmod(N), "x")
x_N = R_N.gen()

# E_i is 1 modulo n_i and 0 modulo each other modulus.  Multiplying
# the lower-degree RSA equations by powers of x gives one monic
# degree-13 equation modulo N = n_1*n_2*n_3.
f_N = x_N**degree
for e, n, c in zip(es, ns, cs):
    cofactor = N // n
    idempotent = cofactor * inverse_mod(cofactor, n)
    f_N -= R_N(idempotent * c) * x_N ** (degree - e)

# A Coppersmith lattice for roots below 2^600.  Using several reduced
# rows and taking their polynomial GCD avoids expensive factorization
# of a single degree-116 output polynomial.
R = PolynomialRing(ZZ, "x")
x = R.gen()
f = R(f_N)
X = ZZ(2) ** 600
m = 8

polynomial_rows = [
    x**j * N ** (m - i) * f**i
    for i in range(1, m + 1)
    for j in range(degree)
]
column_count = degree * (m + 1)
lattice = Matrix(ZZ, len(polynomial_rows), column_count)

for row, polynomial in enumerate(polynomial_rows):
    for column, coefficient in enumerate(polynomial):
        lattice[row, column] = coefficient * X**column

reduced = lattice.LLL(algorithm="flatter")
short_polynomials = [
    R([reduced[row, column] // X**column for column in range(column_count)])
    for row in range(12)
]

for i, left in enumerate(short_polynomials):
    for right in short_polynomials[:i]:
        common = left.gcd(right)
        for root, _multiplicity in common.roots():
            candidate = ZZ(root)
            if 0 <= candidate < X and all(
                pow(candidate, e, n) == c for e, n, c in zip(es, ns, cs)
            ):
                plaintext = int(candidate).to_bytes(
                    (int(candidate).bit_length() + 7) // 8, "big"
                )
                print(plaintext.decode())
                raise SystemExit

raise RuntimeError("small root was not recovered")
