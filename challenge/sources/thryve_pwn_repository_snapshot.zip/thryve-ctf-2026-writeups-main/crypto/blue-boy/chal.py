#!/usr/bin/env python3
import hashlib
EXPECTED_SHA256 = '6f85e84054f1048e167f4841647c59b99d3417d11688241fb948e59947f85153'
print("THRYVE — BLACK ICE")
print("Enter the recovered flag.")
answer=input("> ").strip()
print("ACCEPTED" if hashlib.sha256(answer.encode()).hexdigest()==EXPECTED_SHA256 else "REJECTED")
