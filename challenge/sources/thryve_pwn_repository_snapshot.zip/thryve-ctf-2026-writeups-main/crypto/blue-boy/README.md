# Blue Boy Writeup

**Category:** Crypto  
**Points:** 500  
**Author:** 0xFr0sty

> Three exponents. Three ciphertexts. One message.

## TL;DR

The challenge encrypts the same small, unpadded message three times using RSA, but it uses three different public exponents: 7, 11, and 13. That means the usual Hastad broadcast attack does not apply directly.

The trick is to use the Chinese Remainder Theorem (CRT) to turn all three RSA equations into **one degree-13 polynomial modulo the product of the three moduli**. The flag integer is small enough to be a Coppersmith small root of that polynomial. An LLL lattice recovers it without factoring any RSA modulus.

The flag is:

```text
Thryve{BLACK_ICE__three_exponents__common_root__7_11_13__39fe1b5a80c9de68}
```

The platform challenge is called **Blue Boy**, while the supplied files call it **BLACK ICE**. The latter is also what appears inside the accepted flag.

## What We Were Given

`chal.txt` contains three RSA cases. In shorter notation, they are:

```text
case 1: e1 = 7,  modulus n1, ciphertext c1
case 2: e2 = 11, modulus n2, ciphertext c2
case 3: e3 = 13, modulus n3, ciphertext c3
```

The same plaintext integer `m` was used in all three cases, so the underlying equations are

```text
m^7  = c1 (mod n1)
m^11 = c2 (mod n2)
m^13 = c3 (mod n3)
```

Each modulus is 3072 bits, and the three moduli are pairwise coprime.

`chal.py` is just a local checker. It hashes our submitted text with SHA-256 and compares the result with a stored digest, so it does not leak the flag itself.

## The Obvious Ideas That Do Not Work

It is useful to clear away a few standard RSA attacks first.

### Factoring the moduli

These are normal-looking 3072-bit RSA moduli. Factoring even one of them is not a realistic CTF approach unless there is some special weakness. Checking the pairwise GCDs gives 1, so the moduli do not share a prime either.

### Taking ordinary integer roots

Low-exponent RSA can sometimes be broken by taking an ordinary integer root of the ciphertext. That only works when `m^e < n`, meaning no modular wraparound happened.

Here a flag-sized message is too large for that. In the recovered solution, `m` is 591 bits. Even `m^7` is much larger than a 3072-bit modulus, so `c1` is not simply the integer seventh power of `m`. The same issue applies to the other ciphertexts.

### Applying Hastad's broadcast attack directly

The classic broadcast attack expects the **same exponent** for every ciphertext. We have exponents 7, 11, and 13 instead. CRT-ing the ciphertexts as though all three equations were `m^e` would therefore combine unrelated powers.

### Using Bezout on the exponents

Since the exponent GCD is 1, it is tempting to combine powers with Bezout coefficients. That idea works when the powers are known in the same modular ring. Here each power is known modulo a different `n_i`, so there is no direct multiplication trick that gives `m`.

The repeated message is still the weakness; we just need to express it differently.

## Building One Polynomial With CRT

Let

```text
N = n1 * n2 * n3
```

For each modulus, define a CRT idempotent:

```text
Mi = N / ni
Ei = Mi * inverse(Mi mod ni) mod N
```

These values behave like selector switches:

```text
Ei = 1 (mod ni)
Ei = 0 (mod nj), for every j != i
```

The largest exponent is 13. We lift each lower-degree RSA equation to degree 13 by multiplying it by a suitable power of `x`, then use the selectors to put the equations together:

```text
f(x) = x^13 - E1*c1*x^6 - E2*c2*x^2 - E3*c3  (mod N)
```

Why is the message `m` a root? Look at the polynomial one modulus at a time.

Modulo `n1`, only `E1` survives:

```text
f(m) = m^13 - c1*m^6
     = m^6 * (m^7 - c1)
     = 0 (mod n1)
```

Modulo `n2`, only `E2` survives:

```text
f(m) = m^13 - c2*m^2
     = m^2 * (m^11 - c2)
     = 0 (mod n2)
```

Finally, modulo `n3`:

```text
f(m) = m^13 - c3
     = 0 (mod n3)
```

Because the moduli are pairwise coprime, being zero modulo all three means

```text
f(m) = 0 (mod N).
```

We now have one **monic** degree-13 polynomial with the unknown flag as a modular root.

## Why Coppersmith Applies

Coppersmith's univariate method finds sufficiently small roots of a monic polynomial modulo a large composite number. Importantly, it does not require the factorization of that number.

The combined modulus has 9215 bits. For a degree-13 polynomial, the basic small-root boundary is approximately

```text
N^(1/13) ~= 2^(9215/13) ~= 2^708.8.
```

The recovered plaintext is only 591 bits, comfortably below that boundary. I used

```text
X = 2^600
```

as the root bound: large enough to contain the expected flag, but still below the Coppersmith limit.

### What the lattice is doing, in plain English

Knowing that `f(m)` is a multiple of `N` lets us construct many related polynomials that become multiples of a much larger power, `N^8`, when evaluated at `m`:

```text
g(i,j)(x) = x^j * N^(8-i) * f(x)^i
```

for `i = 1..8` and `j = 0..12`.

The coefficient of `x^k` is scaled by `X^k`. This tells the lattice that the root is bounded by `X`; high powers of the possible root should count as larger than low powers.

LLL (using the faster `flatter` backend here) searches this lattice for unusually short combinations. If a combination is small enough at `m` while also being divisible by `N^8`, its value cannot merely be a small nonzero multiple of `N^8`: it must be exactly zero over the integers.

That gives ordinary integer polynomials sharing the unknown root. Taking GCDs between several short output polynomials exposes their common factor, from which Sage can read the integer root. Checking the candidate against all three original RSA equations removes any accidental roots.

## Solver

I used the following Sage script:

```python
#!/usr/bin/env sage-run
import re

from sage.all import Matrix, PolynomialRing, ZZ, Zmod, inverse_mod, prod


data = open("chal.txt", encoding="utf-8").read()
es = list(map(int, re.findall(r"^e = (\d+)$", data, re.MULTILINE)))
ns = list(map(ZZ, re.findall(r"^n = (\d+)$", data, re.MULTILINE)))
cs = list(map(ZZ, re.findall(r"^c = (\d+)$", data, re.MULTILINE)))

N = prod(ns)
degree = max(es)
R_N = PolynomialRing(Zmod(N), "x")
x_N = R_N.gen()

# Ei is 1 modulo ni and 0 modulo each other modulus. Multiplying
# the lower-degree RSA equations by powers of x gives one monic
# degree-13 equation modulo N = n1*n2*n3.
f_N = x_N**degree
for e, n, c in zip(es, ns, cs):
    cofactor = N // n
    idempotent = cofactor * inverse_mod(cofactor, n)
    f_N -= R_N(idempotent * c) * x_N ** (degree - e)

# A Coppersmith lattice for roots below 2^600. Using several reduced
# rows and taking their polynomial GCD avoids factoring one large
# degree-116 output polynomial.
R = PolynomialRing(ZZ, "x")
x = R.gen()
f = R(f_N)
X = ZZ(2) ** 600
m = 8

polynomial_rows = [
    x**j * N ** (m - i) * f**i
    for i in range(1, m + 1)
    for j in range(degree)
]
column_count = degree * (m + 1)
lattice = Matrix(ZZ, len(polynomial_rows), column_count)

for row, polynomial in enumerate(polynomial_rows):
    for column, coefficient in enumerate(polynomial):
        lattice[row, column] = coefficient * X**column

reduced = lattice.LLL(algorithm="flatter")
short_polynomials = [
    R([reduced[row, column] // X**column for column in range(column_count)])
    for row in range(12)
]

for i, left in enumerate(short_polynomials):
    for right in short_polynomials[:i]:
        common = left.gcd(right)
        for root, _multiplicity in common.roots():
            candidate = ZZ(root)
            if 0 <= candidate < X and all(
                pow(candidate, e, n) == c for e, n, c in zip(es, ns, cs)
            ):
                plaintext = int(candidate).to_bytes(
                    (int(candidate).bit_length() + 7) // 8, "big"
                )
                print(plaintext.decode())
                raise SystemExit

raise RuntimeError("small root was not recovered")
```

There are 104 lattice rows (`8 * 13`) and 117 coefficient columns. Rather than trying to factor one potentially awkward degree-116 result from LLL, the script converts the first few short rows back into polynomials and computes their pairwise GCDs. The correct root appears in their shared factor.

## Running It

The script needs SageMath and `flatter`. Run it with `sage-run`:

```bash
sage-run solve.sage.py
```

Output:

```text
Thryve{BLACK_ICE__three_exponents__common_root__7_11_13__39fe1b5a80c9de68}
```

No remote instance interaction is needed.

## Validation

Converting the recovered text to a big-endian integer and testing it against the original data confirms all three equations:

```python
m = int.from_bytes(flag.encode(), "big")
assert pow(m, 7,  n1) == c1
assert pow(m, 11, n2) == c2
assert pow(m, 13, n3) == c3
```

Its SHA-256 digest is also exactly the value embedded in `chal.py`:

```text
6f85e84054f1048e167f4841647c59b99d3417d11688241fb948e59947f85153
```

Feeding it to the checker returns:

```text
THRYVE — BLACK ICE
Enter the recovered flag.
> ACCEPTED
```

## Takeaway

Reusing an unpadded RSA plaintext is dangerous even when the public exponent changes. The different exponents prevent the textbook broadcast formula, but CRT can still package the equations into a single polynomial. Once that polynomial has a small common root, Coppersmith and LLL do the rest—without ever recovering an RSA private key.
