#!/usr/bin/env python3
"""
THRYVE — BLACK ICE
Public compatibility/reference implementation.

This file intentionally contains no private RSA material.
Only Python's standard library is required.
"""

from dataclasses import dataclass


@dataclass(frozen=True)
class RSAProfile:
    modulus_bits: int = 2048
    public_exponent: int = 65537
    component_bytes: int = 128

    # Retained for pre-v4 interoperability.
    # Older tooling excludes this trailer when deriving a component-family tag.
    legacy_trailer_bytes: int = 65


PROFILE = RSAProfile()


def _int_to_minimal_bytes(x: int) -> bytes:
    if x < 0:
        raise ValueError("negative integer")
    return x.to_bytes(max(1, (x.bit_length() + 7) // 8), "big")


def component_family_tag(component: int) -> int:
    """
    Compatibility tag used by the legacy offline provisioning path.
    Integer components in the same family compare equal here.
    """
    shift = 8 * PROFILE.legacy_trailer_bytes
    return component >> shift


def legacy_pair_compatible(left_component: int, right_component: int) -> bool:
    """
    Kept to reproduce old key-import behavior.
    The legacy provisioner required this predicate before publishing n.
    """
    return component_family_tag(left_component) == component_family_tag(right_component)


def build_plaintext(flag: bytes, nonce: bytes) -> bytes:
    if len(nonce) != 16:
        raise ValueError("nonce must be exactly 16 bytes")
    if not flag.startswith(b"Thryve{") or not flag.endswith(b"}"):
        raise ValueError("unexpected flag format")

    return (
        b"THRYVE-OFFLINE-V4:"
        + nonce.hex().encode("ascii")
        + b":"
        + str(len(flag)).encode("ascii")
        + b":"
        + flag
    )


def rsa_encrypt(n: int, e: int, plaintext: bytes) -> int:
    if n.bit_length() != PROFILE.modulus_bits:
        raise ValueError("unexpected modulus size")
    if e != PROFILE.public_exponent:
        raise ValueError("unexpected public exponent")

    m = int.from_bytes(plaintext, "big")
    if m >= n:
        raise ValueError("message too large")
    return pow(m, e, n)


def decode_plaintext_block(block: bytes):
    """
    Parser for the public THRYVE-OFFLINE-V4 plaintext envelope.
    """
    prefix = b"THRYVE-OFFLINE-V4:"
    if not block.startswith(prefix):
        raise ValueError("bad prefix")

    rest = block[len(prefix):]
    nonce_hex, length_ascii, flag = rest.split(b":", 2)

    if len(nonce_hex) != 32:
        raise ValueError("bad nonce field")
    bytes.fromhex(nonce_hex.decode("ascii"))

    declared = int(length_ascii)
    if declared != len(flag):
        raise ValueError("length mismatch")
    return nonce_hex, flag


if __name__ == "__main__":
    print("THRYVE — BLACK ICE public reference")
    print(f"RSA modulus bits : {PROFILE.modulus_bits}")
    print(f"Public exponent  : {PROFILE.public_exponent}")
    print(f"Component bytes  : {PROFILE.component_bytes}")
