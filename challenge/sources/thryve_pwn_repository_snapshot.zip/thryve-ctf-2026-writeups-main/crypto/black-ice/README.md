# Black Ice Writeup

**Category:** Crypto  
**Points:** 500  
**Author:** 0xFr0sty

## The short version

This challenge uses RSA, but the two secret prime numbers were generated in a way that makes them much too similar. The provided compatibility function requires both primes to have the same large prefix. That means the primes are unusually close together, which makes the public modulus easy to factor with **Fermat's factorization method**.

Once the modulus is factored, we can rebuild the RSA private key, decrypt the ciphertext, and recover the flag:

```text
Thryve{black_ice_family_tag_fracture_ec20845fd3d3}
```

## What we were given

The challenge provides:

- `challenge.txt`, containing the RSA public modulus `n`, public exponent `e`, and ciphertext `c`.
- `challenge.py`, the reference implementation.

There is no server or oracle to attack. Everything has to come from the supplied numbers and source code.

The RSA parameters are the usual kind:

```text
n = p * q
e = 65537
c = plaintext^e mod n
```

Here, `p` and `q` are the two secret primes. Normally, factoring a properly generated 2048-bit RSA modulus to recover them is not practical.

## Finding the weakness

The most interesting code is this pair of functions:

```python
def component_family_tag(component: int) -> int:
    shift = 8 * PROFILE.legacy_trailer_bytes
    return component >> shift


def legacy_pair_compatible(left_component: int, right_component: int) -> bool:
    return component_family_tag(left_component) == component_family_tag(right_component)
```

The profile says:

```python
component_bytes = 128
legacy_trailer_bytes = 65
```

Each RSA prime is 128 bytes, or 1024 bits. The `component_family_tag` function shifts a prime to the right by:

```text
8 * 65 = 520 bits
```

A right shift by 520 bits throws away the lowest 520 bits and keeps everything above them. The compatibility check therefore requires:

```text
p >> 520 == q >> 520
```

In less mathematical terms, the two primes must begin with exactly the same upper bits. Because the primes are 1024 bits long, they share approximately:

```text
1024 - 520 = 504 upper bits
```

Imagine choosing two extremely long numbers but forcing the first half of their digits to be identical. Even though both numbers are huge, they will be unusually close to one another. That is exactly what happened to `p` and `q` here.

## Why close primes break RSA

The public RSA modulus is:

```text
n = p * q
```

Fermat's factorization method uses the identity:

```text
a^2 - b^2 = (a - b)(a + b)
```

If we can find `a` and `b` such that:

```text
n = a^2 - b^2
```

then the factors are immediately:

```text
p = a - b
q = a + b
```

When `p` and `q` are close, their average is near the square root of `n`:

```text
a = (p + q) / 2
```

So we start at `ceil(sqrt(n))` and repeatedly test whether `a^2 - n` is a perfect square. With random, well-separated RSA primes, this search would not be useful. With the shared-prefix primes in this challenge, it finishes almost immediately.

For this modulus, it required only **3,496 iterations**.

## Factoring and decrypting

This is the complete solver, also saved as `solve.py`:

```python
#!/usr/bin/env python3
import math
import re

from challenge import decode_plaintext_block


data = open("challenge.txt", "r", encoding="utf-8").read()
n = int(re.search(r"^n = (\d+)$", data, re.MULTILINE).group(1))
e = int(re.search(r"^e = (\d+)$", data, re.MULTILINE).group(1))
c = int(re.search(r"^c = (\d+)$", data, re.MULTILINE).group(1))

# Begin Fermat factorization at the first integer greater than or equal
# to the square root of n.
a = math.isqrt(n)
if a * a < n:
    a += 1

iterations = 0
while True:
    b_squared = a * a - n
    b = math.isqrt(b_squared)

    if b * b == b_squared:
        p = a - b
        q = a + b
        break

    a += 1
    iterations += 1

assert p * q == n

# Rebuild the private RSA exponent.
phi = (p - 1) * (q - 1)
d = pow(e, -1, phi)

# Decrypt c = m^e mod n by calculating m = c^d mod n.
m = pow(c, d, n)
plaintext = m.to_bytes((m.bit_length() + 7) // 8, "big")

nonce_hex, flag = decode_plaintext_block(plaintext)

print(f"Fermat iterations: {iterations}")
print(f"plaintext = {plaintext!r}")
print(f"flag = {flag.decode()}")
```

Running it gives:

```text
Fermat iterations: 3496
plaintext = b'THRYVE-OFFLINE-V4:8f7631600815692173ac425e97bafb7e:50:Thryve{black_ice_family_tag_fracture_ec20845fd3d3}'
flag = Thryve{black_ice_family_tag_fracture_ec20845fd3d3}
```

## What happens after factoring?

After recovering `p` and `q`, the remaining steps are standard RSA:

1. Calculate Euler's totient:

   ```text
   phi(n) = (p - 1)(q - 1)
   ```

2. Calculate the private exponent `d`, which is the modular inverse of `e`:

   ```text
   d = e^-1 mod phi(n)
   ```

3. Decrypt the ciphertext:

   ```text
   m = c^d mod n
   ```

4. Convert the resulting integer back into bytes and pass it to the provided plaintext parser.

The plaintext uses the following envelope:

```text
THRYVE-OFFLINE-V4:<32-character nonce>:<flag length>:<flag>
```

The decrypted length field is `50`, which matches the recovered flag.

## Takeaway

RSA does not become safe just because its numbers are large. Its primes also need to be generated independently and with enough randomness. The legacy family check leaks a structural relationship between the secret primes: it forces them to share about 504 leading bits. That relationship turns an otherwise hard 2048-bit factorization problem into a tiny Fermat search.

## Flag

```text
Thryve{black_ice_family_tag_fracture_ec20845fd3d3}
```
