#!/usr/bin/env python3
import math
import re

from challenge import decode_plaintext_block


data = open("challenge.txt", "r", encoding="utf-8").read()
n = int(re.search(r"^n = (\d+)$", data, re.MULTILINE).group(1))
e = int(re.search(r"^e = (\d+)$", data, re.MULTILINE).group(1))
c = int(re.search(r"^c = (\d+)$", data, re.MULTILINE).group(1))

# The compatibility check forces the 1024-bit primes to have the same bits
# above the final 65 bytes, so p and q are close enough for Fermat factoring.
a = math.isqrt(n)
if a * a < n:
    a += 1

iterations = 0
while True:
    b_squared = a * a - n
    b = math.isqrt(b_squared)
    if b * b == b_squared:
        p, q = a - b, a + b
        break
    a += 1
    iterations += 1

assert p * q == n
phi = (p - 1) * (q - 1)
d = pow(e, -1, phi)
m = pow(c, d, n)
plaintext = m.to_bytes((m.bit_length() + 7) // 8, "big")
nonce_hex, flag = decode_plaintext_block(plaintext)

print(f"Fermat iterations: {iterations}")
print(f"p = {p}")
print(f"q = {q}")
print(f"plaintext = {plaintext!r}")
print(f"flag = {flag.decode()}")
