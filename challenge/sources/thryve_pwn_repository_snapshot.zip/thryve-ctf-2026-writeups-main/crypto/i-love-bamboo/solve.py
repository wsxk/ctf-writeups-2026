#!/usr/bin/env python3
from pathlib import Path


BASE45 = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ $%*+-./:"

# North American Braille ASCII (the cells used by the final layer).
BRAILLE_ASCII = {
    0x00: " ", 0x2e: "!", 0x10: '"', 0x3c: "#", 0x2b: "$",
    0x29: "%", 0x2f: "&", 0x04: "'", 0x37: "(", 0x3e: ")",
    0x21: "*", 0x2c: "+", 0x20: ",", 0x24: "-", 0x28: ".",
    0x0c: "/", 0x34: "0", 0x02: "1", 0x06: "2", 0x12: "3",
    0x32: "4", 0x22: "5", 0x16: "6", 0x36: "7", 0x26: "8",
    0x14: "9", 0x31: ":", 0x30: ";", 0x23: "<", 0x3f: "=",
    0x1c: ">", 0x39: "?", 0x08: "@", 0x01: "A", 0x03: "B",
    0x09: "C", 0x19: "D", 0x11: "E", 0x0b: "F", 0x1b: "G",
    0x13: "H", 0x0a: "I", 0x1a: "J", 0x05: "K", 0x07: "L",
    0x0d: "M", 0x1d: "N", 0x15: "O", 0x0f: "P", 0x1f: "Q",
    0x17: "R", 0x0e: "S", 0x1e: "T", 0x25: "U", 0x27: "V",
    0x3a: "W", 0x2d: "X", 0x3d: "Y", 0x35: "Z", 0x2a: "[",
    0x33: "\\", 0x3b: "]", 0x18: "^", 0x38: "_",
}


def base45_decode(text: str) -> bytes:
    out = bytearray()
    for i in range(0, len(text), 3):
        group = text[i:i + 3]
        value = BASE45.index(group[0]) + 45 * BASE45.index(group[1])
        if len(group) == 3:
            value += 45 * 45 * BASE45.index(group[2])
            if value > 0xffff:
                raise ValueError("invalid Base45 triplet")
            out.extend(divmod(value, 256))
        else:
            if value > 0xff:
                raise ValueError("invalid Base45 pair")
            out.append(value)
    return bytes(out)


ciphertext = Path("ilovebamboo.enc").read_text().strip()

# ROT8000 skips the control-character area. In its printable-ASCII range,
# decrypting these characters is therefore a subtraction of U+7C09.
encoded = "".join(chr(ord(ch) - 0x7C09) for ch in ciphertext)
braille = base45_decode(encoded).decode("utf-8")

decoded = "".join(
    ch if ch in "{}" else BRAILLE_ASCII[ord(ch) - 0x2800]
    for ch in braille
)

# ThryveCTF uses this capitalization for its flag prefix.
flag = "Thryve" + decoded[len("THRYVE"):]
print(encoded)
print(braille)
print(flag)
