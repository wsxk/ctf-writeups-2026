# i LOVE bamboo

**Category:** Cryptography  
**Difficulty:** Easy  
**Flag:** `Thryve{4_C7F_F0R_D4_BL1NDD}`

## Challenge description

> Bamboo baskets,  
> bamboo mats,  
> bamboo screens,  
> bamboo trays,  
> bamboo blinds,  
> bamboo racks,  
> bamboo hampers,  
> bamboo boxes,  
> bamboo cases,  
> bamboo containers,  
> bamboo baskets.  
> I heard they used to use Bamboo as Red and white canes.

The challenge gave us one file, `ilovebamboo.enc`. Opening it showed a long
line of Chinese-looking characters:

```text
籋籝籜簳簼籔籖籍籔籋籝籜簻籂籓籓籎籔...
```

At first glance, this looks like we might need to translate Chinese. We do
not. The characters are being used for their numeric Unicode values rather
than their meanings.

## Layer 1: ROT8000

Computers assign every character a number called a **Unicode code point**.
For example, `A` is U+0041. A Caesar cipher shifts letters through the
alphabet; **ROT8000** applies the same basic idea to Unicode characters by
shifting their code points. Ordinary text consequently turns into characters
from other writing systems, often CJK characters like the ones in our file.

The repeated bamboo references were a hint toward the Chinese-looking
characters. Applying ROT8000 decoding produced this:

```text
BTS*3KMDKBTS29JJEKBTS3ALKDKYTF8EKBTSZGNCDKBTSI5NEDKBTSZGNEDKBTS1*MQDKBTSZGNSDKBTSTRMEEKBTSCUGADKBTSQOGWDKBTSJKJSDKZ2
```

That is progress: it is now plain ASCII, but it still is not readable text.
Its alphabet gives away the next layer.

For the printable characters used here, the ROT8000 implementation can be
reversed by subtracting `0x7C09` from each encrypted Unicode code point:

```python
ciphertext = open("ilovebamboo.enc").read().strip()
stage1 = "".join(chr(ord(char) - 0x7C09) for char in ciphertext)
print(stage1)
```

## Layer 2: Base45

The new text contains uppercase letters, numbers, and a few symbols. More
specifically, every character belongs to this alphabet:

```text
0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ $%*+-./:
```

That is the alphabet used by **Base45**. Base45 is not encryption; it is a
way to represent raw bytes using 45 safe text characters. It is similar in
purpose to Base64, which is commonly used for email attachments and web data.

After Base45 decoding, the bytes are valid UTF-8 and display as:

```text
⠞⠓⠗⠽⠧⠑{⠲⠸⠉⠶⠋⠸⠋⠴⠗⠸⠙⠲⠸⠃⠇⠂⠝⠙⠙}
```

Now the final sentence in the description makes sense. A red-and-white cane
is associated with someone who is deafblind, pointing us toward **Braille**.

## Layer 3: Braille ASCII

The last layer uses **Braille ASCII**. Each Braille dot pattern represents an
ASCII character. For example:

| Braille | ASCII |
|---|---|
| `⠞` | `T` |
| `⠓` | `H` |
| `⠗` | `R` |
| `⠽` | `Y` |
| `⠧` | `V` |
| `⠑` | `E` |
| `⠸` | `_` |
| `⠲` | `4` |
| `⠶` | `7` |
| `⠴` | `0` |
| `⠂` | `1` |

Decoding every cell gives:

```text
THRYVE{4_C7F_F0R_D4_BL1NDD}
```

ThryveCTF uses `Thryve` as the capitalization of its flag prefix, so the
final flag is:

```text
Thryve{4_C7F_F0R_D4_BL1NDD}
```

The text inside the braces is leetspeak for roughly **"A CTF for da blind"**,
which fits the Braille theme.

## Complete solver

Here is a standalone Python solver. It uses no third-party packages.

```python
#!/usr/bin/env python3
from pathlib import Path

BASE45 = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ $%*+-./:"

# The Braille cells needed by this challenge, indexed by their Unicode
# pattern value (the code point minus U+2800).
BRAILLE_ASCII = {
    0x1e: "T",
    0x13: "H",
    0x17: "R",
    0x3d: "Y",
    0x27: "V",
    0x11: "E",
    0x32: "4",
    0x38: "_",
    0x09: "C",
    0x36: "7",
    0x0b: "F",
    0x34: "0",
    0x19: "D",
    0x03: "B",
    0x07: "L",
    0x02: "1",
    0x1d: "N",
}


def base45_decode(text: str) -> bytes:
    output = bytearray()

    for offset in range(0, len(text), 3):
        group = text[offset:offset + 3]
        value = BASE45.index(group[0])
        value += 45 * BASE45.index(group[1])

        if len(group) == 3:
            value += 45 * 45 * BASE45.index(group[2])
            output.extend(divmod(value, 256))
        else:
            output.append(value)

    return bytes(output)


ciphertext = Path("ilovebamboo.enc").read_text().strip()

# Undo ROT8000 for the character range used by the file.
base45_text = "".join(chr(ord(char) - 0x7C09) for char in ciphertext)

# Decode Base45, then interpret the resulting bytes as UTF-8 Braille text.
braille = base45_decode(base45_text).decode("utf-8")

# The braces are already ordinary ASCII; translate everything else from
# its Braille pattern number.
decoded = "".join(
    char if char in "{}" else BRAILLE_ASCII[ord(char) - 0x2800]
    for char in braille
)

flag = "Thryve" + decoded[len("THRYVE"):]
print(flag)
```

Running it from the challenge directory gives:

```console
$ python3 solve.py
Thryve{4_C7F_F0R_D4_BL1NDD}
```

## Takeaway

This challenge is mostly about recognizing layers rather than breaking a
strong cipher:

1. Bamboo/Chinese-looking characters hinted at a Unicode trick: ROT8000.
2. The resulting alphabet matched Base45.
3. The red-and-white cane clue pointed to deafblindness and Braille.
4. Braille ASCII revealed the flag.

Whenever a CTF file looks like nonsense, it is worth checking whether the
characters are meaningful or whether their underlying numeric values are the
real message.
