#!/usr/bin/env python3
import base64
from pathlib import Path


BASE45 = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ $%*+-./:"


def b45decode(data: str) -> bytes:
    out = bytearray()
    for pos in range(0, len(data), 3):
        group = data[pos : pos + 3]
        value = BASE45.index(group[0]) + 45 * BASE45.index(group[1])
        if len(group) == 3:
            value += 45**2 * BASE45.index(group[2])
            out.extend(divmod(value, 256))
        else:
            out.append(value)
    return bytes(out)


def beaufort(ciphertext: str, key: str) -> str:
    result = []
    key_pos = 0
    for char in ciphertext:
        if not char.isascii() or not char.isalpha():
            result.append(char)
            continue

        shift = ord(key[key_pos % len(key)].upper()) - ord("A")
        value = (shift - (ord(char.lower()) - ord("a"))) % 26
        plain = chr(ord("a") + value)
        result.append(plain.upper() if char.isupper() else plain)
        key_pos += 1
    return "".join(result)


key_data = b45decode(Path("chall/key.enc").read_text())
rounds = 0
while key_data != b"FLAMINGO":
    key_data = base64.b64decode(key_data, validate=True)
    rounds += 1
key = key_data.decode()

emojis = bytes.fromhex(Path("chall/chall.enc").read_text()).decode()
# The emoji alphabet starts at U+1F400 and indexes ASCII U+0009..U+007E.
ciphertext = "".join(chr(ord(emoji) - 128000 + 9) for emoji in emojis)
flag = beaufort(ciphertext, key).strip()

print(f"Base64 rounds: {rounds}")
print(f"Key: {key}")
print(f"Beaufort ciphertext: {ciphertext!r}")
print(f"Flag: {flag}")
