# :) — Crypto Writeup

## Challenge information

- **Challenge:** `:)`
- **Category:** Crypto
- **Points:** 490
- **Author:** `gl1tt3rpuff0`
- **Description:** `;b`
- **Flag format:** `Thryve{...}`

## Files provided

After extracting `chall.7z`, we get two files:

```text
chall/chall.enc
chall/key.enc
```

At first glance, neither file looks very friendly. `chall.enc` is a short hex
string, while `key.enc` is over 100 KB of seemingly random characters.

The challenge name and description are both faces, so emojis are a reasonable
thing to expect somewhere in the puzzle.

## Step 1: Looking at `chall.enc`

The contents of `chall.enc` only use hexadecimal characters:

```text
f09f9184f09f919cf09f91a1...
```

Every pair of hex digits represents one byte. Decoding the hex as UTF-8 gives
us a line of emojis:

```text
👄👜👡👦👥👡👲👥👟🐨👥👖🐨👫👖👭👪👭👖👮🐨👘👟👤🐘👴🐁
```

This fits the smiley-face theme, but the individual pictures do not form a
sentence. Their Unicode numbers are what matter.

For example:

```text
👄 = U+1F444 = 128068
👜 = U+1F45C = 128092
👡 = U+1F461 = 128097
```

All of the values are close to `128000`, the code point for `🐀`. Subtracting
`128000` produces small numbers. The encoding also uses an ASCII alphabet that
starts at character code 9, so we add 9 afterward:

```python
ascii_value = ord(emoji) - 128000 + 9
```

Applying that calculation to every emoji reveals:

```text
Mejonj{nh1n_1t_vsv_w1ahm!}
```

This looks much more like an encrypted flag. It has the right braces, digits,
underscores, and overall length.

## Step 2: Unwrapping `key.enc`

`key.enc` uses exactly the following 45-character alphabet:

```text
0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ $%*+-./:
```

That is the Base45 alphabet, so the first operation is Base45 decoding.

The result begins like this:

```text
Vm0wd2QyUXlVWGxWV0d4V1YwZDRWMVl3...
```

That looks like Base64. Decoding it once only gives us another Base64 string,
then another, and another. The key has effectively been wrapped like a very
annoying digital onion.

After **31 Base64 decoding rounds**, the result is finally:

```text
FLAMINGO
```

Trying to Base64-decode that one more time produces binary nonsense, so the
readable word `FLAMINGO` is our intended stopping point and cipher key.

## Step 3: Recognizing the cipher

We now have:

```text
Ciphertext: Mejonj{nh1n_1t_vsv_w1ahm!}
Key:        FLAMINGO
```

The remaining layer is a **Beaufort cipher**. Beaufort is closely related to
the Vigenere cipher. Each key letter is treated as a number from 0 to 25:

```text
A = 0, B = 1, C = 2, ..., Z = 25
```

For each letter, Beaufort uses:

```text
plaintext = key - ciphertext mod 26
```

The key repeats as necessary, but it advances only when processing letters.
Digits, underscores, braces, and punctuation are copied unchanged.

Here is the beginning by hand:

```text
Ciphertext: M  e  j  o  n  j
Key:       F  L  A  M  I  N
Plaintext: T  h  r  y  v  e
```

Decrypting the entire string gives:

```text
Thryve{th1s_1s_fun_r1ght!}
```

## Solver

The following script performs every step without requiring extra Python
packages:

```python
#!/usr/bin/env python3
import base64
from pathlib import Path


BASE45 = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ $%*+-./:"


def b45decode(data: str) -> bytes:
    output = bytearray()

    for position in range(0, len(data), 3):
        group = data[position:position + 3]
        value = BASE45.index(group[0])
        value += 45 * BASE45.index(group[1])

        if len(group) == 3:
            value += 45**2 * BASE45.index(group[2])
            output.extend(divmod(value, 256))
        else:
            output.append(value)

    return bytes(output)


def beaufort(ciphertext: str, key: str) -> str:
    plaintext = []
    key_position = 0

    for character in ciphertext:
        if not character.isascii() or not character.isalpha():
            plaintext.append(character)
            continue

        key_letter = key[key_position % len(key)].upper()
        key_value = ord(key_letter) - ord("A")
        cipher_value = ord(character.lower()) - ord("a")
        plain_value = (key_value - cipher_value) % 26

        plain_character = chr(ord("a") + plain_value)
        if character.isupper():
            plain_character = plain_character.upper()

        plaintext.append(plain_character)
        key_position += 1

    return "".join(plaintext)


# Decode Base45, followed by the 31 Base64 layers.
key_data = b45decode(Path("chall/key.enc").read_text())
rounds = 0

while key_data != b"FLAMINGO":
    key_data = base64.b64decode(key_data, validate=True)
    rounds += 1

key = key_data.decode()

# Hex -> UTF-8 emojis -> ASCII Beaufort ciphertext.
emoji_text = bytes.fromhex(Path("chall/chall.enc").read_text()).decode()
ciphertext = "".join(
    chr(ord(emoji) - 128000 + 9)
    for emoji in emoji_text
)

flag = beaufort(ciphertext, key).strip()

print(f"Base64 rounds: {rounds}")
print(f"Key: {key}")
print(f"Ciphertext: {ciphertext!r}")
print(f"Flag: {flag}")
```

Running it produces:

```text
Base64 rounds: 31
Key: FLAMINGO
Ciphertext: 'Mejonj{nh1n_1t_vsv_w1ahm!}\n'
Flag: Thryve{th1s_1s_fun_r1ght!}
```

## Flag

```text
Thryve{th1s_1s_fun_r1ght!}
```

The challenge is mostly a chain of disguises: hex hides emojis, Unicode values
hide a Beaufort ciphertext, and Base45 plus many Base64 layers hide its key.
Once each wrapper is removed in the correct order, the final cipher is fairly
straightforward.
