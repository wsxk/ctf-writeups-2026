# It Works on My Machine — Writeup

**Category:** Forensics  
**Points:** 500  
**Authors:** Aws Afaneh and Nova0x

## TL;DR

The disk belonged to several Windows users, but the suspicious activity happened in the `aws` account. Its Windows **Run** history contained an obfuscated PowerShell command. Decoding that command pointed to a recovery note in `C:\ProgramData\HearthSync`.

The note told us to match five colored desk cards to five Windows accounts. Their initials formed the key `ANOAR`. After Base64-decoding `broker.cache` and XORing it with that repeating key, we got:

```text
Thryve{rUnmRu_1s_n0t_th3_cL1pb04rd}
```

## What we were given

The only evidence file was:

```text
It_Works_On_My_Machine.E01
```

An `.E01` file is a forensic disk image. In normal-person terms, it is a carefully packaged copy of a drive that lets us inspect the laptop without changing the original evidence.

I used Sleuth Kit, `ewf-tools`, and Python's `python-registry` library. The important commands are included below so the investigation can be reproduced.

## 1. Checking the image

I started with `ewfinfo`:

```bash
ewfinfo It_Works_On_My_Machine.E01
```

The case notes were unusually helpful:

```text
ClickFix investigation with five user profiles, RunMRU,
authentic Unistore ESE stores, WebCache and Edge databases
```

This suggested a **ClickFix** incident. ClickFix is the sort of fake verification page that tells a victim to open the Windows Run box and paste a command. The page pretends that the command is a harmless verification step, but it actually launches PowerShell or another system tool.

The image represented a 24 GiB drive. I exposed its raw contents with `ewfmount` and checked its partition table:

```bash
mkdir -p ewf-mount
ewfmount It_Works_On_My_Machine.E01 ewf-mount
mmls ewf-mount/ewf1
```

The useful NTFS partition began at sector `2048`:

```text
Slot    Start       Length       Description
000     0000002048  0050327552   primary
```

That number is passed to Sleuth Kit tools with `-o 2048`. It simply tells them where the Windows filesystem starts inside the full disk.

## 2. Listing the files and finding the users

I made a recursive file listing:

```bash
fls -o 2048 -r -p -l ewf-mount/ewf1 > file-list.txt
grep -E $'\tUsers/[^/]+$' file-list.txt
```

There were five relevant employee profiles:

```text
Users/ahmad
Users/aws
Users/nova0x
Users/omar
Users/rana
```

Each profile contained an `NTUSER.DAT` file. This is a per-user Windows Registry database. Among many other settings, it can contain `RunMRU`, the history of commands entered into the **Win+R** Run dialog.

The five hives had the following NTFS metadata record numbers:

| User | `NTUSER.DAT` record |
|---|---:|
| ahmad | 36883 |
| aws | 37814 |
| nova0x | 38749 |
| omar | 39681 |
| rana | 40675 |

I extracted them with `icat`:

```bash
mkdir -p extracted

while read -r inode user; do
    icat -o 2048 ewf-mount/ewf1 "$inode" > "extracted/$user-NTUSER.DAT"
done <<'EOF'
36883 ahmad
37814 aws
38749 nova0x
39681 omar
40675 rana
EOF
```

Here, `icat` is basically being asked, "Give me the contents of the file stored in this NTFS record."

## 3. Finding the suspicious Run command

I checked the `RunMRU` key in every hive with Python:

```python
from Registry import Registry
import glob
import os

runmru = r"Software\Microsoft\Windows\CurrentVersion\Explorer\RunMRU"

for filename in sorted(glob.glob("extracted/*-NTUSER.DAT")):
    print(f"\n=== {os.path.basename(filename)} ===")
    hive = Registry.Registry(filename)

    try:
        key = hive.open(runmru)
    except Registry.RegistryKeyNotFoundException:
        print("No RunMRU key")
        continue

    for value in key.values():
        print(value.name(), repr(value.value()))
```

Four users had no `RunMRU` key. The `aws` profile did, and it contained these entries:

```text
d = msedge.exe https://verify.human-check.example
c = control.exe /name Microsoft.UserAccounts
b = notepad.exe
a = powershell.exe -NoProfile -WindowStyle Hidden
    -ExecutionPolicy Bypass -Command "..."
MRUList = adcb
```

This tells a pretty clear story. The user opened a fake verification site in Edge and eventually ran a hidden PowerShell command. `MRUList` starts with `a`, meaning the PowerShell entry was the most recent command in this list.

The PowerShell was long because it stored another script as Base64-compressed data. Its important variable was:

```text
H4sIAAAAAAAEAD3NsQrCMBCA4Ve5rYvmAdzEFnQQpQouWc7kTApJLuSuim9vRXD+4ftvbVJan2ats0J3jQQVRcmD45yxeJgECivoUh4Jg4FDkUpOYbex58ahYe5R0e4Jm8bLuzg7Dtv+OJjsDXxBLPKiBndKXIKA8g+bnsuLuCZa/Q8SKSXTfQBdZzfxlQAAAA==
```

The surrounding PowerShell showed exactly what it did: Base64-decode the value, decompress it with Gzip, then execute the result. We can safely perform only the decoding in Python:

```python
import base64
import gzip

encoded = "H4sIAAAAAAAEAD3NsQrCMBCA4Ve5rYvmAdzEFnQQpQouWc7kTApJLuSuim9vRXD+4ftvbVJan2ats0J3jQQVRcmD45yxeJgECivoUh4Jg4FDkUpOYbex58ahYe5R0e4Jm8bLuzg7Dtv+OJjsDXxBLPKiBndKXIKA8g+bnsuLuCZa/Q8SKSXTfQBdZzfxlQAAAA=="

decoded = gzip.decompress(base64.b64decode(encoded))
print(decoded.decode())
```

Output:

```powershell
Write-Output 'The pasted command is not the flag. Inspect C:\ProgramData\HearthSync\README.md. The answer belongs to the five people, not the shell.'
```

So the pasted PowerShell was a pointer, not the answer itself.

## 4. Following the HearthSync note

Searching the file listing for `HearthSync` found two small files:

```text
ProgramData/HearthSync/README.md
ProgramData/HearthSync/broker.cache
```

Their record numbers were `28868` and `28869`, so I extracted them:

```bash
icat -o 2048 ewf-mount/ewf1 28868 > extracted/HearthSync-README.md
icat -o 2048 ewf-mount/ewf1 28869 > extracted/broker.cache
cat extracted/HearthSync-README.md
```

The useful part of the note said:

```text
During the account-sync rollback, one visual seating reference was retained:
C:\Users\aws\OneDrive - Thryve\Shared\Team Updates\late-shift-seating-chart.svg

The participant identity markers were retained in each user's Desktop\badge.svg.

Use the identity sequence represented by the visual reference, then take the
first character of the matching Windows account names.
```

It also warned that the old roster and browser hand-off were not authoritative. In other words, use the final seating chart rather than being distracted by stale browser or messaging data.

## 5. Matching the seating chart to the badges

The chart and five badges were easy to locate in `file-list.txt`:

| File | Record |
|---|---:|
| `ahmad/Desktop/badge.svg` | 37726 |
| `aws/Desktop/badge.svg` | 38658 |
| `aws/.../late-shift-seating-chart.svg` | 38697 |
| `nova0x/Desktop/badge.svg` | 39563 |
| `omar/Desktop/badge.svg` | 40498 |
| `rana/Desktop/badge.svg` | 42323 |

I extracted them like this:

```bash
icat -o 2048 ewf-mount/ewf1 37726 > extracted/ahmad-badge.svg
icat -o 2048 ewf-mount/ewf1 38658 > extracted/aws-badge.svg
icat -o 2048 ewf-mount/ewf1 38697 > extracted/late-shift-seating-chart.svg
icat -o 2048 ewf-mount/ewf1 39563 > extracted/nova0x-badge.svg
icat -o 2048 ewf-mount/ewf1 40498 > extracted/omar-badge.svg
icat -o 2048 ewf-mount/ewf1 42323 > extracted/rana-badge.svg
```

SVG files are images, but they are also readable XML text. Opening them in an image viewer or just reading the text gives the same information.

The seating chart ordered the desk cards as:

```text
1. COPPER
2. INDIGO
3. CHARCOAL
4. CRIMSON
5. MINT
```

The individual badges mapped those colors to people:

| Position | Desk card | Badge/account | First character |
|---:|---|---|:---:|
| 1 | COPPER | aws | A |
| 2 | INDIGO | nova0x | N |
| 3 | CHARCOAL | omar | O |
| 4 | CRIMSON | ahmad | A |
| 5 | MINT | rana | R |

Reading the first characters in seating order gives:

```text
ANOAR
```

That is our key.

## 6. Decoding `broker.cache`

The cache contained one Base64 string:

```text
FSY9OCQkNT0UPCwcOh5jMhEhcSYeOidyDSICfjEwcXo9JS8=
```

Base64 is only a way of representing bytes as text; it is not encryption. After decoding it, I XORed the bytes with the repeating key `ANOAR`.

For a quick explanation of XOR: each byte of the hidden message was mixed with one byte of the key. Applying the same operation with the same key reverses it. Since the message is longer than the five-letter key, the key repeats as `ANOARANOARANOAR...`.

```python
import base64

ciphertext = base64.b64decode(
    "FSY9OCQkNT0UPCwcOh5jMhEhcSYeOidyDSICfjEwcXo9JS8="
)
key = b"ANOAR"

plaintext = bytes(
    byte ^ key[index % len(key)]
    for index, byte in enumerate(ciphertext)
)

print(plaintext.decode())
```

Output:

```text
Thryve{rUnmRu_1s_n0t_th3_cL1pb04rd}
```

## Flag

```text
Thryve{rUnmRu_1s_n0t_th3_cL1pb04rd}
```

## Final thoughts

The main lesson was right in the flag: **RunMRU is not the clipboard**. We did not need to recover whatever the victim had copied. Windows had already recorded the command after it was pasted into the Run dialog.

The challenge included realistic browser, WebCache, and Unistore artifacts, which made the laptop look much more like a real investigation. However, the clean route was:

```text
aws NTUSER.DAT
    -> RunMRU PowerShell
    -> Base64 + Gzip decode
    -> HearthSync README
    -> seating chart + five badges
    -> ANOAR
    -> Base64 + repeating XOR
    -> flag
```
