<!-- ===== ANIMATED CYBERPUNK-HUD BANNER (standalone SVG, animates via <img>) ===== -->
<p align="center">
  <img src="./banner.svg" alt="THRYVE CTF 2026 — 1st place — 14 challenges" width="100%">
</p>

<!-- ===== SHIELDS.IO BADGE ROW ===== -->
<p align="center">
  <img alt="Event" src="https://img.shields.io/badge/EVENT-Thryve_Ctf_2026-22e5ff?style=for-the-badge&labelColor=05060a">
  <img alt="Placement" src="https://img.shields.io/badge/RESULT-1st_place-ffbf3f?style=for-the-badge&labelColor=05060a">
  <img alt="Challenges" src="https://img.shields.io/badge/CHALLENGES-14-ff2bd6?style=for-the-badge&labelColor=05060a">
  <img alt="Categories" src="https://img.shields.io/badge/CATEGORIES-crypto_forensics_osint_pwn_rev-8b5cff?style=for-the-badge&labelColor=05060a">
</p>

<!-- ===== BACK-LINK: part of hax1ng's CTF writeups collection ===== -->
<p align="center">
  <a href="https://github.com/hax1ng">
    <img alt="Part of hax1ng's CTF writeups" src="https://img.shields.io/badge/%E2%97%89_part_of-hax1ng's_CTF_writeups-2bff88?style=for-the-badge&labelColor=05060a&logo=github&logoColor=dff7ff">
  </a>
</p>

<p align="center">
  <sub><code>● SYSTEM ONLINE</code> &nbsp;·&nbsp; <strong>THRYVE CTF 2026</strong> &nbsp;·&nbsp; 1st place &nbsp;·&nbsp; 14 challenges &nbsp;·&nbsp; crypto · forensics · osint · pwn · rev</sub>
</p>

---
# Thryve CTF 2026 — Writeups 🥇

> **🏆 1st Place Finish** — Thryve CTF 2026 (14 Aug 2026, 9-hour event)

A collection of writeups and solve scripts for the challenges we cleared on our way to
first place. Each challenge lives in its own folder with a full writeup (`README.md`),
the exploit/solver, and the relevant source or handout files.

![Placement](https://img.shields.io/badge/Placement-1st%20Place-gold)
![Challenges](https://img.shields.io/badge/Solved-14-brightgreen)
![Categories](https://img.shields.io/badge/Categories-5-blue)
![Flag Format](https://img.shields.io/badge/flag-Thryve%7B...%7D-purple)

---

## 📊 Solve Summary

| Category  | Solved |
|-----------|:------:|
| Crypto    | 4 |
| Reversing | 6 |
| Pwn       | 2 |
| Forensics | 1 |
| OSINT     | 1 |
| **Total** | **14** |

---

## 🔐 Crypto

| Challenge | Technique | Flag |
|-----------|-----------|------|
| [Black Ice](crypto/black-ice) | Near-equal RSA primes → **Fermat factorization** | `Thryve{black_ice_family_tag_fracture_ec20845fd3d3}` |
| [Blue Boy](crypto/blue-boy) | Same message, exponents 7/11/13 → **CRT + Coppersmith (LLL)** | `Thryve{BLACK_ICE__three_exponents__common_root__7_11_13__39fe1b5a80c9de68}` |
| [I Love Bamboo](crypto/i-love-bamboo) | Layered Unicode / Caesar-shift decoding | `Thryve{4_C7F_F0R_D4_BL1NDD}` |
| [:\)](crypto/smiley) | Nested "wrapped" encoding layers unravelled with key `FLAMINGO` | `Thryve{th1s_1s_fun_r1ght!}` |

## 🧩 Reversing

| Challenge | Technique | Flag |
|-----------|-----------|------|
| [Black Blood](rev/black-blood) | 13 questions, every answer is `give me blood`; feed it 13× | `Thryve{Th3_Bl00d_1s_bl2ck}` |
| [Chimera Mirrors](rev/chimera-mirrors) | Nested **VM-in-a-VM**; emulate the inner VM & brute per-char | `Thryve{d0ubl3_VM_1n_4_m1rr0r_0pc0d35_n3v3r_5t4y}` |
| [Hell](rev/hell) | **Mixed Boolean-Arithmetic** constraints solved with Z3 | `Thryve{m4th_m4dn3ss}` |
| [Parallax](rev/parallax) | Self-modifying VM (opcodes mutate every step) checking a 45-char input | `Thryve{Man_Am_1_n0t_th2_b2st_auth0r?_NotSaad}` |
| [Redline](rev/redline) | Bit-level logic-gate network; solve a 320-bit constraint | `ThryveCTF{red_black_relays_dont_lie}` |
| [Soul](rev/soul) | Custom VM; 16-byte key drives both the check and flag decryption | `Thryve{0n3_7h1n9_4b0u7_m3_15_1_h47e_vm_d15p47ch3r5}` |

## 💥 Pwn

| Challenge | Technique | Flag |
|-----------|-----------|------|
| [Abyss Oracle](pwn/abyss-oracle) | Linux **kernel LPE** abusing a custom capability device | `Thryve{662a0b7c-e3b6-47e9-bea2-1595483c37d5}` |
| [Secret Door](pwn/secret-door) | C++ **type confusion** → attacker-controlled vtable pointer | `Thryve{31908972-e4a3-451e-8cba-a5738ba9b6da}` |

## 🔎 Forensics

| Challenge | Technique | Flag |
|-----------|-----------|------|
| [It Works On My Machine](forensics/it-works-on-my-machine) | E01 disk → obfuscated PowerShell in Run history → XOR `broker.cache` with `ANOAR` | `Thryve{rUnmRu_1s_n0t_th3_cL1pb04rd}` |

## 🌐 OSINT

| Challenge | Technique | Flag |
|-----------|-----------|------|
| [ThryveTech's Resistance](osint/thryvetechs-resistance) | Username pivot (X → Reddit breadcrumbs) to recover the flag | `Thryve{f8b9f764e48829ffea56e5bc463286c8}` |

---

## 📁 Repository Layout

```
.
├── crypto/      # RSA (Fermat, Coppersmith), layered ciphers
├── rev/         # custom VMs, MBA, logic-gate networks
├── pwn/         # kernel LPE, C++ type confusion
├── forensics/   # E01 disk forensics
└── osint/       # username pivoting
```

Each challenge folder contains:
- **`README.md`** — the full writeup (recon → vulnerability → exploit → flag)
- **`solve.py` / `solve.sage.py`** — the automated solver where applicable
- **source / handout files** — challenge code, small binaries, and artifacts

> **Note on artifacts:** oversized handouts are intentionally left out to keep the
> repo lightweight — the 4.6 GB `It Works On My Machine` E01 disk image, `Abyss Oracle`'s
> `vmlinux`/`bzImage`/initramfs, and `Black Blood`'s core dump. The writeups explain how
> to obtain and work with them.

---

## ⚖️ Disclaimer

These writeups document solutions to **intentionally vulnerable** challenges built for the
Thryve CTF 2026 competition, for educational purposes only. Flag format: `Thryve{...}`
(one challenge, *Redline*, uses `ThryveCTF{...}`).
