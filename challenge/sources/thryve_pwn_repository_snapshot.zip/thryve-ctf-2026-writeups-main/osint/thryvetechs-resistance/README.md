
# ThryveTech's Resistance - OSINT Writeup

**Category:** OSINT  
**Flag Format:** `Thryve{...}`   

## Challenge Description

> A few days ago, ThryveTech terminated an employee due to repeated bad behavior and misconduct. Since then, the former employee appears to have started retaliating against the company by leaking internal information and exposing some of our secrets online.
>
> One of our employees managed to identify an account believed to belong to him:
>
> **Username:** YoToxicGrass
>
> Your task is to investigate his online presence, follow the trail he left behind, and determine what sensitive information he has exposed.

## Solution

### 1. Initial Reconnaissance – X (Twitter)

Searching for the given username leads to the X account:

- **Handle:** [@YoToxicGrass](https://x.com/YoToxicGrass) (display name variants such as YoToxicGrass81720_ appear in some contexts)
- **Bio:** *"I'm not telling my name. But I made this account to make ThryveTech regret their choices."*

This confirms the account belongs to the disgruntled former employee and sets the motive for the leak trail.

Relevant posts from around 7 August 2026 include media attachments. One notable post contains an image that appears to show a **Google AI Studio / Gemini API key**.

### 2. The Fake API Key is Base64

The string visible in the image (or extracted from it) is:

```
b3dvMxtaIHUvT2stSHVja2xlYmVycnk3OTMwlFobM293b9OP3qBgS++/vQ=
```

This is **not** a real Google API key. Decoding it as Base64 yields (with some binary noise):

```
owo3\x1bZ u/Ok-Huckleberry7930\x94Z\x1b3owo\xd3\x8f\xde\xa0`K\xef\xbf\xbd
```

The clear, readable portion is the Reddit username:

**`u/Ok-Huckleberry7930`**

### 3. Reddit Breadcrumb

Visiting the Reddit profile:

- [https://www.reddit.com/user/Ok-Huckleberry7930](https://www.reddit.com/user/Ok-Huckleberry7930)

There is a post titled **"ToxicGrass"** (or similar) containing a long string of Brainfuck code:

```
-[------->+<]>+.[-->+++<]>.------.+++++.-[->+++++<]>-.+[----->+<]>.--[--->+<]>.-[---->+<]>++.---[->++++<]>-.++++[->+++<]>.--.-[--->+<]>----.-------------.[--->+<]>---.[---->+<]>+++.+[->+++<]>.++++++++++++.--..++++++++.-------.-----.+++++++++++.+++++.-[---->+<]>++.---[->++++<]>.-----.[--->+<]>-----.+++++[->+++<]>.+++++++.+[->+++<]>.+++++++++++++.++.------------.++++++++++.---.++++++++.+[---->+<]>++.>-[--->+<]>-.[---->+++++<]>-.++++++++++.+++++++.---.+[->+++<]>.>-[--->+<]>-.-[----->+++<]>.--.+++++.[->+++<]>++.>++++++++++..--[----->+<]>.++++++++++++..----.+++.+[-->+<]>.-----------..[--->+<]>-.+++++.++++++++++.+++[->+++<]>+.++++++++++++.+++.--------------.[->+++<]>++.+[--->+<]>++..--[->+++<]>.[--->+<]>++++++.[->+++<]>++.-[-->+++<]>+.--[--->+<]>.+.>+[--->++<]>.---------.+++++++++++++.---.+.
```

### 4. Brainfuck Decoding

Running the Brainfuck code produces:

```
Join my secret community to overthrow ThryveTech:

https://discord.gg/kCdvwVMZWX
```

### 5. Discord Server

Joining the Discord invite leads to a message from the user **YoToxicGrass** (or similar display name with role `[THRV]`):

> Yeah, I saved everything. I knew this day would come.  
> Check out: https://thryvectf.org/2LkuPiEPUpQqE112zK2WL1PMb

### 6. Final Flag Page

The linked page contains:

```
Good job dude you earned this!
Flag: Thryve{f8b9f764e48829ffea56e5bc463286c8}
```

## Flag

```
Thryve{f8b9f764e48829ffea56e5bc463286c8}
```

## Summary of the Trail

```
YoToxicGrass (X/Twitter)
        ↓
Base64-encoded "API key" image
        ↓
u/Ok-Huckleberry7930 (Reddit)
        ↓
Brainfuck payload
        ↓
Discord invite
        ↓
Final flag page
```

This is a classic multi-platform OSINT / steganography-style trail using encoding techniques (Base64 + Brainfuck) to hide successive breadcrumbs.
