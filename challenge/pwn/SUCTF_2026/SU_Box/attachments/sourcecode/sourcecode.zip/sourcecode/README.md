J2V8的官方仓库：https://github.com/eclipsesource/J2V8/tree/master
切换到这个commit 00dddaa31a80782abbe93c4a01f325db3c4975d6，然后编译一份linux-x86_64.jar
剩下的就是环境布置的信息