import 'package:flutter_test/flutter_test.dart';

import 'package:flumel/main.dart';

void main() {
  testWidgets('CTF screen renders', (WidgetTester tester) async {
    await tester.pumpWidget(const CtfApp());

    expect(
      find.text('Later, respectively, wander and suffer sorrow.'),
      findsOneWidget,
    );
    expect(find.text('flumel'), findsOneWidget);
    expect(find.text('Verify'), findsOneWidget);
  });
}
