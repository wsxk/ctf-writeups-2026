#include <array>
#include <cstdint>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <string>
#include <vector>

#if defined(__ANDROID__)
#include <dirent.h>
#endif

#if !defined(NO_HERMES_RUNTIME)
#include <hermes/hermes.h>
#include <jsi/jsi.h>
#endif

#if defined(_WIN32)
#define CTF_EXPORT extern "C" __declspec(dllexport)
#else
#define CTF_EXPORT extern "C" __attribute__((visibility("default")))
#endif

namespace {

constexpr int kPayloadLen = 36;
constexpr size_t kBlockSize = 16;
constexpr size_t kCipherLen = 48;

constexpr std::array<uint8_t, 16> kAesKey = {
    'y', 'o', 'u', 'k', 'n', 'o', 'w', 'w',
    'h', 'a', 't', 'I', 'm', 'e', 'a', 'n'};

constexpr std::array<uint8_t, 16> kAesIv = {
    'i', 't', 's', 'a', 'l', 'l', 'i', 'n',
    't', 'h', 'e', 'f', 'l', 'o', 'w', '!'};

constexpr std::array<uint8_t, 256> kSbox = {
    0x63, 0x7c, 0x77, 0x7b, 0xf2, 0x6b, 0x6f, 0xc5, 0x30, 0x01, 0x67, 0x2b,
    0xfe, 0xd7, 0xab, 0x76, 0xca, 0x82, 0xc9, 0x7d, 0xfa, 0x59, 0x47, 0xf0,
    0xad, 0xd4, 0xa2, 0xaf, 0x9c, 0xa4, 0x72, 0xc0, 0xb7, 0xfd, 0x93, 0x26,
    0x36, 0x3f, 0xf7, 0xcc, 0x34, 0xa5, 0xe5, 0xf1, 0x71, 0xd8, 0x31, 0x15,
    0x04, 0xc7, 0x23, 0xc3, 0x18, 0x96, 0x05, 0x9a, 0x07, 0x12, 0x80, 0xe2,
    0xeb, 0x27, 0xb2, 0x75, 0x09, 0x83, 0x2c, 0x1a, 0x1b, 0x6e, 0x5a, 0xa0,
    0x52, 0x3b, 0xd6, 0xb3, 0x29, 0xe3, 0x2f, 0x84, 0x53, 0xd1, 0x00, 0xed,
    0x20, 0xfc, 0xb1, 0x5b, 0x6a, 0xcb, 0xbe, 0x39, 0x4a, 0x4c, 0x58, 0xcf,
    0xd0, 0xef, 0xaa, 0xfb, 0x43, 0x4d, 0x33, 0x85, 0x45, 0xf9, 0x02, 0x7f,
    0x50, 0x3c, 0x9f, 0xa8, 0x51, 0xa3, 0x40, 0x8f, 0x92, 0x9d, 0x38, 0xf5,
    0xbc, 0xb6, 0xda, 0x21, 0x10, 0xff, 0xf3, 0xd2, 0xcd, 0x0c, 0x13, 0xec,
    0x5f, 0x97, 0x44, 0x17, 0xc4, 0xa7, 0x7e, 0x3d, 0x64, 0x5d, 0x19, 0x73,
    0x60, 0x81, 0x4f, 0xdc, 0x22, 0x2a, 0x90, 0x88, 0x46, 0xee, 0xb8, 0x14,
    0xde, 0x5e, 0x0b, 0xdb, 0xe0, 0x32, 0x3a, 0x0a, 0x49, 0x06, 0x24, 0x5c,
    0xc2, 0xd3, 0xac, 0x62, 0x91, 0x95, 0xe4, 0x79, 0xe7, 0xc8, 0x37, 0x6d,
    0x8d, 0xd5, 0x4e, 0xa9, 0x6c, 0x56, 0xf4, 0xea, 0x65, 0x7a, 0xae, 0x08,
    0xba, 0x78, 0x25, 0x2e, 0x1c, 0xa6, 0xb4, 0xc6, 0xe8, 0xdd, 0x74, 0x1f,
    0x4b, 0xbd, 0x8b, 0x8a, 0x70, 0x3e, 0xb5, 0x66, 0x48, 0x03, 0xf6, 0x0e,
    0x61, 0x35, 0x57, 0xb9, 0x86, 0xc1, 0x1d, 0x9e, 0xe1, 0xf8, 0x98, 0x11,
    0x69, 0xd9, 0x8e, 0x94, 0x9b, 0x1e, 0x87, 0xe9, 0xce, 0x55, 0x28, 0xdf,
    0x8c, 0xa1, 0x89, 0x0d, 0xbf, 0xe6, 0x42, 0x68, 0x41, 0x99, 0x2d, 0x0f,
    0xb0, 0x54, 0xbb, 0x16};

constexpr std::array<uint8_t, 256> kInvSbox = {
    0x52, 0x09, 0x6a, 0xd5, 0x30, 0x36, 0xa5, 0x38, 0xbf, 0x40, 0xa3, 0x9e,
    0x81, 0xf3, 0xd7, 0xfb, 0x7c, 0xe3, 0x39, 0x82, 0x9b, 0x2f, 0xff, 0x87,
    0x34, 0x8e, 0x43, 0x44, 0xc4, 0xde, 0xe9, 0xcb, 0x54, 0x7b, 0x94, 0x32,
    0xa6, 0xc2, 0x23, 0x3d, 0xee, 0x4c, 0x95, 0x0b, 0x42, 0xfa, 0xc3, 0x4e,
    0x08, 0x2e, 0xa1, 0x66, 0x28, 0xd9, 0x24, 0xb2, 0x76, 0x5b, 0xa2, 0x49,
    0x6d, 0x8b, 0xd1, 0x25, 0x72, 0xf8, 0xf6, 0x64, 0x86, 0x68, 0x98, 0x16,
    0xd4, 0xa4, 0x5c, 0xcc, 0x5d, 0x65, 0xb6, 0x92, 0x6c, 0x70, 0x48, 0x50,
    0xfd, 0xed, 0xb9, 0xda, 0x5e, 0x15, 0x46, 0x57, 0xa7, 0x8d, 0x9d, 0x84,
    0x90, 0xd8, 0xab, 0x00, 0x8c, 0xbc, 0xd3, 0x0a, 0xf7, 0xe4, 0x58, 0x05,
    0xb8, 0xb3, 0x45, 0x06, 0xd0, 0x2c, 0x1e, 0x8f, 0xca, 0x3f, 0x0f, 0x02,
    0xc1, 0xaf, 0xbd, 0x03, 0x01, 0x13, 0x8a, 0x6b, 0x3a, 0x91, 0x11, 0x41,
    0x4f, 0x67, 0xdc, 0xea, 0x97, 0xf2, 0xcf, 0xce, 0xf0, 0xb4, 0xe6, 0x73,
    0x96, 0xac, 0x74, 0x22, 0xe7, 0xad, 0x35, 0x85, 0xe2, 0xf9, 0x37, 0xe8,
    0x1c, 0x75, 0xdf, 0x6e, 0x47, 0xf1, 0x1a, 0x71, 0x1d, 0x29, 0xc5, 0x89,
    0x6f, 0xb7, 0x62, 0x0e, 0xaa, 0x18, 0xbe, 0x1b, 0xfc, 0x56, 0x3e, 0x4b,
    0xc6, 0xd2, 0x79, 0x20, 0x9a, 0xdb, 0xc0, 0xfe, 0x78, 0xcd, 0x5a, 0xf4,
    0x1f, 0xdd, 0xa8, 0x33, 0x88, 0x07, 0xc7, 0x31, 0xb1, 0x12, 0x10, 0x59,
    0x27, 0x80, 0xec, 0x5f, 0x60, 0x51, 0x7f, 0xa9, 0x19, 0xb5, 0x4a, 0x0d,
    0x2d, 0xe5, 0x7a, 0x9f, 0x93, 0xc9, 0x9c, 0xef, 0xa0, 0xe0, 0x3b, 0x4d,
    0xae, 0x2a, 0xf5, 0xb0, 0xc8, 0xeb, 0xbb, 0x3c, 0x83, 0x53, 0x99, 0x61,
    0x17, 0x2b, 0x04, 0x7e, 0xba, 0x77, 0xd6, 0x26, 0xe1, 0x69, 0x14, 0x63,
    0x55, 0x21, 0x0c, 0x7d};

constexpr std::array<uint8_t, 10> kRcon = {
    0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40, 0x80, 0x1b, 0x36};

constexpr uint32_t kBundleChk0 = 0xc9b1af71U;
constexpr uint32_t kBundleChk1 = 0x3094a854U;
constexpr uint32_t kBundleChk2 = 0x4515e60cU;
constexpr std::array<uint8_t, kCipherLen> kCipherTarget = {
    0x56, 0x96, 0x70, 0xde, 0x6d, 0x7e, 0x27, 0x0e, 0x7e, 0x27, 0xa1, 0x89,
    0xce, 0xc7, 0x08, 0x2b, 0xa1, 0x88, 0x3f, 0x69, 0x79, 0x66, 0x31, 0xad,
    0xbd, 0x7c, 0x6d, 0x0f, 0xea, 0x9f, 0x28, 0x1d, 0x60, 0xf9, 0xd1, 0x27,
    0x7f, 0x1b, 0x00, 0x7c, 0x36, 0xd6, 0x31, 0x72, 0x77, 0x53, 0xed, 0xcf};

uint8_t rotl8(uint8_t value, unsigned int shift) {
    return static_cast<uint8_t>((value << shift) | (value >> (8U - shift)));
}

uint8_t rotr8(uint8_t value, unsigned int shift) {
    return static_cast<uint8_t>((value >> shift) | (value << (8U - shift)));
}

uint32_t xorshift32(uint32_t value) {
    value ^= value << 13U;
    value ^= value >> 17U;
    value ^= value << 5U;
    return value;
}

uint8_t gfMul(uint8_t a, uint8_t b) {
    uint8_t p = 0;
    uint8_t x = a;
    uint8_t y = b;
    for (int i = 0; i < 8; ++i) {
        if ((y & 1U) != 0U) {
            p ^= x;
        }
        const bool hi = (x & 0x80U) != 0U;
        x = static_cast<uint8_t>(x << 1U);
        if (hi) {
            x ^= 0x1bU;
        }
        y = static_cast<uint8_t>(y >> 1U);
    }
    return p;
}

std::array<uint8_t, 176> expandKey(const std::array<uint8_t, 16>& key) {
    std::array<uint8_t, 176> out{};
    for (size_t i = 0; i < key.size(); ++i) {
        out[i] = key[i];
    }

    std::array<uint8_t, 4> temp{};
    size_t bytes = 16;
    int round = 0;
    while (bytes < out.size()) {
        for (size_t i = 0; i < temp.size(); ++i) {
            temp[i] = out[bytes - 4 + i];
        }

        if ((bytes % 16U) == 0U) {
            const uint8_t first = temp[0];
            temp[0] = temp[1];
            temp[1] = temp[2];
            temp[2] = temp[3];
            temp[3] = first;
            for (size_t i = 0; i < temp.size(); ++i) {
                temp[i] = kSbox[temp[i]];
            }
            temp[0] ^= kRcon[static_cast<size_t>(round++)];
        }

        for (size_t i = 0; i < temp.size(); ++i) {
            out[bytes] = static_cast<uint8_t>(out[bytes - 16] ^ temp[i]);
            ++bytes;
        }
    }

    return out;
}

void addRoundKey(
    std::array<uint8_t, 16>& state,
    const std::array<uint8_t, 176>& roundKeys,
    int round) {
    const size_t base = static_cast<size_t>(round) * 16U;
    for (size_t i = 0; i < state.size(); ++i) {
        state[i] ^= roundKeys[base + i];
    }
}

void subBytes(std::array<uint8_t, 16>& state) {
    for (size_t i = 0; i < state.size(); ++i) {
        state[i] = kSbox[state[i]];
    }
}

void invSubBytes(std::array<uint8_t, 16>& state) {
    for (size_t i = 0; i < state.size(); ++i) {
        state[i] = kInvSbox[state[i]];
    }
}

void shiftRows(std::array<uint8_t, 16>& state) {
    const auto t = state;
    state[1] = t[5];
    state[5] = t[9];
    state[9] = t[13];
    state[13] = t[1];

    state[2] = t[10];
    state[6] = t[14];
    state[10] = t[2];
    state[14] = t[6];

    state[3] = t[15];
    state[7] = t[3];
    state[11] = t[7];
    state[15] = t[11];
}

void invShiftRows(std::array<uint8_t, 16>& state) {
    const auto t = state;
    state[1] = t[13];
    state[5] = t[1];
    state[9] = t[5];
    state[13] = t[9];

    state[2] = t[10];
    state[6] = t[14];
    state[10] = t[2];
    state[14] = t[6];

    state[3] = t[7];
    state[7] = t[11];
    state[11] = t[15];
    state[15] = t[3];
}

void mixColumns(std::array<uint8_t, 16>& state) {
    for (int c = 0; c < 4; ++c) {
        const int i = c * 4;
        const uint8_t a0 = state[i];
        const uint8_t a1 = state[i + 1];
        const uint8_t a2 = state[i + 2];
        const uint8_t a3 = state[i + 3];
        state[i] = static_cast<uint8_t>(gfMul(a0, 2) ^ gfMul(a1, 3) ^ a2 ^ a3);
        state[i + 1] = static_cast<uint8_t>(a0 ^ gfMul(a1, 2) ^ gfMul(a2, 3) ^ a3);
        state[i + 2] = static_cast<uint8_t>(a0 ^ a1 ^ gfMul(a2, 2) ^ gfMul(a3, 3));
        state[i + 3] = static_cast<uint8_t>(gfMul(a0, 3) ^ a1 ^ a2 ^ gfMul(a3, 2));
    }
}

void invMixColumns(std::array<uint8_t, 16>& state) {
    for (int c = 0; c < 4; ++c) {
        const int i = c * 4;
        const uint8_t a0 = state[i];
        const uint8_t a1 = state[i + 1];
        const uint8_t a2 = state[i + 2];
        const uint8_t a3 = state[i + 3];
        state[i] = static_cast<uint8_t>(
            gfMul(a0, 14) ^ gfMul(a1, 11) ^ gfMul(a2, 13) ^ gfMul(a3, 9));
        state[i + 1] = static_cast<uint8_t>(
            gfMul(a0, 9) ^ gfMul(a1, 14) ^ gfMul(a2, 11) ^ gfMul(a3, 13));
        state[i + 2] = static_cast<uint8_t>(
            gfMul(a0, 13) ^ gfMul(a1, 9) ^ gfMul(a2, 14) ^ gfMul(a3, 11));
        state[i + 3] = static_cast<uint8_t>(
            gfMul(a0, 11) ^ gfMul(a1, 13) ^ gfMul(a2, 9) ^ gfMul(a3, 14));
    }
}

void aesEncryptBlock(
    std::array<uint8_t, 16>& state,
    const std::array<uint8_t, 176>& roundKeys) {
    addRoundKey(state, roundKeys, 0);
    for (int round = 1; round <= 9; ++round) {
        subBytes(state);
        shiftRows(state);
        mixColumns(state);
        addRoundKey(state, roundKeys, round);
    }
    subBytes(state);
    shiftRows(state);
    addRoundKey(state, roundKeys, 10);
}

void aesDecryptBlock(
    std::array<uint8_t, 16>& state,
    const std::array<uint8_t, 176>& roundKeys) {
    addRoundKey(state, roundKeys, 10);
    for (int round = 9; round >= 1; --round) {
        invShiftRows(state);
        invSubBytes(state);
        addRoundKey(state, roundKeys, round);
        invMixColumns(state);
    }
    invShiftRows(state);
    invSubBytes(state);
    addRoundKey(state, roundKeys, 0);
}

std::vector<uint8_t> extraEncrypt(const uint8_t* input, size_t len) {
    std::vector<uint8_t> out(len, 0);
    uint32_t state = 0x31415926U;
    for (size_t i = 0; i < len; ++i) {
        state = xorshift32(
            state + 0x9e3779b9U + static_cast<uint32_t>(i) +
            kAesKey[(i * 7U + 3U) % kAesKey.size()]);
        const uint8_t ks = static_cast<uint8_t>((state >> ((i & 3U) * 8U)) & 0xffU);
        out[i] = rotl8(static_cast<uint8_t>(input[i] ^ ks), static_cast<unsigned int>((i % 5U) + 1U));
    }
    return out;
}

std::vector<uint8_t> extraDecrypt(const std::vector<uint8_t>& input) {
    std::vector<uint8_t> out(input.size(), 0);
    uint32_t state = 0x31415926U;
    for (size_t i = 0; i < input.size(); ++i) {
        state = xorshift32(
            state + 0x9e3779b9U + static_cast<uint32_t>(i) +
            kAesKey[(i * 7U + 3U) % kAesKey.size()]);
        const uint8_t ks = static_cast<uint8_t>((state >> ((i & 3U) * 8U)) & 0xffU);
        out[i] = static_cast<uint8_t>(
            rotr8(input[i], static_cast<unsigned int>((i % 5U) + 1U)) ^ ks);
    }
    return out;
}

std::vector<uint8_t> aesCbcEncryptWith(
    const std::vector<uint8_t>& input,
    const std::array<uint8_t, 16>& key,
    const std::array<uint8_t, 16>& iv) {
    auto roundKeys = expandKey(key);

    std::vector<uint8_t> plain = input;
    const uint8_t pad = static_cast<uint8_t>(kBlockSize - (plain.size() % kBlockSize));
    plain.insert(plain.end(), pad, pad);

    std::vector<uint8_t> out;
    out.reserve(plain.size());
    std::array<uint8_t, 16> prev = iv;

    for (size_t offset = 0; offset < plain.size(); offset += kBlockSize) {
        std::array<uint8_t, 16> block{};
        for (size_t i = 0; i < kBlockSize; ++i) {
            block[i] = static_cast<uint8_t>(plain[offset + i] ^ prev[i]);
        }
        aesEncryptBlock(block, roundKeys);
        out.insert(out.end(), block.begin(), block.end());
        prev = block;
    }
    return out;
}

std::vector<uint8_t> aesCbcDecryptWith(
    const std::vector<uint8_t>& input,
    const std::array<uint8_t, 16>& key,
    const std::array<uint8_t, 16>& iv,
    bool& ok) {
    ok = false;
    if (input.empty() || (input.size() % kBlockSize) != 0U) {
        return {};
    }

    auto roundKeys = expandKey(key);
    std::vector<uint8_t> plain;
    plain.reserve(input.size());
    std::array<uint8_t, 16> prev = iv;

    for (size_t offset = 0; offset < input.size(); offset += kBlockSize) {
        std::array<uint8_t, 16> curr{};
        std::array<uint8_t, 16> block{};
        for (size_t i = 0; i < kBlockSize; ++i) {
            curr[i] = input[offset + i];
            block[i] = curr[i];
        }

        aesDecryptBlock(block, roundKeys);
        for (size_t i = 0; i < kBlockSize; ++i) {
            block[i] ^= prev[i];
        }

        plain.insert(plain.end(), block.begin(), block.end());
        prev = curr;
    }

    if (plain.empty()) {
        return {};
    }
    const uint8_t pad = plain.back();
    if (pad == 0U || pad > kBlockSize || pad > plain.size()) {
        return {};
    }
    for (size_t i = 0; i < pad; ++i) {
        if (plain[plain.size() - 1U - i] != pad) {
            return {};
        }
    }

    plain.resize(plain.size() - pad);
    ok = true;
    return plain;
}

std::vector<uint8_t> aesCbcEncrypt(const std::vector<uint8_t>& input) {
    return aesCbcEncryptWith(input, kAesKey, kAesIv);
}

std::vector<uint8_t> aesCbcDecrypt(const std::vector<uint8_t>& input, bool& ok) {
    return aesCbcDecryptWith(input, kAesKey, kAesIv, ok);
}

uint32_t d_rotl32(uint32_t value, uint32_t bits) {
    return (value << bits) | (value >> (32U - bits));
}

uint32_t d_rotr32(uint32_t value, uint32_t bits) {
    return (value >> bits) | (value << (32U - bits));
}

uint64_t d_rotl64(uint64_t value, uint32_t bits) {
    return (value << bits) | (value >> (64U - bits));
}

uint32_t d_fnv1a32(const uint8_t* data, size_t len) {
    uint32_t hash = 2166136261U;
    for (size_t i = 0; i < len; ++i) {
        hash ^= data[i];
        hash *= 16777619U;
    }
    return hash;
}

std::array<uint32_t, 256> d_crc32Table() {
    std::array<uint32_t, 256> table{};
    for (uint32_t i = 0; i < 256; ++i) {
        uint32_t c = i;
        for (int j = 0; j < 8; ++j) {
            c = (c & 1U) ? (0xedb88320U ^ (c >> 1U)) : (c >> 1U);
        }
        table[i] = c;
    }
    return table;
}

uint32_t d_crc32(const uint8_t* data, size_t len) {
    static const auto table = d_crc32Table();
    uint32_t crc = 0xffffffffU;
    for (size_t i = 0; i < len; ++i) {
        crc = table[(crc ^ data[i]) & 0xffU] ^ (crc >> 8U);
    }
    return ~crc;
}

void d_rc4Ksa(const uint8_t* key, size_t keyLen, std::array<uint8_t, 256>& s) {
    for (size_t i = 0; i < s.size(); ++i) {
        s[i] = static_cast<uint8_t>(i);
    }
    uint8_t j = 0;
    for (size_t i = 0; i < s.size(); ++i) {
        j = static_cast<uint8_t>(j + s[i] + key[i % keyLen]);
        std::swap(s[i], s[j]);
    }
}

void d_rc4Crypt(
    const std::array<uint8_t, 256>& s0,
    const uint8_t* input,
    uint8_t* output,
    size_t len) {
    auto s = s0;
    uint8_t i = 0;
    uint8_t j = 0;
    for (size_t n = 0; n < len; ++n) {
        i = static_cast<uint8_t>(i + 1U);
        j = static_cast<uint8_t>(j + s[i]);
        std::swap(s[i], s[j]);
        const uint8_t k = s[static_cast<uint8_t>(s[i] + s[j])];
        output[n] = static_cast<uint8_t>(input[n] ^ k);
    }
}

void d_teaEncryptBlock(
    uint32_t& v0,
    uint32_t& v1,
    const std::array<uint32_t, 4>& key) {
    uint32_t sum = 0;
    constexpr uint32_t delta = 0x9e3779b9U;
    for (int i = 0; i < 32; ++i) {
        sum += delta;
        v0 += ((v1 << 4U) + key[0]) ^ (v1 + sum) ^ ((v1 >> 5U) + key[1]);
        v1 += ((v0 << 4U) + key[2]) ^ (v0 + sum) ^ ((v0 >> 5U) + key[3]);
    }
}

void d_teaDecryptBlock(
    uint32_t& v0,
    uint32_t& v1,
    const std::array<uint32_t, 4>& key) {
    constexpr uint32_t delta = 0x9e3779b9U;
    uint32_t sum = delta * 32U;
    for (int i = 0; i < 32; ++i) {
        v1 -= ((v0 << 4U) + key[2]) ^ (v0 + sum) ^ ((v0 >> 5U) + key[3]);
        v0 -= ((v1 << 4U) + key[0]) ^ (v1 + sum) ^ ((v1 >> 5U) + key[1]);
        sum -= delta;
    }
}

void d_xxteaEncrypt(std::vector<uint32_t>& v, const std::array<uint32_t, 4>& key) {
    if (v.size() < 2) {
        return;
    }
    uint32_t rounds = 6U + static_cast<uint32_t>(52U / v.size());
    uint32_t sum = 0;
    uint32_t z = v.back();
    constexpr uint32_t delta = 0x9e3779b9U;
    while (rounds-- > 0U) {
        sum += delta;
        const uint32_t e = (sum >> 2U) & 3U;
        for (size_t p = 0; p < v.size() - 1; ++p) {
            const uint32_t y = v[p + 1];
            const uint32_t mx =
                ((z >> 5U) ^ (y << 2U)) + ((y >> 3U) ^ (z << 4U)) ^
                ((sum ^ y) + (key[(p & 3U) ^ e] ^ z));
            z = (v[p] += mx);
        }
        const uint32_t y = v[0];
        const size_t p = v.size() - 1;
        const uint32_t mx =
            ((z >> 5U) ^ (y << 2U)) + ((y >> 3U) ^ (z << 4U)) ^
            ((sum ^ y) + (key[(p & 3U) ^ e] ^ z));
        z = (v[p] += mx);
    }
}

void d_xxteaDecrypt(std::vector<uint32_t>& v, const std::array<uint32_t, 4>& key) {
    if (v.size() < 2) {
        return;
    }
    constexpr uint32_t delta = 0x9e3779b9U;
    uint32_t rounds = 6U + static_cast<uint32_t>(52U / v.size());
    uint32_t sum = rounds * delta;
    uint32_t y = v[0];
    while (sum != 0U) {
        const uint32_t e = (sum >> 2U) & 3U;
        for (size_t p = v.size() - 1; p > 0; --p) {
            const uint32_t z = v[p - 1];
            const uint32_t mx =
                ((z >> 5U) ^ (y << 2U)) + ((y >> 3U) ^ (z << 4U)) ^
                ((sum ^ y) + (key[(p & 3U) ^ e] ^ z));
            y = (v[p] -= mx);
        }
        const uint32_t z = v.back();
        const uint32_t mx =
            ((z >> 5U) ^ (y << 2U)) + ((y >> 3U) ^ (z << 4U)) ^
            ((sum ^ y) + (key[e] ^ z));
        y = (v[0] -= mx);
        sum -= delta;
    }
}

std::array<uint32_t, 5> d_sha1(const uint8_t* data, size_t len) {
    std::array<uint32_t, 5> h = {
        0x67452301U, 0xefcdab89U, 0x98badcfeU, 0x10325476U, 0xc3d2e1f0U};

    std::vector<uint8_t> msg(data, data + len);
    msg.push_back(0x80U);
    while ((msg.size() % 64U) != 56U) {
        msg.push_back(0);
    }
    const uint64_t bitLen = static_cast<uint64_t>(len) * 8U;
    for (int i = 7; i >= 0; --i) {
        msg.push_back(static_cast<uint8_t>((bitLen >> (i * 8)) & 0xffU));
    }

    for (size_t off = 0; off < msg.size(); off += 64U) {
        std::array<uint32_t, 80> w{};
        for (size_t i = 0; i < 16; ++i) {
            w[i] = (static_cast<uint32_t>(msg[off + i * 4]) << 24U) |
                   (static_cast<uint32_t>(msg[off + i * 4 + 1]) << 16U) |
                   (static_cast<uint32_t>(msg[off + i * 4 + 2]) << 8U) |
                   static_cast<uint32_t>(msg[off + i * 4 + 3]);
        }
        for (size_t i = 16; i < 80; ++i) {
            w[i] = d_rotl32(w[i - 3] ^ w[i - 8] ^ w[i - 14] ^ w[i - 16], 1U);
        }

        uint32_t a = h[0];
        uint32_t b = h[1];
        uint32_t c = h[2];
        uint32_t d = h[3];
        uint32_t e = h[4];

        for (size_t i = 0; i < 80; ++i) {
            uint32_t f = 0;
            uint32_t k = 0;
            if (i < 20) {
                f = (b & c) | ((~b) & d);
                k = 0x5a827999U;
            } else if (i < 40) {
                f = b ^ c ^ d;
                k = 0x6ed9eba1U;
            } else if (i < 60) {
                f = (b & c) | (b & d) | (c & d);
                k = 0x8f1bbcdcU;
            } else {
                f = b ^ c ^ d;
                k = 0xca62c1d6U;
            }
            const uint32_t temp = d_rotl32(a, 5U) + f + e + k + w[i];
            e = d;
            d = c;
            c = d_rotl32(b, 30U);
            b = a;
            a = temp;
        }

        h[0] += a;
        h[1] += b;
        h[2] += c;
        h[3] += d;
        h[4] += e;
    }

    return h;
}

void d_chacha20Block(
    const std::array<uint32_t, 8>& key,
    uint32_t counter,
    const std::array<uint32_t, 3>& nonce,
    std::array<uint32_t, 16>& out) {
    std::array<uint32_t, 16> st = {
        0x61707865U, 0x3320646eU, 0x79622d32U, 0x6b206574U,
        key[0],      key[1],      key[2],      key[3],
        key[4],      key[5],      key[6],      key[7],
        counter,     nonce[0],    nonce[1],    nonce[2]};

    auto qr = [&st](int a, int b, int c, int d) {
        st[a] += st[b];
        st[d] ^= st[a];
        st[d] = d_rotl32(st[d], 16U);
        st[c] += st[d];
        st[b] ^= st[c];
        st[b] = d_rotl32(st[b], 12U);
        st[a] += st[b];
        st[d] ^= st[a];
        st[d] = d_rotl32(st[d], 8U);
        st[c] += st[d];
        st[b] ^= st[c];
        st[b] = d_rotl32(st[b], 7U);
    };

    auto work = st;
    for (int i = 0; i < 10; ++i) {
        qr(0, 4, 8, 12);
        qr(1, 5, 9, 13);
        qr(2, 6, 10, 14);
        qr(3, 7, 11, 15);
        qr(0, 5, 10, 15);
        qr(1, 6, 11, 12);
        qr(2, 7, 8, 13);
        qr(3, 4, 9, 14);
    }
    for (size_t i = 0; i < out.size(); ++i) {
        out[i] = work[i] + st[i];
    }
}

uint64_t d_sipRound(uint64_t v0, uint64_t v1, uint64_t v2, uint64_t v3) {
    v0 += v1;
    v2 += v3;
    v1 = d_rotl64(v1, 13);
    v3 = d_rotl64(v3, 16);
    v1 ^= v0;
    v3 ^= v2;
    v0 = d_rotl64(v0, 32);
    v2 += v1;
    v0 += v3;
    v1 = d_rotl64(v1, 17);
    v3 = d_rotl64(v3, 21);
    v1 ^= v2;
    v3 ^= v0;
    v2 = d_rotl64(v2, 32);
    return v0 ^ v1 ^ v2 ^ v3;
}

uint32_t d_polySeed(const uint8_t* data, size_t len) {
    uint64_t acc = 0x736f6d6570736575ULL;
    for (size_t i = 0; i < len; ++i) {
        acc ^= static_cast<uint64_t>(data[i]) << ((i & 7U) * 8U);
        acc = d_rotl64(acc * 0x100000001b3ULL, 9U);
        acc ^= 0x646f72616e646f6dULL;
    }
    return static_cast<uint32_t>(acc ^ (acc >> 32U));
}

uint64_t d_blendDigest(const uint8_t* data, size_t len) {
    const uint32_t a = d_fnv1a32(data, len);
    const uint32_t b = d_crc32(data, len);
    const uint32_t c = d_polySeed(data, len);
    std::array<uint32_t, 3> v = {a, b, c};
    std::vector<uint32_t> vv(v.begin(), v.end());
    d_xxteaEncrypt(vv, {0x11U, 0x22U, 0x33U, 0x44U});
    return (static_cast<uint64_t>(vv[0]) << 32U) | vv[1];
}

#if defined(__ANDROID__)
bool containsFridaToken(const std::string& line) {
    static constexpr const char* kNeedles[] = {
        "frida", "gum-js-loop", "gmain", "linjector", "frida-agent", "frida-gadget"};
    for (const char* needle : kNeedles) {
        if (line.find(needle) != std::string::npos) {
            return true;
        }
    }
    return false;
}

bool tracerPidPresent() {
    std::ifstream status("/proc/self/status");
    if (!status.is_open()) {
        return false;
    }
    std::string line;
    while (std::getline(status, line)) {
        if (line.rfind("TracerPid:", 0) == 0) {
            const int tracer = std::atoi(line.c_str() + std::strlen("TracerPid:"));
            return tracer > 0;
        }
    }
    return false;
}

bool mapsContainFrida() {
    std::ifstream maps("/proc/self/maps");
    if (!maps.is_open()) {
        return false;
    }
    std::string line;
    while (std::getline(maps, line)) {
        if (containsFridaToken(line)) {
            return true;
        }
    }
    return false;
}

bool threadNamesContainFrida() {
    DIR* taskDir = opendir("/proc/self/task");
    if (taskDir == nullptr) {
        return false;
    }
    bool hit = false;
    while (dirent* entry = readdir(taskDir)) {
        if (entry->d_name[0] == '.') {
            continue;
        }
        std::string path = "/proc/self/task/";
        path.append(entry->d_name);
        path.append("/comm");

        std::ifstream comm(path);
        std::string line;
        if (comm.is_open() && std::getline(comm, line) && containsFridaToken(line)) {
            hit = true;
            break;
        }
    }
    closedir(taskDir);
    return hit;
}

bool tamperDetected() {
    return tracerPidPresent() || mapsContainFrida() || threadNamesContainFrida();
}
#else
bool tamperDetected() {
    return false;
}
#endif

uint32_t u00(uint32_t v) { return ((v * 3U) ^ 0x15U) & 0xffffU; }
uint32_t u01(uint32_t v) { return ((v * 5U) ^ 0x27U) & 0xffffU; }
uint32_t u02(uint32_t v) { return ((v * 7U) ^ 0x39U) & 0xffffU; }
uint32_t u03(uint32_t v) { return ((v * 9U) ^ 0x4bU) & 0xffffU; }
uint32_t u04(uint32_t v) { return ((v * 11U) ^ 0x5dU) & 0xffffU; }
uint32_t u05(uint32_t v) { return ((v * 13U) ^ 0x6fU) & 0xffffU; }
uint32_t u06(uint32_t v) { return ((v * 15U) ^ 0x81U) & 0xffffU; }
uint32_t u07(uint32_t v) { return ((v * 17U) ^ 0x93U) & 0xffffU; }
uint32_t u08(uint32_t v) { return ((v * 19U) ^ 0xa5U) & 0xffffU; }
uint32_t u09(uint32_t v) { return ((v * 21U) ^ 0xb7U) & 0xffffU; }
uint32_t u10(uint32_t v) { return ((v * 23U) ^ 0xc9U) & 0xffffU; }
uint32_t u11(uint32_t v) { return ((v * 25U) ^ 0xdbU) & 0xffffU; }
uint32_t u12(uint32_t v) { return ((v * 27U) ^ 0xedU) & 0xffffU; }
uint32_t u13(uint32_t v) { return ((v * 29U) ^ 0xffU) & 0xffffU; }
uint32_t u14(uint32_t v) { return ((v * 31U) ^ 0x111U) & 0xffffU; }
uint32_t u15(uint32_t v) { return ((v * 33U) ^ 0x123U) & 0xffffU; }
uint32_t u16(uint32_t v) { return ((v * 35U) ^ 0x135U) & 0xffffU; }
uint32_t u17(uint32_t v) { return ((v * 37U) ^ 0x147U) & 0xffffU; }
uint32_t u18(uint32_t v) { return ((v * 39U) ^ 0x159U) & 0xffffU; }
uint32_t u19(uint32_t v) { return ((v * 41U) ^ 0x16bU) & 0xffffU; }
uint32_t u20(uint32_t v) { return ((v * 43U) ^ 0x17dU) & 0xffffU; }
uint32_t u21(uint32_t v) { return ((v * 45U) ^ 0x18fU) & 0xffffU; }
uint32_t u22(uint32_t v) { return ((v * 47U) ^ 0x1a1U) & 0xffffU; }
uint32_t u23(uint32_t v) { return ((v * 49U) ^ 0x1b3U) & 0xffffU; }

uint32_t ux0(const uint8_t* data, size_t len) {
    uint32_t acc = 0x3a5cU;
    for (size_t i = 0; i < len; ++i) {
        const uint32_t x = static_cast<uint32_t>(data[i]) + static_cast<uint32_t>(i);
        switch (i & 7U) {
            case 0: acc ^= u00(x); break;
            case 1: acc ^= u03(x); break;
            case 2: acc ^= u06(x); break;
            case 3: acc ^= u09(x); break;
            case 4: acc ^= u12(x); break;
            case 5: acc ^= u15(x); break;
            case 6: acc ^= u18(x); break;
            default: acc ^= u21(x); break;
        }
        acc = static_cast<uint32_t>((acc << 1U) | (acc >> 31U));
    }
    return acc;
}

struct BundleState {
    uint32_t a;
    uint32_t b;
    uint32_t c;
};

BundleState deriveBundleState(const uint8_t* bundle, int bundle_len) {
    const size_t n = static_cast<size_t>(bundle_len);
    BundleState st{};
    st.a = d_fnv1a32(bundle, n);
    st.b = d_crc32(bundle, n);
    st.c = d_polySeed(bundle, n) ^ ux0(bundle, n);

    for (size_t i = 0; i < 96U; ++i) {
        const uint8_t x = bundle[
            (i * 131U + (st.a & 0xffU) + ((st.b >> ((i & 3U) * 8U)) & 0xffU)) % n];
        const uint8_t y = bundle[
            (i * 197U + (st.c & 0xffU) + ((st.a >> (((i + 1U) & 3U) * 8U)) & 0xffU)) % n];
        st.a = xorshift32(st.a + static_cast<uint32_t>(x) + static_cast<uint32_t>(i * 0x45d9U));
        st.b = d_rotl32(
            st.b ^ static_cast<uint32_t>(y + static_cast<uint8_t>(i)),
            static_cast<uint32_t>((i % 13U) + 3U));
        st.c = xorshift32(
            st.c + (st.a ^ st.b) + static_cast<uint32_t>(x * 33U + y * 17U));
    }

    return st;
}

bool checkBundleState(const BundleState& st) {
    const uint32_t t0 = xorshift32(st.a ^ 0x5c3a19d7U);
    const uint32_t t1 = xorshift32(st.b ^ 0x7f21b04dU);
    const uint32_t t2 = xorshift32(st.c ^ 0x1984ce63U);
    return t0 == kBundleChk0 && t1 == kBundleChk1 && t2 == kBundleChk2;
}

bool invokeHermesBundle(const uint8_t* bundle, int bundle_len) {
#if defined(NO_HERMES_RUNTIME)
    (void)bundle;
    (void)bundle_len;
    return true;
#else
    class StaticBuffer final : public facebook::jsi::Buffer {
    public:
        explicit StaticBuffer(const uint8_t* data, size_t len) : bytes_(data, data + len) {}
        size_t size() const override { return bytes_.size(); }
        const uint8_t* data() const override { return bytes_.data(); }

    private:
        std::vector<uint8_t> bytes_;
    };

    try {
        if (!facebook::hermes::HermesRuntime::isHermesBytecode(
                bundle, static_cast<size_t>(bundle_len))) {
            return false;
        }
        auto runtime = facebook::hermes::makeHermesRuntime();
        auto buffer = std::make_shared<StaticBuffer>(bundle, static_cast<size_t>(bundle_len));
        (void)runtime->evaluateJavaScript(buffer, "bundles/cache.snap.bundle");
        return true;
    } catch (...) {
        return false;
    }
#endif
}

void deriveRuntimeKeyIv(
    const uint8_t* bundle,
    int bundle_len,
    std::array<uint8_t, 16>& key_out,
    std::array<uint8_t, 16>& iv_out) {
    const size_t n = static_cast<size_t>(bundle_len);
    const uint8_t saltK = static_cast<uint8_t>(d_fnv1a32(bundle, n) & 0xffU);
    const uint8_t saltI = static_cast<uint8_t>((d_crc32(bundle, n) >> 8U) & 0xffU);

    for (size_t i = 0; i < 16U; ++i) {
        const uint8_t kb = bundle[(i * 17U + 11U) % n];
        const uint8_t ib = bundle[(i * 29U + 7U) % n];
        key_out[i] = static_cast<uint8_t>(kAesKey[i] ^ kb ^ static_cast<uint8_t>(saltK + i));
        iv_out[i] =
            static_cast<uint8_t>(kAesIv[i] ^ ib ^ static_cast<uint8_t>(saltI + i * 3U));
    }
}

bool checkCipherConstraints(const std::vector<uint8_t>& cipher) {
    if (cipher.size() != kCipherLen) {
        return false;
    }

    uint8_t diff = 0;
    for (size_t i = 0; i < kCipherLen; ++i) {
        diff |= static_cast<uint8_t>(cipher[i] ^ kCipherTarget[i]);
    }
    return diff == 0;
}

} // namespace

CTF_EXPORT int qk9v(
    const uint8_t* data,
    int len,
    const uint8_t* bundle,
    int bundle_len) {
    if (data == nullptr || len != kPayloadLen || bundle == nullptr || bundle_len < 256) {
        return 0;
    }
    if (tamperDetected()) {
        return 0;
    }

    const auto st = deriveBundleState(bundle, bundle_len);
    if (!checkBundleState(st)) {
        return 0;
    }
    if (!invokeHermesBundle(bundle, bundle_len)) {
        return 0;
    }

    std::array<uint8_t, 16> runtimeKey{};
    std::array<uint8_t, 16> runtimeIv{};
    deriveRuntimeKeyIv(bundle, bundle_len, runtimeKey, runtimeIv);

    std::vector<uint8_t> plain(data, data + len);
    const auto finalCipher = aesCbcEncryptWith(plain, runtimeKey, runtimeIv);
    return checkCipherConstraints(finalCipher) ? 1 : 0;
}
