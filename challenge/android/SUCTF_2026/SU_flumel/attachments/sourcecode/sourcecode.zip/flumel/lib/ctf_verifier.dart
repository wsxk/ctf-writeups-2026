import 'dart:async';
import 'dart:convert';
import 'dart:ffi' as ffi;
import 'dart:io';
import 'dart:isolate';

import 'package:ffi/ffi.dart';
import 'package:flutter/services.dart';

typedef _VerifyNative =
    ffi.Int32 Function(
      ffi.Pointer<ffi.Uint8>,
      ffi.Int32,
      ffi.Pointer<ffi.Uint8>,
      ffi.Int32,
    );
typedef _VerifyDart =
    int Function(ffi.Pointer<ffi.Uint8>, int, ffi.Pointer<ffi.Uint8>, int);

class CtfVerifier {
  static Future<Uint8List>? _bundleFuture;
  static const Duration _kVerifyTimeout = Duration(seconds: 8);
  static const Duration _kBundleLoadTimeout = Duration(seconds: 4);
  static const Duration _kNativeTimeout = Duration(seconds: 8);

  static Future<bool> verify(String candidate) async {
    try {
      final bundle = await _loadHermesBundle().timeout(
        _kBundleLoadTimeout,
        onTimeout: () => Uint8List(0),
      );
      if (bundle.isEmpty) {
        return false;
      }

      final rc4Encrypted = Rc4Warp(_buildRc4Key()).process(utf8.encode(candidate));
      return await _verifyInNativeAsync(
        Uint8List.fromList(rc4Encrypted),
        bundle,
      ).timeout(_kVerifyTimeout, onTimeout: () => false);
    } on Object {
      return false;
    }
  }

  static String _buildRc4Key() {
    const obf = [
      0x1f,
      0x3b,
      0x3f,
      0x03,
      0x00,
      0x0a,
      0xcf,
      0xe5,
      0xe7,
      0xe8,
      0xca,
      0xcc,
      0xd2,
    ];
    final out = List<int>.generate(
      obf.length,
      (index) => obf[index] ^ ((0x4b + index * 9) & 0xff),
    );
    return String.fromCharCodes(out);
  }

  static Future<Uint8List> _loadHermesBundle() {
    return _bundleFuture ??= rootBundle
        .load('bundles/cache.snap.bundle')
        .then(
          (data) =>
              data.buffer.asUint8List(data.offsetInBytes, data.lengthInBytes),
        );
  }

  static Future<bool> _verifyInNativeAsync(
    Uint8List payload,
    Uint8List bundle,
  ) async {
    final args = <Object>[
      Uint8List.fromList(payload),
      Uint8List.fromList(bundle),
    ];
    try {
      return await Isolate.run(() => _nativeWorker(args)).timeout(
        _kNativeTimeout,
        onTimeout: () => false,
      );
    } on Object {
      return false;
    }
  }
}

bool _nativeWorker(List<Object> args) {
  final payload = args[0] as Uint8List;
  final bundle = args[1] as Uint8List;

  if (!Platform.isAndroid) {
    return false;
  }

  final lib = ffi.DynamicLibrary.open('libjunk.so');
  final verify = lib.lookupFunction<_VerifyNative, _VerifyDart>('qk9v');

  final payloadPtr = malloc<ffi.Uint8>(payload.length);
  final bundlePtr = malloc<ffi.Uint8>(bundle.length);
  try {
    payloadPtr.asTypedList(payload.length).setAll(0, payload);
    bundlePtr.asTypedList(bundle.length).setAll(0, bundle);
    return verify(payloadPtr, payload.length, bundlePtr, bundle.length) == 1;
  } finally {
    malloc.free(payloadPtr);
    malloc.free(bundlePtr);
  }
}

class Rc4Warp {
  Rc4Warp(String key) : _key = utf8.encode(key);

  final List<int> _key;

  List<int> process(List<int> input) {
    final s = List<int>.generate(256, (index) => index);
    var j = 0;
    var salt = 0xc3;

    for (var i = 0; i < 256; i++) {
      final k0 = _key[(i * 5 + 1) % _key.length];
      final k1 = _key[(i * 3 + 7) % _key.length];
      salt = _rotl8(salt, 1);
      j = (j + s[i] + k0 + ((k1 ^ salt) & 0xff) + i) & 0xff;
      final tmp = s[i];
      s[i] = s[j];
      s[j] = tmp;
    }

    var i = 0;
    j = 0;
    var twist = 0x9d;
    final output = <int>[];
    for (final byte in input) {
      i = (i + 1) & 0xff;
      j = (j + s[i] + ((i * 11) & 0xff)) & 0xff;
      final tmp = s[i];
      s[i] = s[j];
      s[j] = tmp;
      final idx = (s[i] + s[j] + ((s[(i + j) & 0xff] ^ twist) & 0xff)) & 0xff;
      final k = s[idx];
      twist = _rotl8(twist, 3);
      final spice = s[(k ^ twist) & 0xff];
      output.add((byte ^ k ^ spice ^ ((i * 13) & 0xff)) & 0xff);
    }

    return output;
  }

  int _rotl8(int value, int shift) {
    return ((value << shift) | (value >> (8 - shift))) & 0xff;
  }
}
