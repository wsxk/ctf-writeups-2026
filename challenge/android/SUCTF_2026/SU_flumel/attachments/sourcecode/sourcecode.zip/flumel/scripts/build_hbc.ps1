param(
    [string]$HermescPath = "~/src/hermes/build-host/bin/hermesc",
    [switch]$Optimize
)

$ErrorActionPreference = "Stop"

$projectRoot = Split-Path -Parent $PSScriptRoot
$jsPathWin = Join-Path $projectRoot "bundles/cache.snap.bundle.js"
$bundlePathWin = Join-Path $projectRoot "bundles/cache.snap.bundle"

$jsPathWsl = "/mnt/" + $jsPathWin.Substring(0,1).ToLower() + $jsPathWin.Substring(2).Replace('\','/')
$bundlePathWsl = "/mnt/" + $bundlePathWin.Substring(0,1).ToLower() + $bundlePathWin.Substring(2).Replace('\','/')

$optFlag = if ($Optimize) { "-O" } else { "-O0" }
$cmd = "$HermescPath -emit-binary $optFlag -out `"$bundlePathWsl`" `"$jsPathWsl`""
wsl.exe -e bash -lc $cmd

Write-Output "Generated: $bundlePathWin"
