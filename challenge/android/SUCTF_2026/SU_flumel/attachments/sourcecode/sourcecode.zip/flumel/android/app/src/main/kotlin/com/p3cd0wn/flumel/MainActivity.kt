package com.p3cd0wn.flumel

import io.flutter.FlutterInjector
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        val p0 = z0()
        val p1 = z1(p0)
        val c0 = MethodChannel(flutterEngine.dartExecutor.binaryMessenger, p1.first)
        val m0 = p1.second.toSet()

        c0.setMethodCallHandler { call, result ->
            try {
                if (!m0.contains(call.method)) {
                    result.notImplemented()
                    return@setMethodCallHandler
                }

                val args = call.arguments as? Map<*, *>
                if (args == null) {
                    result.error("e0", "bad-args", null)
                    return@setMethodCallHandler
                }

                val step = (args["step"] as? Number)?.toInt() ?: 0
                val slot = (args["slot"] as? Number)?.toInt() ?: 0
                val state = (args["state"] as? Number)?.toInt() ?: 0
                val data = z2(args["data"])
                result.success(z3(data, step, slot, state, p0))
            } catch (t: Throwable) {
                result.error("e1", t.message ?: "handler-failed", null)
            }
        }
    }

    private fun x00(v: Int): Int = ((v * 3) xor 0x15) and 0xffff
    private fun x01(v: Int): Int = ((v * 5) xor 0x27) and 0xffff
    private fun x02(v: Int): Int = ((v * 7) xor 0x39) and 0xffff
    private fun x03(v: Int): Int = ((v * 9) xor 0x4b) and 0xffff
    private fun x04(v: Int): Int = ((v * 11) xor 0x5d) and 0xffff
    private fun x05(v: Int): Int = ((v * 13) xor 0x6f) and 0xffff
    private fun x06(v: Int): Int = ((v * 15) xor 0x81) and 0xffff
    private fun x07(v: Int): Int = ((v * 17) xor 0x93) and 0xffff
    private fun x08(v: Int): Int = ((v * 19) xor 0xa5) and 0xffff
    private fun x09(v: Int): Int = ((v * 21) xor 0xb7) and 0xffff
    private fun x10(v: Int): Int = ((v * 23) xor 0xc9) and 0xffff
    private fun x11(v: Int): Int = ((v * 25) xor 0xdb) and 0xffff
    private fun x12(v: Int): Int = ((v * 27) xor 0xed) and 0xffff
    private fun x13(v: Int): Int = ((v * 29) xor 0xff) and 0xffff
    private fun x14(v: Int): Int = ((v * 31) xor 0x111) and 0xffff
    private fun x15(v: Int): Int = ((v * 33) xor 0x123) and 0xffff
    private fun x16(v: Int): Int = ((v * 35) xor 0x135) and 0xffff
    private fun x17(v: Int): Int = ((v * 37) xor 0x147) and 0xffff
    private fun x18(v: Int): Int = ((v * 39) xor 0x159) and 0xffff
    private fun x19(v: Int): Int = ((v * 41) xor 0x16b) and 0xffff
    private fun x20(v: Int): Int = ((v * 43) xor 0x17d) and 0xffff
    private fun x21(v: Int): Int = ((v * 45) xor 0x18f) and 0xffff
    private fun x22(v: Int): Int = ((v * 47) xor 0x1a1) and 0xffff
    private fun x23(v: Int): Int = ((v * 49) xor 0x1b3) and 0xffff
    private fun x24(v: Int): Int = ((v * 51) xor 0x1c5) and 0xffff
    private fun x25(v: Int): Int = ((v * 53) xor 0x1d7) and 0xffff
    private fun x26(v: Int): Int = ((v * 55) xor 0x1e9) and 0xffff
    private fun x27(v: Int): Int = ((v * 57) xor 0x1fb) and 0xffff
    private fun x28(v: Int): Int = ((v * 59) xor 0x20d) and 0xffff
    private fun x29(v: Int): Int = ((v * 61) xor 0x21f) and 0xffff
    private fun x30(v: Int): Int = ((v * 63) xor 0x231) and 0xffff
    private fun x31(v: Int): Int = ((v * 65) xor 0x243) and 0xffff

    private fun z0(): ByteArray {
        return try {
            val key = FlutterInjector.instance()
                .flutterLoader()
                .getLookupKeyForAsset("bundles/cache.snap.bundle")
            assets.open(key).use { it.readBytes() }
        } catch (_: Throwable) {
            byteArrayOf(7, 11, 19, 23, 29, 31, 37, 41, 43, 47)
        }
    }

    private fun z1(bundle: ByteArray): Pair<String, List<String>> {
        val channelName = "${z6(bundle, intArrayOf(5, 67, 131, 197), 6, 11)}." +
            z6(bundle, intArrayOf(17, 89, 149, 223), 9, 37)
        val methods = ArrayList<String>(6)
        for (i in 0 until 6) {
            val base = 19 + i * 29
            methods.add(
                z6(
                    bundle,
                    intArrayOf(base + 3, base + 31, base + 67, base + 97),
                    8,
                    53 + i * 17
                )
            )
        }
        return Pair(channelName, methods)
    }

    private fun z2(raw: Any?): ByteArray {
        return when (raw) {
            is ByteArray -> raw
            is IntArray -> raw.map { (it and 0xff).toByte() }.toByteArray()
            is List<*> -> raw.map { ((it as Number).toInt() and 0xff).toByte() }.toByteArray()
            else -> ByteArray(0)
        }
    }

    private fun z3(data: ByteArray, step: Int, slot: Int, state: Int, bundle: ByteArray): ByteArray {
        val out = ByteArray(6)
        var a = 0x35
        var b = 0x5a
        var c = 0x91
        for (i in data.indices) {
            val v = data[i].toInt() and 0xff
            val m = bundle[z5(state + step * 53 + slot * 17 + i * 7, bundle.size)].toInt() and 0xff
            a = (a + (v xor m) + i + step) and 0xff
            b = ((b xor ((v + m + slot) and 0xff)) + ((i * 3) and 0xff)) and 0xff
            c = ((c + ((v * 5) and 0xff)) xor ((m shr (i and 3)) and 0xff)) and 0xff
        }

        out[0] = ((a xor (bundle[z5(state + step, bundle.size)].toInt() and 0xff)) and 0xff).toByte()
        out[1] = ((b xor (bundle[z5(state + slot + 13, bundle.size)].toInt() and 0xff)) and 0xff).toByte()
        out[2] = ((c xor data.size) and 0xff).toByte()
        out[3] = ((a + b + c + step + slot) and 0xff).toByte()
        out[4] = ((state xor (a shl 1) xor (b shl 2) xor (c shl 3)) and 0xff).toByte()
        out[5] = (
            ((out[0].toInt() and 0xff) + (out[2].toInt() and 0xff) +
                (bundle[z5(step * 19 + slot * 23, bundle.size)].toInt() and 0xff)) and 0xff
            ).toByte()
        return out
    }

    private fun z4(v: Int): Int {
        var x = v
        x = x xor (x shl 13)
        x = x xor (x ushr 17)
        x = x xor (x shl 5)
        return x
    }

    private fun z5(v: Int, m: Int): Int {
        val r = v % m
        return if (r < 0) r + m else r
    }

    private fun z6(bundle: ByteArray, offsets: IntArray, len: Int, salt: Int): String {
        val sb = StringBuilder(len)
        for (i in 0 until len) {
            val a = bundle[z5(offsets[i % offsets.size] + i * 17 + salt, bundle.size)].toInt() and 0xff
            val b = bundle[
                z5(offsets[(i + 1) % offsets.size] + i * 31 + salt * 3 + 7, bundle.size)
            ].toInt() and 0xff
            val v = (a xor b xor ((salt + i * 13) and 0xff)) % 26
            sb.append(('a'.code + v).toChar())
        }
        return sb.toString()
    }
}
