import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:video_player/video_player.dart';

import 'ctf_verifier.dart';

void main() {
  runApp(const CtfApp());
}

class CtfApp extends StatelessWidget {
  const CtfApp({super.key});

  static const String kTitle = 'flumel';
  static const String kGateLine =
      'Later, respectively, wander and suffer sorrow.';

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: kTitle,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.blueGrey),
      ),
      home: const IntroVideoPage(),
    );
  }
}

class IntroVideoPage extends StatefulWidget {
  const IntroVideoPage({super.key});

  @override
  State<IntroVideoPage> createState() => _IntroVideoPageState();
}

class _IntroVideoPageState extends State<IntroVideoPage> {
  late final VideoPlayerController _controller;
  bool _initialized = false;
  bool _enteredFlagPage = false;

  @override
  void initState() {
    super.initState();
    _controller = VideoPlayerController.asset('assets/intro/1.mp4')
      ..setLooping(false)
      ..addListener(_onVideoTick);

    _controller
        .initialize()
        .then((_) {
          if (!mounted) {
            return;
          }
          setState(() {
            _initialized = true;
          });
          _controller.play();
        })
        .catchError((_) {
          _enterFlagPage();
        });
  }

  void _onVideoTick() {
    if (_enteredFlagPage) {
      return;
    }
    final value = _controller.value;
    if (!value.isInitialized) {
      return;
    }
    if (value.hasError) {
      _enterFlagPage();
      return;
    }
    if (!value.isPlaying &&
        value.duration > Duration.zero &&
        value.position >= value.duration) {
      _enterFlagPage();
    }
  }

  void _enterFlagPage() {
    if (_enteredFlagPage || !mounted) {
      return;
    }
    _enteredFlagPage = true;
    Navigator.of(
      context,
    ).pushReplacement(MaterialPageRoute(builder: (_) => const FlagCheckPage()));
  }

  @override
  void dispose() {
    _controller.removeListener(_onVideoTick);
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Center(
        child: _initialized
            ? AspectRatio(
                aspectRatio: _controller.value.aspectRatio == 0
                    ? 16 / 9
                    : _controller.value.aspectRatio,
                child: VideoPlayer(_controller),
              )
            : const CircularProgressIndicator(),
      ),
    );
  }
}

class FlagCheckPage extends StatefulWidget {
  const FlagCheckPage({super.key});

  @override
  State<FlagCheckPage> createState() => _FlagCheckPageState();
}

class _FlagCheckPageState extends State<FlagCheckPage> {
  final TextEditingController _controller = TextEditingController();
  String _result = 'Input flag and tap Verify';
  bool _checking = false;
  bool? _lastCheckOk;

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Future<void> _verifyFlag() async {
    if (_checking) {
      return;
    }

    final candidate = _controller.text.trim();
    if (candidate.isEmpty) {
      setState(() {
        _result = 'Flag cannot be empty';
        _lastCheckOk = false;
      });
      return;
    }

    setState(() {
      _checking = true;
      _result = 'Checking...';
      _lastCheckOk = null;
    });

    try {
      final ok = await CtfVerifier.verify(candidate);
      if (!mounted) {
        return;
      }
      setState(() {
        _result = ok ? 'Correct!' : 'Wrong flag';
        _lastCheckOk = ok;
      });
      await Future<void>.delayed(const Duration(seconds: 1));
      if (!mounted) {
        return;
      }
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(builder: (_) => OutcomeVideoPage(success: ok)),
      );
    } on UnsupportedError catch (error) {
      setState(() {
        _result = error.message ?? 'Unsupported platform';
        _lastCheckOk = false;
      });
    } on Object catch (error) {
      setState(() {
        _result = 'Native verify failed: $error';
        _lastCheckOk = false;
      });
    } finally {
      if (mounted) {
        setState(() {
          _checking = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final resultColor = _lastCheckOk == null
        ? Colors.blueGrey.shade700
        : (_lastCheckOk! ? const Color(0xFF0B8F5B) : const Color(0xFFBE2E4A));

    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Color(0xFF0B132B), Color(0xFF1C2541), Color(0xFF3A506B)],
          ),
        ),
        child: Stack(
          children: [
            const Positioned(
              top: -60,
              right: -40,
              child: _BackgroundOrb(size: 220, color: Color(0xFFEE6C4D)),
            ),
            const Positioned(
              bottom: -80,
              left: -60,
              child: _BackgroundOrb(size: 260, color: Color(0xFF5BC0BE)),
            ),
            SafeArea(
              child: Center(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.all(20),
                  child: ConstrainedBox(
                    constraints: const BoxConstraints(maxWidth: 520),
                    child: Container(
                      padding: const EdgeInsets.all(22),
                      decoration: BoxDecoration(
                        color: Colors.white.withValues(alpha: 0.93),
                        borderRadius: BorderRadius.circular(24),
                        boxShadow: const [
                          BoxShadow(
                            color: Color(0x33000000),
                            blurRadius: 28,
                            offset: Offset(0, 14),
                          ),
                        ],
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          const Text(
                            CtfApp.kTitle,
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              fontSize: 30,
                              fontWeight: FontWeight.w900,
                              letterSpacing: 0.5,
                              color: Color(0xFF10243D),
                            ),
                          ),
                          const SizedBox(height: 8),
                          const Text(
                            CtfApp.kGateLine,
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              fontWeight: FontWeight.w700,
                              color: Color(0xFF334E68),
                            ),
                          ),
                          const SizedBox(height: 20),
                          TextField(
                            controller: _controller,
                            textInputAction: TextInputAction.done,
                            onSubmitted: (_) => _verifyFlag(),
                            decoration: InputDecoration(
                              filled: true,
                              fillColor: const Color(0xFFF2F6FA),
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(14),
                                borderSide: BorderSide.none,
                              ),
                              hintText: 'Enter Flag',
                              prefixIcon: const Icon(
                                Icons.vpn_key_rounded,
                                color: Color(0xFF3A506B),
                              ),
                            ),
                          ),
                          const SizedBox(height: 14),
                          SizedBox(
                            height: 52,
                            child: ElevatedButton.icon(
                              onPressed: _checking ? null : _verifyFlag,
                              style: ElevatedButton.styleFrom(
                                backgroundColor: const Color(0xFFEE6C4D),
                                foregroundColor: Colors.white,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(14),
                                ),
                                textStyle: const TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.w800,
                                ),
                              ),
                              icon: Icon(
                                _checking ? Icons.hourglass_top : Icons.bolt,
                              ),
                              label: Text(_checking ? 'Checking...' : 'Verify'),
                            ),
                          ),
                          const SizedBox(height: 14),
                          AnimatedContainer(
                            duration: const Duration(milliseconds: 220),
                            padding: const EdgeInsets.symmetric(
                              horizontal: 14,
                              vertical: 12,
                            ),
                            decoration: BoxDecoration(
                              color: resultColor.withValues(alpha: 0.12),
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(
                                color: resultColor.withValues(alpha: 0.45),
                              ),
                            ),
                            child: Text(
                              _result,
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                color: resultColor,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class OutcomeVideoPage extends StatefulWidget {
  const OutcomeVideoPage({super.key, required this.success});

  final bool success;

  @override
  State<OutcomeVideoPage> createState() => _OutcomeVideoPageState();
}

class _OutcomeVideoPageState extends State<OutcomeVideoPage> {
  late final VideoPlayerController _controller;
  bool _initialized = false;
  bool _completed = false;

  @override
  void initState() {
    super.initState();
    _controller =
        VideoPlayerController.asset(
            widget.success
                ? 'assets/result/right.mp4'
                : 'assets/result/wrong.mp4',
          )
          ..setLooping(false)
          ..addListener(_onVideoTick);

    _controller
        .initialize()
        .then((_) {
          if (!mounted) {
            return;
          }
          setState(() {
            _initialized = true;
          });
          _controller.play();
        })
        .catchError((_) {
          _finishFlow();
        });
  }

  void _onVideoTick() {
    if (_completed) {
      return;
    }
    final value = _controller.value;
    if (!value.isInitialized) {
      return;
    }
    if (value.hasError) {
      _finishFlow();
      return;
    }
    if (!value.isPlaying &&
        value.duration > Duration.zero &&
        value.position >= value.duration) {
      _finishFlow();
    }
  }

  void _finishFlow() {
    if (_completed || !mounted) {
      return;
    }
    _completed = true;
    if (widget.success) {
      SystemNavigator.pop();
      return;
    }
    Navigator.of(
      context,
    ).pushReplacement(MaterialPageRoute(builder: (_) => const FlagCheckPage()));
  }

  @override
  void dispose() {
    _controller.removeListener(_onVideoTick);
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Center(
        child: _initialized
            ? AspectRatio(
                aspectRatio: _controller.value.aspectRatio == 0
                    ? 16 / 9
                    : _controller.value.aspectRatio,
                child: VideoPlayer(_controller),
              )
            : const CircularProgressIndicator(),
      ),
    );
  }
}

class _BackgroundOrb extends StatelessWidget {
  const _BackgroundOrb({required this.size, required this.color});

  final double size;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: color.withValues(alpha: 0.22),
      ),
    );
  }
}
